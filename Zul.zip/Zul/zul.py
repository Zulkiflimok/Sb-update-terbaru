#TEAM TERMUX CREATOR ZULKIFLI MOKOAGOW
import Zul
from Zul import *
from liff.ttypes import LiffChatContext, LiffContext, LiffSquareChatContext, LiffNoneContext, LiffViewRequest
from akad.ttypes import Message
from akad.ttypes import ContentType as Type
from akad.ttypes import ChatRoomAnnouncementContents
from akad.ttypes import ChatRoomAnnouncement
from thrift import transport, protocol, server
from datetime import datetime, timedelta
import pytz, pafy, livejson, time, asyncio, random, multiprocessing, timeit, sys, json, ctypes, tweepy, codecs, threading, glob, re, ast, six, os, subprocess, wikipedia, atexit, goslate, urllib, urllib.parse, urllib3, string, tempfile, shutil, unicodedata
from humanfriendly import format_timespan, format_size, format_number, format_length
import html5lib
import subprocess, youtube_dl, humanize, traceback
import requests,json,urllib3
from io import StringIO
from random import randint
from bs4 import BeautifulSoup
from gtts import gTTS
from Naked.toolshed.shell import execute_js
from googletrans import Translator
import youtube_dl
from time import sleep
from urllib.parse import urlencode
from multiprocessing import Pool
import subprocess as cmd
import pyimgflip
from BEAPI import BEAPI
from zalgo_text import zalgo
from BEAPI import *
from threading import Thread,Event
import platform
import requests, json
import wikipedia as wiki
requests.packages.urllib3.disable_warnings()
try:
    import urllib.request as urllib2
except ImportError:
    import urllib2


cl = LINE("imel@gmail.com","katasandi") #isi imel dan kata sandi line mu disini
cl.log("Auth Token : " + str(cl.authToken))
#=====================================
oepoll = OEPoll(cl)
call = cl
creator = ["ua4430a010faaae4f5a7a49c0c343444f"] # ganti dengan mid kamu
owner = ["ua4430a010faaae4f5a7a49c0c343444f"] # ganti dengan mid kamu
aadmin = ["ua4430a010faaae4f5a7a49c0c343444f"] # ganti dengan mid kamu
staff = ["ua4430a010faaae4f5a7a49c0c343444f"] # ganti dengan mid kamu
lineProfile = cl.getProfile()
mid = cl.getProfile().mid
KAC = [cl]
Bots = [mid]
Saints = aadmin + owner + staff
admin = creator + owner + aadmin + staff + Bots
Setbot = codecs.open("setting.json","r","utf-8")
Setmain = json.load(Setbot)
lineProfile = cl.getProfile()
mid = cl.getProfile().mid
KAC = [cl]
Bots = [mid]
Saints = aadmin + owner + staff
admin = creator + owner + aadmin + staff + Bots
Setbot = codecs.open("setting.json","r","utf-8")
Setmain = json.load(Setbot)

#=={ Update terbaru Version }
welcome = []
protectqr = []
protectkick = []
protectjoin = []
protectinvite = []
protectcancel = []
targets = []
protectname = []
prohibitedWords = ['Asu', 'Jancuk', 'Tai', 'Kickall', 'Ratakan', 'Cleanse']
userTemp = {}
userKicked = []
msg_dict = {}
msg_dict1 = {}
dt_to_str = {}
temp_flood = {}
groupName = {}
groupImage = {}
list = []
ban_list = []
offbot = []

settings = {
    "welcome": False,
    "leave": False,
    "mid": False,
    "Aip": True,
    "replySticker": False,
    "stickerOn": False,
    "checkContact": False,
    "postEndUrl": {},
    "postingan":{},
    "checkPost": False,
    "autoRead": False,
    "autoJoinTicket": False,
    "setKey": False,
    "restartPoint": False,
    "checkSticker": False,
    "userMentioned": False,
    "messageSticker": False,
    "changeGroupPicture": [],
    "keyCommand": "",
    "AddstickerTag": {
        "sid": "",
        "spkg": "",
        "status": False
            },
    "Addsticker":{
            "name": "",
            "status":False
            },
    "stk":{},
    "selfbot":True,
    "Images":{},
    "Img":{},
    "Addimage":{
            "name": "",
            "status":False
            },
    "Videos":{},
    "Addaudio":{
            "name": "",
            "status":False
            },
    "Addvideo":{
            "name": "",
            "status":False
            },
    "myProfile": {
        "displayName": "",
        "coverId": "",
        "pictureStatus": "",
        "statusMessage": ""
    },
    "mimic": {
        "copy": False,
        "status": False,
        "target": {}
    }, 
    "unsendMessage": False,
    "Picture":False,
    "group":{},
    "groupPicture":False,
    "changevp": False,
    "changeCover":False,
    "changePicture":False,
    "changeProfileVideo": False,
    "ChangeVideoProfilevid":{},
    "ChangeVideoProfilePicture":{},
    "displayName": "",
    "userAgent": [
        "Mozilla/5.0 (Linux; Android 5.1.1; ASUS_X014D Build/LMY47V; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/79.0.3945.93 Mobile Safari/537.36 Line/9.2.0"
        "Mozilla/5.0 (X11; U; Linux i586; de; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (X11; U; Linux amd64; rv:5.0) Gecko/20100101 Firefox/5.0 (Debian)",
        "Mozilla/5.0 (X11; U; Linux amd64; en-US; rv:5.0) Gecko/20110619 Firefox/5.0",
        "Mozilla/5.0 (X11; Linux) Gecko Firefox/5.0",
        "Mozilla/5.0 (X11; Linux x86_64; rv:5.0) Gecko/20100101 Firefox/5.0 FirePHP/0.5",
        "Mozilla/5.0 (X11; Linux x86_64; rv:5.0) Gecko/20100101 Firefox/5.0 Firefox/5.0",
        "Mozilla/5.0 (X11; Linux x86_64) Gecko Firefox/5.0",
        "Mozilla/5.0 (X11; Linux ppc; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (X11; Linux AMD64) Gecko Firefox/5.0",
        "Mozilla/5.0 (X11; FreeBSD amd64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.2; WOW64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:5.0) Gecko/20110619 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.1; rv:6.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.1.1; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.2; WOW64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.1; U; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.1; rv:2.0.1) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.0; WOW64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.0; rv:5.0) Gecko/20100101 Firefox/5.0"
    ]
}

wait = {
    "limit": 1,
    "owner":{},
    "admin":{},
    "delFriend":False,
    "addadmin":False,
    "delladmin":False,
    "checkmid": False,
    "getMid": False,
    "invite":False,
    "Invi":False,
    "staff":{},
    "Timeline": False,
    "likePost": False,
    "likeOn": True,
    "addstaff":False,
    "dellstaff":False,
    "bots":{},
    "readPoint":{},
    "readMember":{},
    "lang":False,
    "addbots":False,
    "dellbots":False,
    "blacklist":{},
    "wblacklist":False,
    "dblacklist":False,
    "Talkblacklist":{},
    "Talkwblacklist":False,
    "Talkdblacklist":False,
    "talkban":True,
    "tumbal":True,
    "backup":True,
    "smule": True,
    "smulenotife": True,
    "contact":False,
    "autoRead": False,
    "autoBlock": True,
    "autoJoin":False,
    "autoAdd":True,
    'autoCancel':{"on":True, "members":1},
    "autoReject":False,
    "autoLeave": False,
    "autoLeave1": False,    
    "detectMention":False,
    "detectMention2":False,
    "detectMention3":False,
    "detectMention4":False,
    "arespon":False,
    "Mentionkick":False,
    "welcomeOn":True,
    "welcome": True,
    "responGc":True,
    "responGc1":True,
    "responGc2": True,
    "responGc3":True,
    "responGc4":True,
    "responGc5":True,
    "Unsend":False,
    "youtube":False,
    "sticker":False,
    "ytube":True,
    "selfbot":True,
    "smule":True,
    "apikey" : "WdKBots1991",
    "tagall": "all",
    "mention":"ɪɴɪ ᴅɪᴀ ᴛᴜᴋᴀɴɢ ɴʏɪᴍᴀᴋ ɴɪʜ ᴊᴏɴᴇꜱ",
    "Respontag":"ᴀꜱᴇᴍ ᴅɪ ᴛᴀɢ ᴀᴡᴀꜱ ɴʏᴀᴍᴀɴ ʟᴏʜ",
    "Respontag2":"ᴛᴀɢ ᴛɪᴅᴀᴋ ᴊᴇʟᴀꜱ ᴛᴇɴɢᴇʟᴀᴍᴋᴀɴ",
    "Respontag3":"ᴀᴡᴀꜱ ᴛᴜᴋᴀɴɢ ᴛᴀɢ ɴɪʜ ɴʏᴀʀɪ ᴋᴏᴊᴏᴍᴀɴ ᴅɪᴀ",
    "Respontag4":"ᴀᴘᴀɴ ᴛᴀɢ ɢᴜᴇ ᴍᴀᴜ ʙᴀʏᴀʀ ʜᴜᴛᴀɴɢ",
    "Respontag5":"ᴀᴡᴀꜱ ᴀᴅᴀ ᴊᴏɴᴇꜱ ᴅɪᴀ ᴛᴀɢ ᴀᴋᴜ",
    "welcome":"sᴇᴍᴏɢᴀ ʙᴇᴛᴀʜ ɢᴀᴇᴢ",
    "autoLeave":"ɴᴀʜ ᴋᴀɴ ᴋᴋ ʙᴀʀᴜ ᴊᴜɢᴀ ᴍᴀꜱᴜᴋ ᴜᴅᴀʜ ᴋᴀʙᴜʀ ʙᴀᴘᴇʀᴀɴ",
    "comment":"Autolike Bye: TEAM TERMUX",
    "message1":"ᴛʜᴀɴᴋᴢ ғᴏʀᴅ ᴀᴅᴅ ᴍᴇ\n╭──────────────────╮\n├🌺  Open Order Bots     \n╰──────────────────╯\n╭──────────────────\n├🌺  Sb Template Full =50k\n├🌺  6 Asis War Go =350\n├🌺  10 Asis War Go =450\n├🌺  4 Asis War Go =250\n├🌺  10 Pro + 1Ajs = 350k/ʙʟɴ\n├🌺  6 Pro + 1Ajs = 250k/ʙʟɴ\n├🌺  Vps Allversion\n├🌺  Token Primary\n├🌺  Vip Android\n├🌺  Soong Books\n├🌺  Apikey Bulanan\n├🌺  Terima Bikin Sc Bots\n├🌺  Selfbot antijs\n├🌺  Bot Kuis\n├🌺  Bot Chat\n├🌺  Sewa Helper Selfbot\n├🌺  Akun Vps Vurtl\n├🌺  Akun Vps Gcload\n├🌺  ᴋʟɪᴋ ᴏʀᴅᴇʀ ᴄʀᴇᴀᴛᴏʀ \n╰────────────────── \n╭─────────────────\n├🌺  line.me/ti/p/~Zul.1.02\n╰─────────────────",
}
protect = {
    "pqr":[],
    "pinv":[],
    "proall":[],
    "antijs":[],
    "protect":[]
}

read = {
    "readPoint":{},
    "readMember":{},
    "readTime":{},
    "ROM":{},
}

cctv = {
    "cyduk":{},
    "point":{},
    "sidermem":{}
}

cctv2 = {
    "cyduk2":{},
    "point2":{},
    "sidermem2":{}
}

myProfile = {
	"displayName": "",
	"statusMessage": "",
	"pictureStatus": ""
}
    
clProfile = cl.getProfile()
myProfile["displayName"] = clProfile.displayName
myProfile["statusMessage"] = clProfile.statusMessage
myProfile["pictureStatus"] = clProfile.pictureStatus

contact = cl.getProfile()
backup = cl.getProfile()
backup.displayName = contact.displayName
backup.statusMessage = contact.statusMessage
backup.pictureStatus = contact.pictureStatus


imagesOpen = codecs.open("image.json","r","utf-8")
images = json.load(imagesOpen)
videosOpen = codecs.open("video.json","r","utf-8")
videos = json.load(videosOpen)
stickersOpen = codecs.open("sticker.json","r","utf-8")
stickers = json.load(stickersOpen)
audiosOpen = codecs.open("audio.json","r","utf-8")
audios = json.load(audiosOpen)
mulai = time.time()

msg_dict = {}
msg_dict1 = {}

tz = pytz.timezone("Asia/Jakarta")
timeNow = datetime.now(tz=tz)
           
def cTime_to_datetime(unixtime):
    return datetime.fromtimestamp(int(str(unixtime)[:len(str(unixtime))-3]))

def autolike():
    for zx in range(0,500):
      hasil = cl.activity(limit=500)
      if hasil['result']['posts'][zx]['postInfo']['liked'] == True:
        try:
          cl.like(hasil['result']['posts'][zx]['userInfo']['mid'],hasil['result']['posts'][zx]['postInfo']['postId'],likeType=1001)
          cl.comment(hasil['result']['posts'][zx]['userInfo']['mid'],hasil['result']['posts'][zx]['postInfo']['postid'],wait["comment"])
          print ("✪[]► Like Success")
        except:
          pass
      else:
          print ("Already Liked")
    
def dt_to_str(dt):
    return dt.strftime('%H:%M:%S')

#delete log if pass more than 24 hours
def delete_log():
    ndt = datetime.now()
    for data in msg_dict:
        if (datetime.utcnow() - cTime_to_datetime(msg_dict[data]["createdTime"])) > datetime.timedelta(1):
            del msg_dict[msg_id]
        
def delete_log():
    ndt = datetime.now()
    for data in msg_dict:
        if (datetime.utcnow() - cTime_to_datetime(msg_dict[data]["createdTime"])) > timedelta(1):
            if "path" in msg_dict[data]:
                cl.deleteFile(msg_dict[data]["path"])
            del msg_dict[data]


def logError(text):
    cl.log("[ ERROR ] {}".format(str(text)))
    tz = pytz.timezone("Asia/Jakarta")
    timeNow = datetime.now(tz=tz)
    timeHours = datetime.strftime(timeNow,"(%H:%M)")
    day = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday","Friday", "Saturday"]
    hari = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"]
    bulan = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"]
    inihari = datetime.now(tz=tz)
    hr = inihari.strftime('%A')
    bln = inihari.strftime('%m')
    for i in range(len(day)):
        if hr == day[i]: hasil = hari[i]
    for k in range(0, len(bulan)):
        if bln == str(k): bln = bulan[k-1]
    time = "{}, {} - {} - {} | {}".format(str(hasil), str(inihari.strftime('%d')), str(bln), str(inihari.strftime('%Y')), str(inihari.strftime('%H:%M:%S')))
    with open("logError.txt","a") as error:
        error.write("\n[ {} ] {}".format(str(time), text))

def download_page(url):
    version = (3,0)
    cur_version = sys.version_info
    if cur_version >= version:     
        import urllib,request
        try:
            headers = {}
            headers['User-Agent'] = "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36"
            req = urllib,request.Request(url, headers = headers)
            resp = urllib,request.urlopen(req)
            respData = str(resp.read())
            return respData
        except Exception as e:
            print(str(e))
    else:                        
        import urllib2
        try:
            headers = {}
            headers['User-Agent'] = "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.17 (KHTML, like Gecko) Chrome/24.0.1312.27 Safari/537.17"
            req = urllib2.Request(url, headers = headers)
            response = urllib2.urlopen(req)
            page = response.read()
            return page
        except:
            return"Page Not found"

def _images_get_all_items(page):
    items = []
    while True:
        item, end_content = _images_get_next_item(page)
        if item == "no_links":
            break
        else:
            items.append(item)      
            time.sleep(0.1)        
            page = page[end_content:]
    return items

def downloadImageWithURL (mid):
    contact = cl.getContact(mid)
    if contact.videoProfile == None:
        cl.cloneContactProfile(mid)
    else:
        profile = cl.getProfile()
        profile.displayName, profile.statusMessage = contact.displayName, contact.statusMessage
        cl.updateProfile(profile)
        pict = cl.downloadFileURL('http://dl.profile.line-cdn.net/' + contact.pictureStatus, saveAs="tmp/pict.bin")
        vids = cl.downloadFileURL( 'http://dl.profile.line-cdn.net/' + contact.pictureStatus + '/vp', saveAs="tmp/video.bin")
        changeVideoAndPictureProfile(pict, vids)
    coverId = cl.getProfileDetail(mid)['result']['objectId']
    cl.updateProfileCoverById(coverId)
    
def restartBot():
    python = sys.executable
    os.execl(python, python, *sys.argv)

def waktu(secs):
    mins, secs = divmod(secs,60)
    hours, mins = divmod(mins,60)
    days, hours = divmod(hours, 24)
    return '%02d Hari %02d Jam %02d Menit %02d Detik' % (days, hours, mins, secs)

def runtime(secs):
    mins, secs = divmod(secs,60)
    hours, mins = divmod(mins,60)
    days, hours = divmod(hours, 24)
    return '%02d Hari %02d Jam %02d Menit %02d Detik' % (days, hours, mins, secs)
    
def sendImage(to, path, name="image"):
    try:
        if settings["server"] == "VPS":
            cl.sendImageWithURL(to, str(path))
    except Exception as error:
        logError(error)

def changeProfileVideo(to):
    if settings['changevp']['picture'] == True:
        return cl.sendMessage(to, "Foto tidak ditemukan")
    elif settings['changevp']['video'] == True:
        return cl.sendMessage(to, "Video tidak ditemukan")
    else:
        path = settings['changevp']['video']
        files = {'file': open(path, 'rb')}
        obs_params = cl.genOBSParams({'oid': cl.getProfile().mid, 'ver': '2.0', 'type': 'video', 'cat': 'vp.mp4'})
        data = {'params': obs_params}
        r_vp = cl.server.postContent('{}/talk/vp/upload.nhn'.format(str(cl.server.LINE_OBS_DOMAIN)), data=data, files=files)
        if r_vp.status_code != 201:
            return cl.sendMessage(to, "Gagal update profile")
        path_p = settings['changevp']['picture']
        settings['changevp']['status'] = True
        cl.updateProfilePicture(path_p, 'vp')
                     
def changeVideoAndPictureProfile(pict, vids):
    try:
        files = {'file': open(vids, 'rb')}
        obs_params = cl.genOBSParams({'oid': mid, 'ver': '2.0', 'type': 'video', 'cat': 'vp.mp4', 'name': 'GEGE.mp4'})
        data = {'params': obs_params}
        r_vp = cl.server.postContent('{}/talk/vp/upload.nhn'.format(str(cl.server.LINE_OBS_DOMAIN)), data=data, files=files)
        if r_vp.status_code != 201:
            return "Failed update profile"
        cl.updateProfilePicture(pict, 'vp')
        return "Success update profile"
    except Exception as e:
        raise Exception("Error change video and picture profile %s"%str(e))

def cloneProfile(mid):
    contact = cl.getContact(mid)
    if contact.videoProfile == None:
        cl.cloneContactProfile(mid)
    else:
        profile = cl.getProfile()
        profile.displayName, profile.statusMessage = contact.displayName, contact.statusMessage
        cl.updateProfile(profile)
        pict = cl.downloadFileURL('http://dl.profile.line-cdn.net/' + contact.pictureStatus, saveAs="tmp/pict.bin")
        vids = cl.downloadFileURL( 'http://dl.profile.line-cdn.net/' + contact.pictureStatus + '/vp', saveAs="tmp/video.bin")
        changeVideoAndPictureProfile(pict, vids)
    coverId = cl.getProfileDetail(mid)['result']['objectId']
    cl.updateProfileCoverById(coverId)

def restoreProfile():
    profile = cl.getProfile()
    profile.displayName = settings['myProfile']['displayName']
    profile.statusMessage = settings['myProfile']['statusMessage']
    if settings['myProfile']['videoProfile'] == None:
        profile.pictureStatus = settings['myProfile']['pictureStatus']
        cl.updateProfileAttribute(8, profile.pictureStatus)
        cl.updateProfile(profile)
    else:
        cl.updateProfile(profile)
        pict = cl.downloadFileURL('http://dl.profile.line-cdn.net/' + settings['myProfile']['pictureStatus'], saveAs="tmp/pict.bin")
        vids = cl.downloadFileURL( 'http://dl.profile.line-cdn.net/' + settings['myProfile']['pictureStatus'] + '/vp', saveAs="tmp/video.bin")
        changeVideoAndPictureProfile(pict, vids)
    coverId = settings['myProfile']['coverId']
    cl.updateProfileCoverById(coverId)

def mentionMembers(to, mid):
    try:
        arrData = ""
        ginfo = cl.getGroup(to)
        textx = "╔═════[ Sider Members ]═══════\n╠➣   Sini Gabung Chat ka 😊..\n╠☛ 1. "
        arr = []
        no = 1
        for i in mid:
            mention = "@x\n"
            slen = str(len(textx))
            elen = str(len(textx) + len(mention) - 1)
            arrData = {'S':slen, 'E':elen, 'M':i}
            arr.append(arrData)
            textx += mention
            if no < len(mid):
                no += 1
                textx += "╠☛  {}. ".format(str(no))
            else:
                textx += "╚══════════════════\n╔══════════════════\n  「 ᴛᴏᴛᴀʟ ᴍᴇᴍʙᴇʀ : {} 」\n╚══════════════════".format(str(len(mid)))
        cl.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        cl.sendMessage(to, "[ INFO ] Error :\n" + str(error))

def siderMembers(to, mid):
    try:
        arrData = ""
        textx = (str(len(mid)))
        arr = []
        no = 1
        num = 2
        for i in mid:
            mention = "@x\n"
            slen = str(len(textx))
            elen = str(len(textx) + len(mention) - 1)
            arrData = {'S':slen, 'E':elen, 'M':i}
            arr.append(arrData)
            textx += mention
            if no < len(mid):
                no += 1
                textx += "%i. " % (num)
                num=(num)
            else:
                try:
                    no = "\n╚══[ {} ]".format(str(cl.getGroup(to).name))
                except:
                    no = "\n╚══[ Success ]"
#===== [ ꜱᴜᴘᴘᴏʀᴛ ʙʏᴇ ᴛᴇᴀᴍ TEAM TERMUX
    except Exception as error:
        cl.sendMessage(to, "[ INFO ] Error :\n" + str(error))
       
def summon(to, nama):
    aa = ""
    bb = ""
    strt = int(0)
    akh = int(0)
    nm = nama
    myid = cl.getProfile().mid
    if myid in nm:
      nm.remove(myid)
    for mm in nm:
      akh = akh + 6
      aa += """{"S":"""+json.dumps(str(strt))+""","E":"""+json.dumps(str(akh))+""","M":"""+json.dumps(mm)+"},"""
      strt = strt + 7
      akh = akh + 1
      bb += "@nrik "
    aa = (aa[:int(len(aa)-1)])
    text = bb
    try:
       cl.sendMessage(to, text, contentMetadata={'MENTION':'{"MENTIONEES":['+aa+']}'}, contentType=0)
    except Exception as error:
       print(error)
       
def welcomeMembers(to, mid):
    try:
        arrData = ""
        textx = " ".format(str(len(mid)))
        arr = []
        no = 1
        num = 2
        for i in mid:
            ginfo = cl.getGroup(to)
            mention = "@x\n"
            slen = str(len(textx))
            elen = str(len(textx) + len(mention) - 1)
            arrData = {'S':slen, 'E':elen, 'M':i}
            arr.append(arrData)
            textx += mention
            if no < len(mid):
                no += 1
                textx += "%i " % (num)
                num=(num+1)
            else:
                try:
                    no = "\n╚══[ {} ]".format(str(cl.getGroup(to).name))
                except:
                    no = "\n╚══[ Success ]"
       # cl.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        cl.sendMessage(to, "[ INFO ] Error :\n" + str(error))

def leaveMembers(to, mid):
    try:
        arrData = ""
        textx = "".format(str(len(mid)))
        arr = []
        no = 1
        num = 2
        for i in mid:
            ginfo = cl.getGroup(to)
            mention = "@x\n"
            slen = str(len(textx))
            elen = str(len(textx) + len(mention) - 1)
            arrData = {'S':slen, 'E':elen, 'M':i}
            arr.append(arrData)
            textx += mention
            if no < len(mid):
                no += 1
                textx += "%i " % (num)
                num=(num+1)
            else:
                try:
                    no = "\n┗━━[ {} ]".format(str(aditmadzs.getGroup(to).name))
                except:
                    no = "\n┗━━[ Success ]"
    #    cl.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        cl.sendMessage(to, "[ INFO ] Error :\n" + str(error))

def sendMention(to, mid, firstmessage):
    try:
        arrData = ""
        text = "%s " %(str(firstmessage))
        arr = []
        mention = "@x \n"
        slen = str(len(text))
        elen = str(len(text) + len(mention) - 1)
        arrData = {'S':slen, 'E':elen, 'M':mid}
        arr.append(arrData)
        today = datetime.today()
        future = datetime(2018,3,1)
        hari = (str(future - today))
        comma = hari.find(",")
        hari = hari[:comma]
        teman = cl.getAllContactIds()
        gid = cl.getGroupIdsJoined()
        tz = pytz.timezone("Asia/Jakarta")
        timeNow = datetime.now(tz=tz)
        eltime = time.time() - mulai
        bot = runtime(eltime)
        text += mention+"jam : "+datetime.strftime(timeNow,'%H:%M:%S')+" wib\nNama Group : "+str(len(gid))+"\nTeman : "+str(len(teman))+"\nExpired : In "+hari+"\n Version :「Gaje Bots」  \nTanggal : "+datetime.strftime(timeNow,'%Y-%m-%d')+"\nRuntime : \n • "+bot
        cl.sendMessage(to, text, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        cl.sendMessage(to, "[ INFO ] Error :\n" + str(error))

def sendMention1(to, mid, firstmessage, lastmessage):
    try:
        arrData = ""
        text = "%s " %(str(firstmessage))
        arr = []
        mention = "@x "
        slen = str(len(text))
        elen = str(len(text) + len(mention) - 1)
        arrData = {'S':slen, 'E':elen, 'M':mid}
        arr.append(arrData)
        text += mention + str(lastmessage)
        cl.sendMessage(to, text, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)                     
    except Exception as error:
        cl.sendMessage(to, "[ INFO ] Error :\n" + str(error))

def sendTemplates(to, data):
    data = data
    url = "https://api.line.me/message/v3/share"
    headers = {}
    headers['User-Agent'] = 'Mozilla/5.0 (Linux; Android 8.1.0; Redmi Note 5 Build/OPM1.171019.011; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/67.0.3396.87 Mobile Safari/537.36 Line/8.1.1'  
    headers['Content-Type'] = 'application/json'  
    headers['Authorization'] = 'Bearer eyJhbGciOiJIUzI1NiJ9.5uMcEEHahauPb5_MKAArvGzEP8dFOeVQeaMEUSjtlvMV9uuGpj827IGArKqVJhiGJy4vs8lkkseiNd-3lqST14THW-SlwGkIRZOrruV4genyXbiEEqZHfoztZbi5kTp9NFf2cxSxPt8YBUW1udeqKu2uRCApqJKzQFfYu3cveyk.GoRKUnfzfj7P2uAX9vYQf9WzVZi8MFcmJk8uFrLtTqU'
    sendPost = requests.post(url, data=json.dumps(data), headers=headers)
    print(sendPost)
    return sendPost


def removeCmd(cmd, text):
	key = settings["keyCommand"]
	if settings["setKey"] == False: key = ''
	rmv = len(key + cmd) + 1
	return text[rmv:]  
	
def sendFlex(to, data):
  token = self.issueLiffView(to)
  url = 'https://api.line.me/message/v3/share'
  headers = {
    'Content-Type': 'application/json',
    'Authorization': 'Bearer %s' % token.accessToken
  }
  data = {
    'messages': [data]
  }
  res = requests.post(url, headers=headers, data=json.dumps(data))
  return res
#===============================================================================================
def sendTextTemplate25(to, text):
    data = {
                                       "type": "flex",
                                       "altText": "TEAM TERMUX",
                                       "contents": 
{
"type": "bubble",
"size": "micro",
"body": {
"backgroundColor": "#000000",
"type": "box",
"layout": "vertical",
"contents": [
      {
        "contents": [                   
            {            
            "type": "separator",
            "color": "#ffffff"            
      },
      {
        "type": "separator",
        "color": "#ffffff"  
      },
      {         
         "contents": [
          {
          "type": "separator",
          "color": "#ffffff"   
      },
      {
            "contents": [
              {
              "type": "image",
     "url": "https://media.tenor.com/images/3cfcb167ed18a35f3a52f70e44fdf6c0/tenor.gif",
    "size": "xxs"
          },{
 "type": "text",
"text": "TEAM TERMUX",
"weight": "bold",
"color": "#ccff00",
"size": "xxs",
"flex": 0
},{
"type": "text",
"text": " ™Bₒₜₛ",
"weight": "bold",
"color": "#ccff00",
"size": "xxs",
"flex": 0
},{
"type": "text",
"text": " ᴠᴇʀꜱɪᴏɴ",
"weight": "bold",
"color": "#ccff00",
"size": "xxs",
"flex": 0
      },
      {
    "type": "image",
     "url": "https://media.tenor.com/images/3cfcb167ed18a35f3a52f70e44fdf6c0/tenor.gif",
    "size": "xxs"
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "horizontal"    
      },
      {
        "type": "separator",
         "color": "#ffffff"
         }
            ],
            "type": "box",
            "layout": "horizontal"   
            },
         {
        "type": "separator",
        "color": "#ffffff"
         },
         {
       "contents": [
          {
           "type": "separator",
           "color": "#ffffff"
          },
          {
          "type": "image",
          "url": "https://obs.line-scdn.net/{}".format(cl.getContact(mid).pictureStatus),
"size": "xxs",
      "aspectMode": "cover",
           "action": {
            "type": "uri",
            "uri": "http://line.me/ti/p/~Zul.1.02",
            },
            "flex": 0
          },
          {
        "type": "separator",
        "color": "#ffffff"
      },
      {      
       "contents": [              
          {
"type": "text",
"text": "❒  {}".format(cl.getContact(mid).displayName),
"weight": "bold",
"color": "#33ffff",
#"align": "center",
"size": "xxs",
"flex": 0
},{
"type": "separator",
"color": "#ffffff"
},{
"type": "text",
"text": "📆 "+ datetime.strftime(timeNow,'%Y-%m-%d'),
"weight": "bold",
"color": "#ffffff",
#"align": "center",
"size": "xxs",
"flex": 0
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "vertical"
      },
      {
        "type": "separator",
        "color": "#ffffff"
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "horizontal"
      },
      {
        "type": "separator",
         "color": "#ffffff"
       },
       {     
       "contents": [           
         { 
           "type": "separator",
           "color": "#ffffff"
            },
           {
            "contents": [
              {
          "text": text,
           "size": "xxs",
          # "align": "center",
           "color": "#ccffff",
           "wrap": True,
           "weight": "bold",
           "type": "text"
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "vertical"    
      },
      {
        "type": "separator",
         "color": "#ffffff"
         }
            ],
            "type": "box",
            "layout": "horizontal"   
            },
         {
        "type": "separator",
        "color": "#ffffff"
         },
         {          
        "contents": [
          {
            "type": "separator",
            "color": "#ffffff"
            },
             {
            "type": "image",
            "url": "https://i.ibb.co.com/XWQd8rj/20190625-201419.png",
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "https://youtube.com"
            },
            "flex": 1
          },
          {
          "type": "image",
            "url": "https://i.ibb.co.com/b53ztTR/20190427-191019.png", #linehttps://icon-icons.com/icons2/70/PNG/512/line_14096.png", #line
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "http://line.me/ti/p/~Zul.1.02",             
           }, 
            "flex": 1            
          },
          {
        "type": "image",
            "url": "https://i.ibb.co.com/kSMSnWn/20190427-191235.png", #camerahttps://i.ibb.co.com/hVWDsp8/20190428-232907.png", #smulehttps://i.ibb.co.com/8YfQVtr/20190427-185626.png", #callinghttps://kepriprov.go.id/assets/img/icon/phone.png", #phone
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "http://line.me/ti/p/~Zul.1.02"
          },
            "flex": 1
            },
          {
          "type": "image",
            "url": "https://i.ibb.co.com/CntKh4x/20190525-152240.png", #smule
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "Https://smule.com/Zul_moko",
            },         
            "flex": 1          
          },
          {
          "type": "image",
            "url": "https://i.ibb.co.com/Wf8bQ2Z/20190625-105354.png",
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "http://line.me/ti/p/~Zul.1.02"
            },
            "flex": 1
            },
            {
            "contents": [
            {
            "type": "image",
            "url": "https://i.ibb.co.com/1sGhJdC/20190428-232658.png",
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "http://line.me/ti/p/~Zul.1.02"
            },
            "flex": 1
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "vertical"    
      },
      {
        "type": "separator",
         "color": "#ffffff"
         }
            ],
            "type": "box",
            "layout": "horizontal"   
            },
         {
        "type": "separator",
        "color": "#ffffff"
          }
        ],
        "type": "box",
        "layout": "vertical"
      }
    ],
    "type": "box",
    "spacing": "xs",
    "layout": "vertical"
  }
}
}
    cl.postTemplate(to, data)
#=================================================================
def sendTextTemplate(to, text):
    data = {
                                       "type": "flex",
                                       "altText": "TEAM TERMUX",
                                       "contents": 
{
"type": "bubble",
"size": "micro",
"body": {
"backgroundColor": "#000000",
"type": "box",
"layout": "vertical",
    "contents": [
      {
        "contents": [
          {
            "contents": [
             {
            "type": "separator",
            "color": "#ffffff"            
            },
            {
            "contents": [
            {
            "type": "separator",
            "color": "#ffffff" 
   },
   {
            "text": text,
           "size": "xxs",
           "color": "#FFFFFF",
           "wrap": True,
           "weight": "bold",
           "type": "text"
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "vertical"    
      },
      {
        "type": "separator",
         "color": "#ffffff"
         }
            ],
            "type": "box",
            "layout": "horizontal"   
            },
         {
        "type": "separator",
        "color": "#ffffff"
          }
        ],
        "type": "box",
        "layout": "vertical"
      }
    ],
    "type": "box",
    "spacing": "xs",
    "layout": "vertical"
  }
}
}
    cl.postTemplate(to, data)
                                       	
def sendFooter(to, isi):
    data = {
        "type": "text",
        "text": isi,
        "sentBy": {
            "label": "TEAM TERMUX",
            "iconUrl": "https://i.pinimg.com/originals/e2/c2/76/e2c2768a11e8c4858bf0aec9f0311265.gif",
            "linkUrl": "line://nv/profilePopup/mid=u1aaf34421b7a8a94e0a977095e4ff605"
        }
    }
    cl.postTemplate(to, data)
    
def sendFooter1(to, isi):
    data = {
        "type": "text",
        "text": isi,
        "sentBy": {
            "label": "TEAM TERMUX",
            "iconUrl": "https://i.pinimg.com/originals/e2/c2/76/e2c2768a11e8c4858bf0aec9f0311265.gif",
            "linkUrl": "line://nv/profilePopup/mid=u1aaf34421b7a8a94e0a977095e4ff605"
        }
    }
    cl.postTemplate(to, data)
    
def sendFooter2(to, isi):
    data = {
        "type": "text",
        "text": isi,
        "sentBy": {
            "label": "TEAM TERMUX",
            "iconUrl": "https://i.pinimg.com/originals/e2/c2/76/e2c2768a11e8c4858bf0aec9f0311265.gif",
            "linkUrl": "line://nv/profilePopup/mid=u1aaf34421b7a8a94e0a977095e4ff605"
        }
    }
    cl.postTemplate(to, data)

def sendTextSeting(to, text):
    data = {
                                        "type": "flex",
                                        "altText": "TEAM TERMUX",
                                        "contents": {

  "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://i.ibb.co.com/3kTMsnR/ezgif-com-gif-maker.png",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:5",
            "gravity": "top",
            "animated": True
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [],
            "width": "152px",
            "height": "390px",
            "borderColor": "#00FFFF",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "position": "absolute",
            "offsetTop": "3px",
            "offsetStart": "3px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [],
            "borderColor": "#00FFFF",
            "borderWidth": "1px",
            "cornerRadius": "2px",
            "width": "60px",
            "height": "40px",
            "position": "absolute",
            "offsetTop": "3px",
            "offsetStart": "3px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [],
            "width": "93px",
            "height": "20px",
            "borderColor": "#00FFFF",
            "borderWidth": "1px",
            "cornerRadius": "2px",
            "position": "absolute",
            "offsetTop": "3px",
            "offsetStart": "62px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [],
            "borderColor": "#00FFFF",
            "borderWidth": "1px",
            "cornerRadius": "2px",
            "width": "152px",
            "height": "329px",
            "position": "absolute",
            "offsetTop": "42px",
            "offsetStart": "3px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://obs.line-scdn.net/{}".format(cl.getContact(mid).pictureStatus),
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "position": "absolute",
            "borderColor": "#FF1493",
            "borderWidth": "1px",
            "cornerRadius": "2px",
            "width": "58px",
            "height": "38px",
            "offsetTop": "4px",
            "offsetStart": "4px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "TEAM TERMUX",
                "size": "xxs",
                "color": "#FFFFFF",
                "style": "italic",
                "offsetTop": "1px",
                "offsetStart": "15px"
              }
            ],
            "position": "absolute",
            "height": "19px",
            "width": "91px",
            "borderWidth": "1px",
            "cornerRadius": "2px",
            "borderColor": "#FF1493",
            "offsetTop": "23px",
            "offsetStart": "63px",
            "backgroundColor": "#800080"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": " {}".format(cl.getContact(mid).displayName),
                "size": "xxs",
                "style": "italic",
                "color": "#FFFFFF",
                "offsetStart": "8px"
              }
            ],
            "position": "absolute",
            "width": "91px",
            "height": "18px",
            "borderColor": "#FF1493",
            "borderWidth": "1px",
            "cornerRadius": "2px",
            "offsetTop": "4px",
            "offsetStart": "63px",
            "backgroundColor": "#800000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://obs.line-scdn.net/{}".format(cl.getContact(mid).pictureStatus),
                "size": "full",
                "aspectMode": "cover",
                "aspectRatio": "2:5"
              }
            ],
            "borderColor": "#FF1493",
            "borderWidth": "1px",
            "cornerRadius": "2px",
            "width": "150px",
            "height": "326px",
            "position": "absolute",
            "offsetTop": "44px",
            "offsetStart": "4px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": text,
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "1px",
                "offsetStart": "2px",
                "wrap": True
              }
            ],
            "cornerRadius": "2px",
            "borderWidth": "1px",
            "borderColor": "#00FFFF",
            "width": "148px",
            "height": "323px",
            "position": "absolute",
            "offsetTop": "45px",
            "offsetStart": "5px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "♻ SETTING BOTS ♻",
                "size": "xxs",
                "color": "#FFFFFF",
                "style": "italic",
                "offsetTop": "2px",
                "offsetStart": "25px"
              }
            ],
            "position": "absolute",
            "width": "149px",
            "height": "21px",
            "borderWidth": "1px",
            "cornerRadius": "2px",
            "borderColor": "#FF1493",
            "offsetTop": "371px",
            "offsetStart": "5px",
            "backgroundColor": "#000000"
          }
        ],
        "paddingAll": "0px",
        "borderColor": "#00FFFF",
        "borderWidth": "1px",
        "cornerRadius": "10px",
        "action": {
          "type": "uri",
          "label": "action",
          "uri": "http://line.me/ti/p/~Zul.1.02",
        }
      }
    }
  ]
}
}
    cl.postTemplate(to, data)

def sendTextTemplate1(to, text):
    data = {
                                        "type": "flex",
                                        "altText": "TEAM TERMUX",
                                        "contents": {
    "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://i.ibb.co.com/3kTMsnR/ezgif-com-gif-maker.png",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:1",
            "gravity": "top",
            "action": {
              "type": "uri",
              "label": "action",
              "uri": "http://line.me/ti/p/~Zul.1.02",
            },
            "animated": True
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [],
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "cornerRadius": "2px",
            "width": "150px",
            "height": "70px",
            "position": "absolute",
            "offsetTop": "4px",
            "offsetStart": "4px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://obs.line-scdn.net/{}".format(cl.getContact(mid).pictureStatus),
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "position": "absolute",
            "width": "60px",
            "height": "50px",
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "cornerRadius": "2px",
            "offsetTop": "4px",
            "offsetStart": "4px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": text,
                "color": "#FFFFFF",
                "style": "italic",
                "size": "xxs",
                "offsetTop": "1px",
                "offsetStart": "21px"
              }
            ],
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "cornerRadius": "2px",
            "width": "150px",
            "height": "21px",
            "position": "absolute",
            "offsetTop": "53px",
            "offsetStart": "4px",
            "backgroundColor": "#8B0000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "TEAM TERMUX",
                "size": "xxs",
                "color": "#FFFFFF",
                "style": "italic",
                "offsetTop": "2px",
                "offsetStart": "10px"
              }
            ],
            "borderColor": "#FFFF00",
            "cornerRadius": "2px",
            "borderWidth": "1px",
            "position": "absolute",
            "width": "91px",
            "height": "20px",
            "offsetTop": "4px",
            "offsetStart": "63px",
            "backgroundColor": "#800000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [],
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "cornerRadius": "2px",
            "width": "91px",
            "height": "31px",
            "position": "absolute",
            "offsetTop": "23px",
            "offsetStart": "63px",
            "backgroundColor": "#000000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://i.ibb.co.com/fvx0z0Q/20190925-164758.png",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "width": "20px",
            "height": "20px",
            "borderWidth": "1px",
            "cornerRadius": "100px",
            "position": "absolute",
            "borderColor": "#FFFF00",
            "offsetTop": "28px",
            "offsetStart": "68px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://i.ibb.co.com/ypkDngF/20190925-164247.png",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "cornerRadius": "100px",
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "width": "20px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "28px",
            "offsetStart": "99px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://i.ibb.co.com/F0yX5Yt/20190925-164610.png",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "cornerRadius": "100px",
            "width": "20px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "28px",
            "offsetStart": "130px"
          }
        ],
        "paddingAll": "0px",
        "borderColor": "#00FF00",
        "cornerRadius": "10px",
        "borderWidth": "1px",
        "action": {
          "type": "uri",
          "label": "action",
          "uri": "http://line.me/ti/p/~Zul.1.02",
        }
      }
    }
  ]
}
}
    cl.postTemplate(to, data)

def desy_raka(to, text):
    data = {
                                       "type": "flex",
                                       "altText": "TEAM TERMUX",
                                       "contents": 
{
  "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcThFXcTIivOqMDddGG4R3wTXrx0ggxydsMtdw&usqp=CAU",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:3",
            "gravity": "top"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "NOTIFSMULE",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "35px"
              }
            ],
            "borderColor": "#00FFFF",
            "cornerRadius": "5px",
            "borderWidth": "1px",
            "width": "140px",
            "height": "20px",
            "position": "absolute",
            "offsetStart": "8px",
            "offsetTop": "2px",
            "backgroundColor": "#9400D3"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "❒   "+ datetime.strftime(timeNow,'%H:%M:%S'),
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "2px"
              }
            ],
            "borderColor": "#00FFFF",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "position": "absolute",
            "width": "60px",
            "height": "20px",
            "offsetTop": "25px",
            "offsetStart": "2px",
            "backgroundColor": "#008000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "✬  "+ datetime.strftime(timeNow,'%Y-%m-%d'),
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "2px"
              }
            ],
            "borderColor": "#00FFFF",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "width": "88px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "25px",
            "offsetStart": "65px",
            "backgroundColor": "#FF1493"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [],
            "cornerRadius": "5px",
            "borderColor": "#FF00FF",
            "borderWidth": "1px",
            "width": "110px",
            "height": "80px",
            "position": "absolute",
            "offsetTop": "50px",
            "offsetStart": "2px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://obs.line-scdn.net/{}".format(cl.getContact(mid).pictureStatus),
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "width": "108px",
            "height": "78px",
            "position": "absolute",
            "offsetTop": "51px",
            "offsetStart": "3px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [],
            "borderColor": "#00FF00",
            "cornerRadius": "5px",
            "borderWidth": "1px",
            "width": "40px",
            "height": "80px",
            "position": "absolute",
            "offsetStart": "114px",
            "offsetTop": "50px",
            "backgroundColor": "#FF00FF"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcRAkM4XtVrtzz44TdtByTMMxs-kQVK7KIxS1Q&usqp=CAU",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#00FF00",
            "borderWidth": "1px",
            "cornerRadius": "100px",
            "width": "20px",
            "height": "20px",
            "position": "absolute",
            "offsetStart": "125px",
            "offsetTop": "55px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://play-lh.googleusercontent.com/74iMObG1vsR3Kfm82RjERFhf99QFMNIY211oMvN636_gULghbRBMjpVFTjOK36oxCbs",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "cornerRadius": "100px",
            "borderColor": "#00FF00",
            "borderWidth": "1px",
            "width": "20px",
            "height": "20px",
            "position": "absolute",
            "offsetStart": "125px",
            "offsetTop": "80px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcTmv9sQl2NjL2aqXRmnOplfq-e4kzt31yACZg&usqp=CAU",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#00FF00",
            "borderWidth": "1px",
            "cornerRadius": "100px",
            "height": "20px",
            "width": "20px",
            "position": "absolute",
            "offsetStart": "125px",
            "offsetTop": "105px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "✬  {}".format(cl.getContact(mid).displayName),
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "2px"
              }
            ],
            "position": "absolute",
            "width": "149px",
            "height": "20px",
            "borderWidth": "1px",
            "borderColor": "#FFFFFF",
            "cornerRadius": "5px",
            "offsetTop": "135px",
            "offsetStart": "2px",
            "backgroundColor": "#000000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "Bagus Ocnyah kk nanti Aku Join Yah Tunggu Ajah Yah",
                "size": "xxs",
                "color": "#FFFFFF",
                "wrap": True,
                "offsetTop": "8px",
                "offsetStart": "4px"
              }
            ],
            "borderColor": "#40E0D0",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "position": "absolute",
            "width": "150px",
            "height": "50px",
            "offsetTop": "158px",
            "offsetStart": "3px",
            "backgroundColor": "#000000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "SELFBOT TEMPLATE V3",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "9px"
              }
            ],
            "borderWidth": "1px",
            "borderColor": "#C71585",
            "cornerRadius": "5px",
            "width": "150px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "210px",
            "offsetStart": "4px",
            "backgroundColor": "#0000CD"
          }
        ],
        "paddingAll": "0px",
        "borderColor": "#9400D3",
        "borderWidth": "2px",
        "cornerRadius": "10px",
        "action": {
          "type": "uri",
          "label": "action",
          "uri": "http://line.me/ti/p/~Zul.1.02"
        }
      }
    }
  ]
}
}
    cl.postTemplate(to, data)
    
def sendTextTemplate2(to, text):
    data = {
                                       "type": "flex",
                                       "altText": "TEAM TERMUX",
                                       "contents": 
{
"type": "bubble",
"size": "nano",
"body": {
"backgroundColor": "#000000",
"type": "box",
"layout": "vertical",
"contents": [
{
"contents": [
{
"type": "separator",
"color": "#000000"
},{
"type": "separator",
"color": "#000000"
},{
"contents": [
{
"type": "separator",
"color": "#80FF00"
},{
"contents": [
{
"text": "TEAM TERMUX",
"size": "xxs",
"align": "center",
"color": "#FFFFFF",
"wrap": True,
"weight": "bold",
"type": "text"
}],
"type": "box",
"spacing": "xs",
"layout": "vertical"
},{
"type": "separator",
"color": "#000000"
}],
"type": "box",
"layout": "horizontal"
},{
"type": "separator",
"color": "#000000"
},{
"contents": [
{
"type": "separator",
"color": "#000000"
},{
"contents": [
{
"text": text,
"size": "xxs",
#"align": "center",
"color": "#FFFFFF",
"wrap": True,
"weight": "bold",
"type": "text"
}],
"type": "box",
"spacing": "xs",
"layout": "vertical"
},{
"type": "separator",
"color": "#000000"
}],
"type": "box",
"layout": "horizontal"
},{
"type": "separator",
"color": "#000000"
},{
"contents": [
          {
            "type": "separator",
            "color": "#80FF00"
            },
             {
            "type": "image",
            "url": "https://i.ibb.co.com/XWQd8rj/20190625-201419.png",
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "https://youtube.com"
            },
            "flex": 1
          },
          {
          "type": "image",
            "url": "https://i.ibb.co.com/b53ztTR/20190427-191019.png", #linehttps://icon-icons.com/icons2/70/PNG/512/line_14096.png", #line
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "http://line.me/ti/p/~Zul.1.02",             
           }, 
            "flex": 1            
          },
          {
        "type": "image",
            "url": "https://i.ibb.co.com/kSMSnWn/20190427-191235.png", #camerahttps://i.ibb.co.com/hVWDsp8/20190428-232907.png", #smulehttps://i.ibb.co.com/8YfQVtr/20190427-185626.png", #callinghttps://kepriprov.go.id/assets/img/icon/phone.png", #phone
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "line://nv/camera/"
          },
            "flex": 1
            },
          {
          "type": "image",
            "url": "https://i.ibb.co.com/CntKh4x/20190525-152240.png", #smule
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "Https://smule.com/Zul_moko",
            },         
            "flex": 1          
          },
          {
          "type": "image",
            "url": "https://i.ibb.co.com/Wf8bQ2Z/20190625-105354.png",
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "line://nv/cameraRoll/multi"
            },
            "flex": 1
            },
            {
            "contents": [
            {
            "type": "image",
            "url": "https://i.ibb.co.com/1sGhJdC/20190428-232658.png",
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "http://line.me/ti/p/~Zul.1.02"
            },
            "flex": 1
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "vertical"    
      },
      {
        "type": "separator",
         "color": "#80FF00"
         }
            ],
            "type": "box",
            "layout": "horizontal"   
            },
         {
        "type": "separator",
        "color": "#80FF00"
          }
        ],
        "type": "box",
        "layout": "vertical"
      }
    ],
    "type": "box",
    "spacing": "xs",
    "layout": "vertical"
  }
}
}
    cl.postTemplate(to, data)
    
def sendTextTemplate23(to, text):
    data = {
                                       "type": "flex",
                                       "altText": "TEAM TERMUX",
                                       "contents": 
{
  "type": "bubble",
"size": "micro",
"body": {
"backgroundColor": "#00008B",
"type": "box",
"layout": "vertical",
"contents": [
      {
        "contents": [                   
            {            
            "type": "separator",
            "color": "#800080"            
      },
      {
        "type": "separator",
        "color": "#800080"  
      },
      {         
         "contents": [
          {
          "type": "separator",
          "color": "#800080"   
      },
      {
            "contents": [
              {
              "type": "image",
     "url": "https://stickershop.line-scdn.net/stickershop/v1/product/6332071/LINEStorePC/main.png;compress=true",
    "size": "xxs"
          },{
 "type": "text",
"text": "TEAM TERMUX",
"weight": "bold",
"color": "#FFFFFF",
"size": "xxs",
"flex": 0
},{
"type": "text",
"text": "𝓑𝓸𝓽𝓼",
"weight": "bold",
"color": "#FFFFFF",
"size": "xxs",
"flex": 0
},{
"type": "text",
"text": "𝓿𝓮𝓻𝓼𝓲𝓸𝓷",
"weight": "bold",
"color": "#FFFFFF",
"size": "xxs",
"flex": 0
      },
      {
    "type": "image",
     "url": "https://stickershop.line-scdn.net/stickershop/v1/product/6332071/LINEStorePC/main.png;compress=true",
    "size": "xxs"
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "horizontal"    
      },
      {
        "type": "separator",
         "color": "#800080"
         }
            ],
            "type": "box",
            "layout": "horizontal"   
            },
         {
        "type": "separator",
        "color": "#800080"
         },
         {
       "contents": [
          {
           "type": "separator",
           "color": "#800080"
          },
          {
          "type": "image",
          "url": "https://obs.line-scdn.net/{}".format(cl.getContact(mid).pictureStatus),
"size": "xxs",
      "aspectMode": "cover",
           "action": {
            "type": "uri",
            "uri": "http://line.me/ti/p/~Zul.1.02",
            },
            "flex": 0
          },
          {
        "type": "separator",
        "color": "#800080"
      },
      {      
       "contents": [              
          {
"type": "text",
"text": "🌺  {}".format(cl.getContact(mid).displayName),
"weight": "bold",
"color": "#FFFFFF",
#"align": "center",
"size": "xxs",
"flex": 0
},{
"type": "separator",
"color": "#ffffff"
},{
"type": "text",
"text": "🌺  "+ datetime.strftime(timeNow,'%Y-%m-%d'),
"weight": "bold",
"color": "#ffffff",
#"align": "center",
"size": "xxs",
"flex": 0
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "vertical"
      },
      {
        "type": "separator",
        "color": "#800080"
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "horizontal"
      },
      {
        "type": "separator",
         "color": "#800080"
       },
       {     
       "contents": [           
         { 
           "type": "separator",
           "color": "#800080"
            },
           {
            "contents": [
              {
          "text": text,
           "size": "xxs",
          # "align": "center",
           "color": "#FFFFFF",
           "wrap": True,
           "weight": "bold",
           "type": "text"
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "vertical"    
      },
      {
        "type": "separator",
         "color": "#800080"
         }
            ],
            "type": "box",
            "layout": "horizontal"   
            },
         {
        "type": "separator",
        "color": "#800080"
         },
         {          
        "contents": [
          {
            "type": "separator",
            "color": "#800080"
            },
             {
            "type": "image",
               "url": "https://i.ibb.co.com/XWQd8rj/20190625-201419.png",
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "https://youtube.com"
            },
            "flex": 1
          },
          {
          "type": "image",
          "url": "https://i.ibb.co.com/b53ztTR/20190427-191019.png", #linehttps://icon-icons.com/icons2/70/PNG/512/line_14096.png", #line
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "http://line.me/ti/p/~Zul.1.02",             
           }, 
            "flex": 1            
          },
          {
        "type": "image",
            "url": "https://i.ibb.co.com/kSMSnWn/20190427-191235.png", #camerahttps://i.ibb.co.com/hVWDsp8/20190428-232907.png", #smulehttps://i.ibb.co.com/8YfQVtr/20190427-185626.png", #callinghttps://kepriprov.go.id/assets/img/icon/phone.png", #phone
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "line://nv/camera/"
          },
            "flex": 1
            },
          {
          "type": "image",
            "url": "https://i.ibb.co.com/CntKh4x/20190525-152240.png", #smule
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "Https://smule.com/Zul_moko",
            },         
            "flex": 1          
          },
          {
          "type": "image",
          "url": "https://i.ibb.co.com/Wf8bQ2Z/20190625-105354.png",
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "line://nv/cameraRoll/multi"
            },
            "flex": 1
            },
            {
            "contents": [
            {
            "type": "image",
            "url": "https://i.ibb.co.com/1sGhJdC/20190428-232658.png",
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "http://line.me/ti/p/~Zul.1.02"
            },
            "flex": 1
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "vertical"    
      },
      {
        "type": "separator",
         "color": "#800080"
         }
            ],
            "type": "box",
            "layout": "horizontal"   
            },
         {
        "type": "separator",
        "color": "#800080"
          }
        ],
        "type": "box",
        "layout": "vertical"
      }
    ],
    "type": "box",
    "spacing": "xs",
    "layout": "vertical"
  }
}
}
    cl.postTemplate(to, data)
    
    
    
def sendTextTemplate00(to, text):
    data = {
                                       "type": "flex",
                                       "altText": "TEAM TERMUX",
                                       "contents": 
{
"type": "bubble",
"size": "micro",
"body": {
"backgroundColor": "#008B8B",
"type": "box",
"layout": "vertical",
  "contents": [
      {
        "contents": [                   
            {            
            "type": "separator",
            "color": "#ffffff"            
      },
      {
        "type": "separator",
        "color": "#ffffff"  
      },
      {         
         "contents": [
          {
          "type": "separator",
          "color": "#ffffff"   
      },
      {
            "contents": [
              {
              "type": "image",
     "url": "https://media.tenor.com/images/3cfcb167ed18a35f3a52f70e44fdf6c0/tenor.gif",
    "size": "xxs"
          },{
 "type": "text",
"text": "™Bₒₜₛ",
"weight": "bold",
"color": "#FFFFFF",
"size": "xxs",
"flex": 0
},{
"type": "text",
"text": "SB TEAM TERMUX ",
"weight": "bold",
"color": "#FFFFFF",
"size": "xxs",
"flex": 0
},{
"type": "text",
"text": "ᴠᴇʀꜱɪᴏɴ",
"weight": "bold",
"color": "#FFFFFF",
"size": "xxs",
"flex": 0
      },
      {
    "type": "image",
     "url": "https://media.tenor.com/images/3cfcb167ed18a35f3a52f70e44fdf6c0/tenor.gif",
    "size": "xxs"
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "horizontal"    
      },
      {
        "type": "separator",
         "color": "#FFFFFF"
         }
            ],
            "type": "box",
            "layout": "horizontal"   
            },
         {
        "type": "separator",
        "color": "#FFFFFF"
         },
         {
       "contents": [
         {
        "type": "separator",
        "color": "#FFFFFF"
         },
         {
            "text": "📔📔📔",
            "size": "xxs",
            "color": "#FFFFFF",
            "align": "center",
            "wrap": True,
            "weight": "bold",
            "type": "text"
            },{
            "type": "separator",
            "color": "#ffffff"
           },
             {
            "text": "📔📔📔",
            "size": "xxs",
            "color": "#FFFFFF",
            "align": "center",
            "wrap": True,
            "weight": "bold",
            "type": "text"
            },{
            "type": "separator",
            "color": "#ffffff"
           },
             {
            "text": "📘📘📘",
            "size": "xxs",
            "color": "#FFFFFF",
            "align": "center",
            "wrap": True,
            "weight": "bold",
            "type": "text"   
            },
         {
        "type": "separator",
        "color": "#ffffff"
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "horizontal"    
      },
      {
        "type": "separator",
         "color": "#ffffff"
         },
         {
       "contents": [
          {
           "type": "separator",
           "color": "#ffffff"
          },
          {
          "url": "https://obs.line-scdn.net/{}".format(cl.getContact(mid).pictureStatus),
            "type": "image",
            "size": "xxs",
            "flex": 0
          },
          {
        "type": "separator",
        "color": "#ffffff"
      },
      {      
       "contents": [              
          {
"type": "text",
"text": "TEAM TERMUX",
"weight": "bold",
"color": "#FFFFFF",
"align": "center",
"size": "xxs",
"flex": 0
},{
"type": "separator",
"color": "#ffffff"
},{
"type": "text",
"text": "⏰"+ datetime.strftime(timeNow,'%H:%M:%S'+"⏰"),
"weight": "bold",
"color": "#ffffff",
"align": "center",
"size": "xxs",
"flex": 0
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "vertical"
      },
      {
        "type": "separator",
        "color": "#ffffff"
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "horizontal"
      },
      {
        "type": "separator",
         "color": "#ffffff"
       },
       {     
       "contents": [           
         { 
           "type": "separator",
           "color": "#ffffff"
            },
           {
            "contents": [
              {
              "type": "separator",
           "color": "#ffffff"
            },
           {
          "type": "text",
"text": "{}".format(cl.getContact(mid).displayName),
"weight": "bold",
"color": "#FFFFFF",
"align": "center",
"size": "xxs",
"flex": 0
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "vertical"    
      },
      {
        "type": "separator",
         "color": "#ffffff"
         }
            ],
            "type": "box",
            "layout": "horizontal"   
            },
         {
        "type": "separator",
        "color": "#ffffff"
         },
         {          
         "contents": [
         { 
           "type": "separator",
           "color": "#ffffff"
            },
           {
            "contents": [
              {
              "type": "separator",
           "color": "#ffffff"
            },
           {
          "text": text,
           "size": "xxs",
          #"align": "center",
           "color": "#FFFFFF",
           "wrap": True,
           "weight": "bold",
           "type": "text"
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "vertical"    
      },
      {
        "type": "separator",
         "color": "#ffffff"
         }
            ],
            "type": "box",
            "layout": "horizontal"   
            },
         {
        "type": "separator",
        "color": "#ffffff"
         },
         {
       "contents": [
         {
        "type": "separator",
        "color": "#ffffff"
         },
         {
            "text": "📘📘📘",
            "size": "xxs",
            "color": "#FFFFFF",
            "align": "center",
            "wrap": True,
            "weight": "bold",
            "type": "text"
            },{
            "type": "separator",
            "color": "#ffffff"
           },
             {
            "text": "📕📕📕",
            "size": "xxs",
            "color": "#FFFFFF",
            "align": "center",
            "wrap": True,
            "weight": "bold",
            "type": "text"
            },{
            "type": "separator",
            "color": "#ffffff"
           },
             {
            "text": "📔📔📔",
            "size": "xxs",
            "color": "#FFFFFF",
            "align": "center",
            "wrap": True,
            "weight": "bold",
            "type": "text"   
          },
         {
        "type": "separator",
        "color": "#ffffff"
         }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "horizontal"    
      },
      {
        "type": "separator",
         "color": "#ffffff"
         },
         {
      "contents": [
          {
            "type": "separator",
            "color": "#ffffff"
            },
             {
            "type": "image",
            "url": "https://i.ibb.co.com/XWQd8rj/20190625-201419.png",
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "https://youtube.com",
           }, 
            "flex": 1
          },
          {
          "type": "image",
            "url": "https://i.ibb.co.com/b53ztTR/20190427-191019.png", #linehttps://icon-icons.com/icons2/70/PNG/512/line_14096.png", #line
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "http://line.me/ti/p/~Zul.1.02",             
           }, 
            "flex": 1            
          },
          {
          "type": "image",
            "url": "https://i.ibb.co.com/ZHtFDts/20190427-185307.png", #chathttps://i.ibb.co.com/b53ztTR/20190427-191019.png", #linehttps://icon-icons.com/icons2/70/PNG/512/line_14096.png", #line
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "line://nv/chat" #"http://line.me/ti/p/~Zul.1.02",
            },         
            "flex": 1          
            },
          {
          "type": "image",
            "url": "https://i.ibb.co.com/CntKh4x/20190525-152240.png", #smule
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "Https://smule.com/Zul_moko",
            },         
            "flex": 1          
          },
          {
          "type": "image",
            "url": "https://i.ibb.co.com/Wf8bQ2Z/20190625-105354.png",
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "line://nv/cameraRoll/multi"
            },
            "flex": 1
            },
            {
            "contents": [
            {
            "type": "image",
            "url": "https://i.ibb.co.com/1sGhJdC/20190428-232658.png",
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "http://line.me/ti/p/~Zul.1.02"
          },
            "flex": 1           
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "vertical"    
      },
      {
        "type": "separator",
         "color": "#ffffff"
         }
            ],
            "type": "box",
            "layout": "horizontal"   
            },
         {
        "type": "separator",
        "color": "#ffffff"
        },{
        "contents": [         
              {
            "type": "separator",
            "color": "#ffffff"
            },
             {          
            "contents": [
               {
    "type": "image",
    "url": "https://media.tenor.com/images/3cfcb167ed18a35f3a52f70e44fdf6c0/tenor.gif",
    "size": "xxs"
    },{
 "type": "text",
"text": "™Bₒₜₛ",
"weight": "bold",
"color": "#FFFFFF",
"size": "xxs",
"flex": 0
},{
"type": "text",
"text": "SB TEAM TERMUX ",
"weight": "bold",
"color": "#FFFFFF",
"size": "xxs",
"flex": 0
},{
"type": "text",
"text": "ʙᴏᴛꜱ",
"weight": "bold",
"color": "#FFFFFF",
"size": "xxs",
"flex": 0
      },
      {
    "type": "image",
    "url": "https://media.tenor.com/images/3cfcb167ed18a35f3a52f70e44fdf6c0/tenor.gif",
    "size": "xxs"
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "horizontal"    
      },
      {
        "type": "separator",
         "color": "#ffffff"
         }
            ],
            "type": "box",
            "layout": "horizontal"   
            },
         {
        "type": "separator", #batas APK
        "color": "#ffffff"     
          }
        ],
        "type": "box",
        "layout": "vertical"
      }
    ],
    "type": "box",
    "spacing": "xs",
    "layout": "vertical"
  }
}
}
    cl.postTemplate(to, data)
   #Def Musik

def sendTextRaka(to, text):
    data = {
                                       "type": "flex",
                                       "altText": "TEAM TERMUX",
                                       "contents": 
{
  "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://i.ibb.co.com/Gcy4K6Q/ezgif-com-gif-to-apng-10.png",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:1",
            "gravity": "top",
            "animated": True
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [],
            "position": "absolute",
            "borderColor": "#00FFFF",
            "borderWidth": "1px",
            "cornerRadius": "2px",
            "width": "148px",
            "height": "70px",
            "offsetTop": "4px",
            "offsetStart": "5px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [],
            "position": "absolute",
            "borderColor": "#00FFFF",
            "cornerRadius": "2px",
            "borderWidth": "1px",
            "width": "70px",
            "height": "50px",
            "offsetTop": "4px",
            "offsetStart": "5px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://obs.line-scdn.net/{}".format(cl.getContact(mid).pictureStatus),
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FF1493",
            "borderWidth": "1px",
            "cornerRadius": "1px",
            "width": "67px",
            "height": "48px",
            "position": "absolute",
            "offsetTop": "5px",
            "offsetStart": "7px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [],
            "borderColor": "#00FFFF",
            "borderWidth": "1px",
            "cornerRadius": "1px",
            "position": "absolute",
            "width": "148px",
            "height": "21px",
            "offsetTop": "53px",
            "offsetStart": "5px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "NOTIF SMULE RECORD",
                "size": "xxs",
                "style": "italic",
                "color": "#FFFFFF",
                "offsetTop": "1px",
                "offsetStart": "18px"
              }
            ],
            "borderWidth": "1px",
            "borderColor": "#FF0000",
            "cornerRadius": "2px",
            "width": "146px",
            "height": "19px",
            "position": "absolute",
            "offsetTop": "54px",
            "offsetStart": "6px",
            "backgroundColor": "#000080"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "™ TEAM TERMUX ™",
                "size": "xxs",
                "color": "#FFFFFF",
                "style": "italic",
                "offsetTop": "2px",
                "offsetStart": "10px"
              }
            ],
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "cornerRadius": "2px",
            "width": "77px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "5px",
            "offsetStart": "75px",
            "backgroundColor": "#800000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "PLAY SONG",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "6px",
                "offsetStart": "9px"
              }
            ],
            "borderColor": "#00FF00",
            "cornerRadius": "2px",
            "borderWidth": "1px",
            "width": "77px",
            "height": "28px",
            "offsetTop": "25px",
            "position": "absolute",
            "offsetStart": "75px",
            "backgroundColor": "#C71585"
          }
        ],
        "paddingAll": "0px",
        "borderColor": "#00FFFF",
        "borderWidth": "1px",
        "cornerRadius": "10px",
        "action": {
          "type": "uri",
          "label": "action",
          "uri": "line://nv/profilePopup/mid=u1aaf34421b7a8a94e0a977095e4ff605",
        }
      }
    }
  ]
}
}
    cl.postTemplate(to, data)
   
def sendFooter10(to, text):
    data = {
                                "type": "flex",
                                "altText": "TEAM TERMUX",
                                "contents": {
"type": "carousel",
"contents": [
{
"type": "bubble",
"size": "nano",
"body": {
"backgroundColor": "#00ff00",
"type": "box",
"layout": "vertical",
"contents": [
{
"type": "image", #Wall 1
"url": "https://content.skyscnr.com/m/7d3992c451e6cf6c/original/color.gif?imbypass=true",
"size": "full",
"aspectMode": "cover",
"aspectRatio": "4:5",
"gravity": "bottom",
"action": {
"uri": "line://nv/profilePopup/mid=u1aaf34421b7a8a94e0a977095e4ff605",
"type": "uri",
}
},
{
"type": "box",
"layout": "vertical",
"contents": [
{
"type": "image", #Wall 2
"url": "https://content.skyscnr.com/m/7d3992c451e6cf6c/original/color.gif?imbypass=true",
"gravity": "bottom",
"size": "xxl",
"aspectMode": "cover",
"aspectRatio": "2:3",
"offsetTop": "0px",
"action": {
"uri": "line://nv/profilePopup/mid=u1aaf34421b7a8a94e0a977095e4ff605",
"type": "uri",
}
}
],
"position": "absolute",
"cornerRadius": "5px",
"offsetTop": "5px",
"offsetStart": "5px",
"height": "140px",
"width": "110px"
},
{
"type": "box",
"layout": "vertical",
"contents": [
{
"type": "image", #Wall 2
"url": "https://obs.line-scdn.net/{}".format(cl.getContact(mid).pictureStatus),
"gravity": "bottom",
"size": "xxl",
"aspectMode": "cover",
"aspectRatio": "2:3",
"offsetTop": "0px",
"action": {
"uri": "line://nv/profilePopup/mid=u1aaf34421b7a8a94e0a977095e4ff605",
"type": "uri",
}
}
],
"position": "absolute",
"cornerRadius": "5px",
"offsetTop": "5px",
"offsetStart": "5px",
"height": "140px",
"width": "110px"
},
{
"type": "box",
"layout": "vertical",
"contents": [
{
"type": "text",
"text": "Hiburan",
"align": "center",
"color": "#000000",
"weight": "bold",
"size": "xxs",
"weight": "bold",
"offsetTop": "1px"
}
],
"position": "absolute",
"cornerRadius": "5px",
"offsetTop": "9px",
"backgroundColor": "#ffd700",
"offsetStart": "7px",
"height": "15px",
"width": "45px"
},
{
"type": "box",
"layout": "vertical",
"contents": [ #dsini
{
"type": "image",
"url": "https://thumbs.gfycat.com/UnkemptWhiteKakapo-max-1mb.gif",
"size": "xxl",
"action": {
"type": "uri",
"uri": "https://wa.me/085757076639",
},         
"flex": 0
}
],
"position": "absolute",
"offsetTop": "5px",
"offsetStart": "92px",
"height": "43px",
"width": "22px"
},
{
"type": "box",
"layout": "vertical",
"contents": [ #dsini
{
"type": "image",
"url": "https://thumbs.gfycat.com/UnkemptWhiteKakapo-max-1mb.gif",
"size": "xxl",
"action": {
"type": "uri",
"uri": "https://joox.com"
},         
"flex": 0
}
],
"position": "absolute",
"offsetTop": "5px",
"offsetStart": "67px",
"height": "43px",
"width": "22px"
},
{
"type": "box",
"layout": "vertical",
"contents": [ #dsini
{
"type": "image",
"url": "https://i.ibb.co.com/CntKh4x/20190525-152240.png", #smule
"size": "xl",
"action": {
"type": "uri",
"uri": "Https://smule.com/Zul_moko",
},
"flex": 0
},{
"type": "image",
"url": "https://i.ibb.co.com/ZHtFDts/20190427-185307.png",
"size": "xl",
"action": {
"type": "uri",
"uri": "line://nv/chat",
},
"flex": 0
},{
"type": "image",
"url": "https://i.ibb.co.com/b53ztTR/20190427-191019.png", #linehttps://icon-icons.com/icons2/70/PNG/512/line_14096.png", #line
"size": "full",
"action": {
"type": "uri",
"uri": "http://line.me/ti/p/~Zul.1.02",
},
"flex": 0
},{
"type": "image",
"url": "https://i.ibb.co.com/XWQd8rj/20190625-201419.png",
"size": "full",
"action": {
"type": "uri",
"uri": "https://youtube.com",
},
"flex": 0
}
],
"position": "absolute",
"offsetTop": "25px",
"offsetStart": "5px",
"height": "180px",
"width": "25px"
},
{
"type": "box",
"layout": "vertical",
"contents": [
{
"type": "text",
"text": "❒   "+ datetime.strftime(timeNow,'%H:%M:%S'),
"weight": "bold",
"color": "#ffffff",
#"align": "center",
"size": "xxs",
"offsetTop": "0px"
}
],
"position": "absolute",
"cornerRadius": "5px",
"offsetTop": "98px",
"backgroundColor": "#ff0000",
"offsetStart": "50px",
"height": "16px",
"width": "63px"
},
{
"type": "box",
"layout": "vertical",
"contents": [
{
"type": "text",
"text": text, #📆 "+ datetime.strftime(timeNow,'%Y-%m-%d'),
"weight": "bold",
"color": "#ffffff",
"size": "xxs",
"offsetTop": "0px"
}
],
"position": "absolute",
"cornerRadius": "5px",
"offsetTop": "115px",
"backgroundColor": "#0000ff",
"offsetStart": "33px",
"height": "14px",
"width": "80px"
},
{
"type": "box",
"layout": "vertical",
"contents": [
{
"type": "text",
"text": "TEAM TERMUX",
"weight": "bold",
"color": "#00ff00",
"size": "xxs",
"offsetTop": "0px"
}
],
"position": "absolute",
"cornerRadius": "5px",
"offsetTop": "130px",
#"backgroundColor": "#33ffff",
"offsetStart": "8px",
"height": "50px",
"width": "110px"
}
],
#"backgroundColor": "#",
"paddingAll": "0px"
}
},
]
}
}
    cl.postTemplate(to, data)
   
def command(text):
    pesan = text.lower()
    if pesan.startswith(Setmain['keyCommand']):
        cmd = pesan.replace(Setmain['keyCommand'],"")
    else:
        cmd = "command"
    return cmd

def keybot():
    key = Setmain["keyCommand"]
    key = key.title()
    helpMessage = "╭「TEAM TERMUX」\n"+\
                  "╠➣  " + key + "sᴇᴛᴛɪɴɢ\n" + \
                  "╠➣  " + key + "ʜᴇʟᴘ ɢʀᴏᴜᴘ\n" + \
                  "╠➣  " + key + "ʜᴇʟᴘ ᴍᴇᴅɪᴀ\n" + \
                  "╠➣  " + key + "ʜᴇʟᴘ ᴀᴅᴍɪɴ\n" + \
                  "╠➣  " + key + "ʜᴇʟᴘ ᴄʀᴇᴀᴛᴏʀ\n" + \
                  "╠➣  " + key + "ʜᴇʟᴘ sᴇᴛᴛɪɴɢ\n" + \
                  "╰「TEAM TERMUX」"
    return helpMessage

def helpcreator():
    key = Setmain["keyCommand"]
    key = key.title()
    helpMessage1 = "╭「TEAM TERMUX」\n"+\
                  "╠➣ " + key + "ᴍᴇ\n" + \
                  "╠➣ " + key + "ᴄᴠᴘ\n" + \
                  "╠➣ " + key + "sᴇᴛᴛɪɴɢ\n" + \
                  "╠➣ " + key + "ʀᴜɴᴛɪᴍᴇ\n" + \
                  "╠➣ " + key + "sᴘᴇᴇᴅ-sᴘ\n" + \
                  "╠➣ " + key + "sᴀɴᴛᴇᴛ ᴍᴀɴᴛᴀɴ\n" + \
                  "╠➣ " + key + "ʙʏᴇᴍᴇ\n" + \
                  "╠➣ " + key + "ʀᴇᴊᴇᴄᴛ\n" + \
                  "╠➣ " + key + "ʟᴇᴀᴠᴇᴀʟʟ\n" + \
                  "╠➣ " + key + "ʟɪsᴛғʀɪᴇɴᴅ\n" + \
                  "╠➣ " + key + "ғʀɪᴇɴᴅʟɪsᴛ\n" + \
                  "╠➣ " + key + "ɢʀᴜᴘʟɪsᴛ\n" + \
                  "╠➣ " + key + "ᴏᴘᴇɴ ǫʀ\n" + \
                  "╠➣ " + key + "ᴄʟᴏsᴇ ǫʀ\n" + \
                  "╠➣ " + key + "ᴛᴀɢᴀʟʟ\n" + \
                  "╠➣ " + key + ".ɪɴᴠɪᴛᴇ @\n" + \
                  "╠➣ " + key + "ʙʟᴏᴄᴋ「@」\n" + \
                  "╠➣ " + key + "ᴀᴅᴅᴍᴇ「@」\n" + \
                  "╠➣ " + key + "ᴍʏʙᴏᴛ\n" + \
                  "╠➣ " + key + "ʟɪsᴛᴘᴇɴᴅɪɴɢ\n" + \
                  "╠➣ " + key + "ʙʟᴏᴄᴋᴄᴏɴᴛᴀᴄᴛ\n" + \
                  "╠➣ " + key + "ʟɪsᴛʙʟᴏᴄᴋ\n" + \
                  "╠➣ " + key + "ʟɪsᴛᴍɪᴅ\n" + \
                  "╠➣ " + key + "ᴀᴅᴅᴀsɪs\n" + \
                  "╠➣ " + key + "ʙʀᴏᴀᴅᴄᴀsᴛ:「ᴛᴇxᴛ」\n" + \
                  "╠➣ " + key + "ʙʀᴏᴀᴅᴄᴀsᴛ1:「ᴛᴇxᴛ」\n" + \
                  "╰「TEAM TERMUX」"
    return helpMessage1

def helpadmin():
    key = Setmain["keyCommand"]
    key = key.title()
    helpMessage5 = "╭「TEAM TERMUX」\n"+\
                  "╠➣ "  + key + "sᴛᴀғғ「@」\n" + \
                  "╠➣ "  + key + "sᴛᴀғᴅᴇʟʟ「@」\n" + \
                  "╠➣ "  + key + "ᴀᴅᴍɪɴ「@」\n" + \
                  "╠➣ "  + key + "ᴀᴅᴍɪɴᴅᴇʟʟ「@」\n" + \
                  "╠➣ "  + key + "ᴅᴇʟʟғʀɪᴇɴᴅ「@」\n" + \
                  "╠➣ "  + key + "sᴛᴀᴛᴜs:「ᴛᴇxᴛ」\n" + \
                  "╠➣ "  + key + "!ᴄᴀɴᴄᴇʟ「ʙᴏᴍ」\n" + \
                  "╠➣ "  + key + "!ᴊs ɢᴏ\n" + \
                  "╠➣ "  + key + "ʀᴇʙᴏᴏᴛ\n" + \
                  "╠➣ "  + key + "ʙᴀɴ「@」\n" + \
                  "╠➣ "  + key + "ᴋɪᴄᴋ「@」\n" + \
                  "╠➣ "  + key + "ɢᴋɪᴄᴋ「@」\n" + \
                  "╠➣ "  + key + "ʙʟᴄ\n" + \
                  "╠➣ "  + key + "ʙᴀɴ:ᴏɴ\n" + \
                  "╠➣ "  + key + "ᴜɴʙᴀɴ:oɴ\n" + \
                  "╠➣ "  + key + "ᴜɴʙᴀɴ「@」\n" + \
                  "╠➣ "  + key + "ʙᴀɴʟɪsᴛ\n" + \
                  "╠➣ "  + key + "ᴄʙᴀɴ\n" + \
                  "╠➣ "  + key + "ʀᴇғʀᴇsʜ\n" + \
                  "╰「TEAM TERMUX」"
    return helpMessage5
  
def helpgroup():
    key = Setmain["keyCommand"]
    key = key.title()
    helpMessage4 = "╭「TEAM TERMUX」\n"+\
                  "╠➣ " + key + "ɢᴍɪᴅ @\n" + \
                  "╠➣ " + key + "ɢᴇᴛ ɪᴅ @\n" + \
                  "╠➣ " + key + "ɢᴇᴛᴍɪᴅ @\n" + \
                  "╠➣ " + key + "ɢᴇᴛʙɪᴏ @\n" + \
                  "╠➣ " + key + "ɢᴇᴛɪɴғᴏ @\n" + \
                  "╠➣ " + key + "ɢᴇᴛᴘʀᴏғɪʟᴇ @\n" + \
                  "╠➣ " + key + "ɢᴇᴛᴘɪᴄᴛᴜʀᴇ @\n" + \
                  "╠➣ " + key + "ɪɴғᴏ @\n" + \
                  "╠➣ " + key + "ᴋᴇᴘᴏ @\n" + \
                  "╠➣ " + key + "ᴘᴘᴠɪᴅᴇᴏ @\n" + \
                  "╠➣ " + key + "ᴋᴏɴᴛᴀᴋ @\n" + \
                  "╠➣ " + key + "ᴄᴏɴᴛᴀᴄᴛ:「ᴍɪᴅ」\n" + \
                  "╠➣ " + key + "ɢɴᴀᴍᴇ「ᴛᴇxᴛ」\n" + \
                  "╠➣ " + key + "ᴍʏᴍɪᴅ\n" + \
                  "╠➣ " + key + "ᴍʏʙɪᴏ\n" + \
                  "╠➣ " + key + "ᴍʏғᴏᴛᴏ\n" + \
                  "╠➣ " + key + "ᴍʏɴᴀᴍᴇ\n" + \
                  "╠➣ " + key + "ᴍʏᴘʀᴏғɪʟᴇ\n" + \
                  "╠➣ " + key + "ᴍʏᴘɪᴄᴛᴜʀᴇ\n" + \
                  "╠➣ " + key + "ᴍʏᴄᴏᴠᴇʀ\n" + \
                  "╠➣ " + key + "ᴍʏᴠɪᴅᴇᴏ\n" + \
                  "╠➣ " + key + "ᴋᴀʟᴇɴᴅᴇʀ\n" + \
                  "╠➣ " + key + "ᴍᴇᴍᴘɪᴄᴛ\n" + \
                  "╠➣ " + key + "ᴜᴘᴅᴀᴛᴇɢʀᴜᴘ\n" + \
                  "╠➣ " + key + "ɢʀᴜᴘᴘɪᴄᴛ\n" + \
                  "╠➣ " + key + "ɪɴғᴏɢʀᴏᴜᴘ「ɴᴏ」\n" + \
                  "╠➣ " + key + "ɪɴғᴏᴍᴇᴍ「ɴᴏ」\n" + \
                  "╰「TEAM TERMUX」"
    return helpMessage4
def helpsetting():
    key = Setmain["keyCommand"]
    key = key.title()
    helpMessage2 = "╭「TEAM TERMUX」\n"+\
                  "╠➣ " + key + "ᴄᴇᴋ sɪᴅᴇʀ\n" + \
                  "╠➣ " + key + "ᴄᴇᴋ ʟᴇᴀᴠᴇ \n" + \
                  "╠➣ " + key + "ᴄᴇᴋ ᴘᴇsᴀɴ \n" + \
                  "╠➣ " + key + "ᴄᴇᴋ ʀᴇsᴘᴏɴ \n" + \
                  "╠➣ " + key + "ᴄᴇᴋ ʀᴇsᴘᴏɴ² \n" + \
                  "╠➣ " + key + "sᴇᴛ sɪᴅᴇʀ:「ᴛᴇxᴛ」\n" + \
                  "╠➣ " + key + "sᴇᴛ ᴘᴇsᴀɴ:「ᴛᴇxᴛ」\n" + \
                  "╠➣ " + key + "sᴇᴛ ʀᴇsᴘᴏɴ:「ᴛᴇxᴛ」\n" + \
                  "╠➣ " + key + "sᴇᴛ ʀᴇsᴘᴏɴ²:「ᴛᴇxᴛ」\n" + \
                  "╠➣ " + key + "sᴇᴛ ᴡᴇʟᴄᴏᴍᴇ:「ᴛᴇxᴛ」\n" + \
                  "╠➣ " + key + "sᴇᴛᴄᴏᴍᴍᴇɴᴛ:「ᴛᴇxᴛ」\n" + \
                  "╠➣ " + key + "sᴇᴛ ʟᴇᴀᴠᴇ:「ᴛᴇxᴛ」\n" + \
                  "╠➣ " + key + "ʟɪᴋᴇ「ᴏɴ/ᴏғғ」\n" + \
                  "╠➣ " + key + "ᴘᴏsᴛ「oɴ/oғғ」\n" + \
                  "╠➣ " + key + "sᴛɪᴄᴋᴇʀ「oɴ/oғғ」\n" + \
                  "╠➣ " + key + "ɪɴᴠɪᴛᴇ「oɴ/ᴏғғ」\n" + \
                  "╠➣ " + key + "ᴜɴsᴇɴᴅ「oɴ/oғғ」\n" + \
                  "╠➣ " + key + "ᴀᴜᴛᴏʀᴇᴀᴅ「oɴ/oғғ」\n" + \
                  "╠➣ " + key + "ᴅᴇʟғʀɪᴇɴᴅ「oɴ/oғғ」\n" + \
                  "╠➣ " + key + "ʀᴇsᴘᴏɴ「oɴ/oғғ」\n" + \
                  "╠➣ " + key + "ʀᴇsᴘᴏɴ²「oɴ/oғғ」\n" + \
                  "╠➣ " + key + "ᴀᴜᴛᴏᴀᴅᴅ「oɴ/oғғ」\n" + \
                  "╠➣ " + key + "ᴡᴇʟᴄᴏᴍᴇ「oɴ/oғғ」\n" + \
                  "╠➣ " + key + "ᴄᴏɴᴛᴀᴄᴛ「oɴ/oғғ」\n" + \
                  "╠➣ " + key + "ᴀᴜᴛᴏᴊᴏɪɴ「oɴ/oғғ」\n" + \
                  "╠➣ " + key + "ᴀᴜᴛᴏʀᴇᴊᴇᴄᴛ「oɴ/oғғ」\n" + \
                  "╠➣ " + key + "ᴀᴜᴛᴏʟᴇᴀᴠᴇ「oɴ/oғғ」\n" + \
                  "╠➣ " + key + "ᴀᴜᴛᴏʙʟᴏᴄᴋ「oɴ/oғғ」\n" + \
                  "╠➣ " + key + "ᴊᴏɪɴᴛɪᴄᴋᴇᴛ「oɴ/oғғ」\n" + \
				  "╰「TEAM TERMUX」"
    return helpMessage2

def media():
    key = Setmain["keyCommand"]
    key = key.title()
    helpMessage3 = "╭「TEAM TERMUX」\n"+\
                  "╠➣ " + key + "ᴀᴅᴅɪᴍɢ\n" + \
                  "╠➣ " + key + "ᴀᴅᴅᴍᴘ3\n" + \
                  "╠➣ " + key + "ᴀᴅᴅᴀᴜᴅɪᴏ\n" + \
                  "╠➣ " + key + "ᴀᴅᴅᴠɪᴅᴇᴏ\n" + \
                  "╠➣ " + key + "ᴀᴅᴅsᴛɪᴄᴋᴇʀ\n" + \
                  "╠➣ " + key + "ᴅᴇʟʟɪᴍɢ\n" + \
                  "╠➣ " + key + "ᴅᴇʟʟᴍᴘ3\n" + \
                  "╠➣ " + key + "ᴅᴇʟʟᴀᴜᴅɪᴏ\n" + \
                  "╠➣ " + key + "ᴅᴇʟʟᴠɪᴅᴇᴏ\n" + \
                  "╠➣ " + key + "ᴅᴇʟʟsᴛɪᴄᴋᴇʀ\n" + \
                  "╠➣ " + key + "ʟɪsᴛᴛɪᴄᴋᴇʀ\n" + \
                  "╠➣ " + key + "ʟɪsᴛɪᴍᴀɢᴇ\n" + \
                  "╠➣ " + key + "ʟɪsᴛᴠɪᴅᴇᴏ\n" + \
                  "╠➣ " + key + "ʟɪsᴛᴀᴜᴅɪᴏ\n" + \
                  "╠➣ " + key + "ʟɪsᴛᴍᴘ3\n" + \
                  "╠➣ " + key + "ᴄᴄᴛᴠ ᴍᴇᴛʀᴏ\n" + \
                  "╠➣ " + key + "ʟɪʜᴀᴛ [no]\n" + \
                  "╠➣ " + key + "sᴍᴜʟᴇ [ɪᴅ]\n" + \
                  "╠➣ " + key + "ᴊᴏᴏx [ᴛᴇxᴛ]\n" + \
                  "╠➣ " + key + "ᴍᴘ3: [ᴛᴇxᴛ]\n" + \
                  "╠➣ " + key + "ᴍᴘ4: [ᴛᴇxᴛ]\n" + \
                  "╠➣ " + key + "ʏᴜᴛᴜʙᴇ [ᴛᴇxᴛ]\n" + \
                  "╠➣ " + key + "ʏᴏᴜᴛᴜʙᴇ [ᴛᴇxᴛ]\n" + \
                  "╰「TEAM TERMUX」"
    return helpMessage3


def bot(op):
    global time
    global ast
    global groupParam
    try:
        if op.type == 0:
            return
        if op.type == 5:
            if wait["autoBlock"] == True:
                cl.blockContact(op.param1)
                cl.sendMessage(op.param1,"❒   ꜱᴏʀʀʏ ᴀᴜᴛᴏʙʟᴏᴄᴋ ᴀᴋᴛɪꜰ [ᴍᴀᴛɪ].👁️.★.★.★.👁️.[ᴍᴀᴛɪ].1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.👿.👿.👿 [ᴍᴀᴛɪ].👁️.★.★.★.👁️.[ᴍᴀᴛɪ].1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.🌺.👿.👿.👿.\n[ᴍᴀᴛɪ].👁️.★.★.★.👁️.[ᴍᴀᴛɪ].1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.🌺.👿.👿.👿.\n[ᴍᴀᴛɪ].👁️.★.★.★.👁️.[ᴍᴀᴛɪ].1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.🌺.👿.👿.👿.")
        if op.type == 13 or op.type == 124:
            if mid in op.param3:
                if wait["autoLeave"] == True:
                    if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                        cl.acceptGroupInvitation(op.param1)
                        ginfo = cl.getGroup(op.param1)
                        cl.leaveGroup(op.param1)
                    else:
                        cl.acceptGroupInvitation(op.param1)
                        ginfo = cl.getGroup(op.param1)
        if op.type == 26:
            msg = op.message
            sender = msg._from
            to = msg.to
            if msg.contentType == 6:
             if wait["responGc"] == True:
                 a = cl.getContact(sender)
                 if msg.toType == 2:
                     b = msg.contentMetadata['GC_EVT_TYPE']
                     c = msg.contentMetadata["GC_MEDIA_TYPE"]
                     if c == "VIDEO" and b == "S":                     	
                         tz = pytz.timezone("Asia/Jakarta")
                         timeNow = datetime.now(tz=tz)                                             
                         cl.getGroup(to).name
                         cl.getContact(msg._from).displayName
                         warna1 = ("#ff69b4","#00ffff","#9933ff","#0033CC","#00ff33","#cc00ff","#ff0033","#003333")
                         warnanya1 = random.choice(warna1)   
                         data = {
                                        "type": "flex",
                                        "altText": "TEAM TERMUX",
                                        "contents": {

  "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://media.suara.com/pictures/653x366/2015/04/17/o_19j3m1hgthf63ni1h951v366r6a.jpg",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:3",
            "gravity": "top"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "NOTIFCALL GRUP",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "25px"
              }
            ],
            "width": "149px",
            "height": "20px",
            "borderColor": "#FF0000",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "position": "absolute",
            "offsetTop": "5px",
            "offsetStart": "3px",
            "backgroundColor": "#000080"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://i.ibb.co.com/9tdnpsd/1652980705963.jpg",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "width": "150px",
            "height": "90px",
            "position": "absolute",
            "offsetTop": "30px",
            "offsetStart": "3px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [],
            "borderColor": "#FF0000",
            "cornerRadius": "5px",
            "borderWidth": "1px",
            "width": "150px",
            "height": "40px",
            "position": "absolute",
            "offsetTop": "147px",
            "offsetStart": "2px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "nah kan ngajakin oncam aim belunah kan ngajakinm mandi tau masih jelek",
                "size": "xxs",
                "color": "#FFFFFF",
                "wrap": True,
                "offsetStart": "2px",
                "offsetTop": "2px"
              }
            ],
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "width": "148px",
            "height": "38px",
            "position": "absolute",
            "offsetTop": "148px",
            "offsetStart": "3px",
            "backgroundColor": "#000000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "SUPPORT  BYE: TEAM TERMUX",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "7px"
              }
            ],
            "borderColor": "#FF00FF",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "width": "150px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "210px",
            "offsetStart": "2px",
            "backgroundColor": "#2E8B57"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "CREATOR",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "6px"
              }
            ],
            "borderColor": "#FF00FF",
            "cornerRadius": "5px",
            "borderWidth": "1px",
            "width": "70px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "188px",
            "offsetStart": "2px",
            "backgroundColor": "#800080"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "ORDER",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "15px"
              }
            ],
            "borderWidth": "1px",
            "borderColor": "#00FFFF",
            "cornerRadius": "5px",
            "width": "76px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "188px",
            "offsetStart": "75px",
            "backgroundColor": "#0000FF"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": []
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://www.blackxperience.com/assets/blackattitude/blacktips//cover-wa-300x300.jpg",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "height": "20px",
            "width": "20px",
            "cornerRadius": "100px",
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "position": "absolute",
            "offsetTop": "124px",
            "offsetStart": "3px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcQBeiKDJTqSrl0DE7K8pIaNYe1uUsXNVqz9dg&usqp=CAU",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "height": "20px",
            "width": "20px",
            "position": "absolute",
            "borderWidth": "1px",
            "cornerRadius": "100px",
            "borderColor": "#FFFF00",
            "offsetTop": "124px",
            "offsetStart": "35px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://play-lh.googleusercontent.com/74iMObG1vsR3Kfm82RjERFhf99QFMNIY211oMvN636_gULghbRBMjpVFTjOK36oxCbs",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "cornerRadius": "100px",
            "borderWidth": "1px",
            "width": "20px",
            "position": "absolute",
            "offsetTop": "124px",
            "offsetStart": "70px",
            "height": "20px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcRK_yDc42L7ssYuvce24MqTgvesOvYZgQIi8Q&usqp=CAU",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "cornerRadius": "100px",
            "width": "20px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "124px",
            "offsetStart": "100px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcTBtVrDomP1KCahV0TSV9hITha-PhnvetHd0g&usqp=CAU",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "cornerRadius": "100px",
            "borderWidth": "1px",
            "width": "20px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "124px",
            "offsetStart": "130px"
          }
        ],
        "paddingAll": "0px",
        "borderColor": "#FFFF00",
        "cornerRadius": "10px",
        "borderWidth": "2px",
        "action": {
          "type": "uri",
          "label": "action",
          "uri": "http://line.me/ti/p/~Zul.1.02"
        }
      }
    }
  ]
}
}
                         cl.postTemplate(to, data)                           

            if msg.contentType == 6:
             if wait["responGc1"] == True:
                 a = cl.getContact(sender)
                 if msg.toType == 2:
                     b = msg.contentMetadata['GC_EVT_TYPE']
                     c = msg.contentMetadata["GC_MEDIA_TYPE"] 
                     if c == "VIDEO" and b == "E":
                         tz = pytz.timezone("Asia/Jakarta")
                         timeNow = datetime.now(tz=tz)
                         cl.getGroup(to).name
                         cl.getContact(msg._from).displayName                            
                         data = {
                                        "type": "flex",
                                        "altText": "TEAM TERMUX",
                                        "contents": {

   "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://media.suara.com/pictures/653x366/2015/04/17/o_19j3m1hgthf63ni1h951v366r6a.jpg",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:3",
            "gravity": "top"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "NOTIFCALL GRUP",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "25px"
              }
            ],
            "width": "149px",
            "height": "20px",
            "borderColor": "#FF0000",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "position": "absolute",
            "offsetTop": "5px",
            "offsetStart": "3px",
            "backgroundColor": "#000080"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://i.ibb.co.com/9tdnpsd/1652980705963.jpg",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "width": "150px",
            "height": "90px",
            "position": "absolute",
            "offsetTop": "30px",
            "offsetStart": "3px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [],
            "borderColor": "#FF0000",
            "cornerRadius": "5px",
            "borderWidth": "1px",
            "width": "150px",
            "height": "40px",
            "position": "absolute",
            "offsetTop": "147px",
            "offsetStart": "2px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "ah tidak asik oncam bentar engga basah aku diatas wkwkwk",
                "size": "xxs",
                "color": "#FFFFFF",
                "wrap": True,
                "offsetStart": "2px",
                "offsetTop": "2px"
              }
            ],
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "width": "148px",
            "height": "38px",
            "position": "absolute",
            "offsetTop": "148px",
            "offsetStart": "3px",
            "backgroundColor": "#000000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "SUPPORT  BYE: TEAM TERMUX",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "7px"
              }
            ],
            "borderColor": "#FF00FF",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "width": "150px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "210px",
            "offsetStart": "2px",
            "backgroundColor": "#2E8B57"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "CREATOR",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "6px"
              }
            ],
            "borderColor": "#FF00FF",
            "cornerRadius": "5px",
            "borderWidth": "1px",
            "width": "70px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "188px",
            "offsetStart": "2px",
            "backgroundColor": "#800080"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "ORDER",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "15px"
              }
            ],
            "borderWidth": "1px",
            "borderColor": "#00FFFF",
            "cornerRadius": "5px",
            "width": "76px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "188px",
            "offsetStart": "75px",
            "backgroundColor": "#0000FF"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": []
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://www.blackxperience.com/assets/blackattitude/blacktips//cover-wa-300x300.jpg",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "height": "20px",
            "width": "20px",
            "cornerRadius": "100px",
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "position": "absolute",
            "offsetTop": "124px",
            "offsetStart": "3px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcQBeiKDJTqSrl0DE7K8pIaNYe1uUsXNVqz9dg&usqp=CAU",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "height": "20px",
            "width": "20px",
            "position": "absolute",
            "borderWidth": "1px",
            "cornerRadius": "100px",
            "borderColor": "#FFFF00",
            "offsetTop": "124px",
            "offsetStart": "35px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://play-lh.googleusercontent.com/74iMObG1vsR3Kfm82RjERFhf99QFMNIY211oMvN636_gULghbRBMjpVFTjOK36oxCbs",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "cornerRadius": "100px",
            "borderWidth": "1px",
            "width": "20px",
            "position": "absolute",
            "offsetTop": "124px",
            "offsetStart": "70px",
            "height": "20px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcRK_yDc42L7ssYuvce24MqTgvesOvYZgQIi8Q&usqp=CAU",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "cornerRadius": "100px",
            "width": "20px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "124px",
            "offsetStart": "100px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcTBtVrDomP1KCahV0TSV9hITha-PhnvetHd0g&usqp=CAU",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "cornerRadius": "100px",
            "borderWidth": "1px",
            "width": "20px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "124px",
            "offsetStart": "130px"
          }
        ],
        "paddingAll": "0px",
        "borderColor": "#FFFF00",
        "cornerRadius": "10px",
        "borderWidth": "2px",
        "action": {
          "type": "uri",
          "label": "action",
          "uri": "http://line.me/ti/p/~Zul.1.02"
        }
      }
    }
  ]
}
}
                         cl.postTemplate(to, data)
# NOTIFCALL GRUP EDITAN                         
            if msg.contentType == 6:
             if wait["responGc2"] == True:
                 a = cl.getContact(sender)
                 if msg.toType == 2:
                     b = msg.contentMetadata['GC_EVT_TYPE']
                     c = msg.contentMetadata["GC_MEDIA_TYPE"]                         
                     if c == "AUDIO" and b == "S":
                         tz = pytz.timezone("Asia/Jakarta")
                         timeNow = datetime.now(tz=tz)
                         cl.getGroup(to).name
                         cl.getContact(msg._from).displayName                            
                         data = {
                                        "type": "flex",
                                        "altText": "TEAM TERMUX",
                                        "contents": {

      "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://media.suara.com/pictures/653x366/2015/04/17/o_19j3m1hgthf63ni1h951v366r6a.jpg",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:3",
            "gravity": "top"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "NOTIFCALL GRUP",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "25px"
              }
            ],
            "width": "149px",
            "height": "20px",
            "borderColor": "#FF0000",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "position": "absolute",
            "offsetTop": "5px",
            "offsetStart": "3px",
            "backgroundColor": "#000080"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://i.ibb.co.com/9tdnpsd/1652980705963.jpg",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "width": "150px",
            "height": "90px",
            "position": "absolute",
            "offsetTop": "30px",
            "offsetStart": "3px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [],
            "borderColor": "#FF0000",
            "cornerRadius": "5px",
            "borderWidth": "1px",
            "width": "150px",
            "height": "40px",
            "position": "absolute",
            "offsetTop": "147px",
            "offsetStart": "2px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "wow jones naik temenin tuh kasian nanti baper kasian",
                "size": "xxs",
                "color": "#FFFFFF",
                "wrap": True,
                "offsetStart": "2px",
                "offsetTop": "2px"
              }
            ],
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "width": "148px",
            "height": "38px",
            "position": "absolute",
            "offsetTop": "148px",
            "offsetStart": "3px",
            "backgroundColor": "#000000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "SUPPORT  BYE: TEAM TERMUX",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "7px"
              }
            ],
            "borderColor": "#FF00FF",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "width": "150px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "210px",
            "offsetStart": "2px",
            "backgroundColor": "#2E8B57"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "CREATOR",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "6px"
              }
            ],
            "borderColor": "#FF00FF",
            "cornerRadius": "5px",
            "borderWidth": "1px",
            "width": "70px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "188px",
            "offsetStart": "2px",
            "backgroundColor": "#800080"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "ORDER",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "15px"
              }
            ],
            "borderWidth": "1px",
            "borderColor": "#00FFFF",
            "cornerRadius": "5px",
            "width": "76px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "188px",
            "offsetStart": "75px",
            "backgroundColor": "#0000FF"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": []
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://www.blackxperience.com/assets/blackattitude/blacktips//cover-wa-300x300.jpg",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "height": "20px",
            "width": "20px",
            "cornerRadius": "100px",
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "position": "absolute",
            "offsetTop": "124px",
            "offsetStart": "3px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcQBeiKDJTqSrl0DE7K8pIaNYe1uUsXNVqz9dg&usqp=CAU",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "height": "20px",
            "width": "20px",
            "position": "absolute",
            "borderWidth": "1px",
            "cornerRadius": "100px",
            "borderColor": "#FFFF00",
            "offsetTop": "124px",
            "offsetStart": "35px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://play-lh.googleusercontent.com/74iMObG1vsR3Kfm82RjERFhf99QFMNIY211oMvN636_gULghbRBMjpVFTjOK36oxCbs",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "cornerRadius": "100px",
            "borderWidth": "1px",
            "width": "20px",
            "position": "absolute",
            "offsetTop": "124px",
            "offsetStart": "70px",
            "height": "20px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcRK_yDc42L7ssYuvce24MqTgvesOvYZgQIi8Q&usqp=CAU",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "cornerRadius": "100px",
            "width": "20px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "124px",
            "offsetStart": "100px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcTBtVrDomP1KCahV0TSV9hITha-PhnvetHd0g&usqp=CAU",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "cornerRadius": "100px",
            "borderWidth": "1px",
            "width": "20px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "124px",
            "offsetStart": "130px"
          }
        ],
        "paddingAll": "0px",
        "borderColor": "#FFFF00",
        "cornerRadius": "10px",
        "borderWidth": "2px",
        "action": {
          "type": "uri",
          "label": "action",
          "uri": "http://line.me/ti/p/~Zul.1.02"
        }
      }
    }
  ]
}
}
                         cl.postTemplate(to, data)
            if msg.contentType == 6:
             if wait["responGc3"] == True:
                 a = cl.getContact(sender)
                 if msg.toType == 2:
                     b = msg.contentMetadata['GC_EVT_TYPE']
                     c = msg.contentMetadata["GC_MEDIA_TYPE"]                         
                     if c == "AUDIO" and b == "E":
                         tz = pytz.timezone("Asia/Jakarta")
                         timeNow = datetime.now(tz=tz)
                         cl.getGroup(to).name
                         cl.getContact(msg._from).displayName                            
                         data = {
                                        "type": "flex",
                                        "altText": "TEAM TERMUX",
                                        "contents": {

   "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://media.suara.com/pictures/653x366/2015/04/17/o_19j3m1hgthf63ni1h951v366r6a.jpg",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:3",
            "gravity": "top"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "NOTIFCALL GRUP",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "25px"
              }
            ],
            "width": "149px",
            "height": "20px",
            "borderColor": "#FF0000",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "position": "absolute",
            "offsetTop": "5px",
            "offsetStart": "3px",
            "backgroundColor": "#000080"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://i.ibb.co.com/9tdnpsd/1652980705963.jpg",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "width": "150px",
            "height": "90px",
            "position": "absolute",
            "offsetTop": "30px",
            "offsetStart": "3px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [],
            "borderColor": "#FF0000",
            "cornerRadius": "5px",
            "borderWidth": "1px",
            "width": "150px",
            "height": "40px",
            "position": "absolute",
            "offsetTop": "147px",
            "offsetStart": "2px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "ko turun kenapa udah dapet tikungan yah wow terbaik",
                "size": "xxs",
                "color": "#FFFFFF",
                "wrap": True,
                "offsetStart": "2px",
                "offsetTop": "2px"
              }
            ],
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "width": "148px",
            "height": "38px",
            "position": "absolute",
            "offsetTop": "148px",
            "offsetStart": "3px",
            "backgroundColor": "#000000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "SUPPORT  BYE: TEAM TERMUX",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "7px"
              }
            ],
            "borderColor": "#FF00FF",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "width": "150px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "210px",
            "offsetStart": "2px",
            "backgroundColor": "#2E8B57"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "CREATOR",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "6px"
              }
            ],
            "borderColor": "#FF00FF",
            "cornerRadius": "5px",
            "borderWidth": "1px",
            "width": "70px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "188px",
            "offsetStart": "2px",
            "backgroundColor": "#800080"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "ORDER",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "15px"
              }
            ],
            "borderWidth": "1px",
            "borderColor": "#00FFFF",
            "cornerRadius": "5px",
            "width": "76px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "188px",
            "offsetStart": "75px",
            "backgroundColor": "#0000FF"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": []
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://www.blackxperience.com/assets/blackattitude/blacktips//cover-wa-300x300.jpg",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "height": "20px",
            "width": "20px",
            "cornerRadius": "100px",
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "position": "absolute",
            "offsetTop": "124px",
            "offsetStart": "3px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcQBeiKDJTqSrl0DE7K8pIaNYe1uUsXNVqz9dg&usqp=CAU",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "height": "20px",
            "width": "20px",
            "position": "absolute",
            "borderWidth": "1px",
            "cornerRadius": "100px",
            "borderColor": "#FFFF00",
            "offsetTop": "124px",
            "offsetStart": "35px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://play-lh.googleusercontent.com/74iMObG1vsR3Kfm82RjERFhf99QFMNIY211oMvN636_gULghbRBMjpVFTjOK36oxCbs",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "cornerRadius": "100px",
            "borderWidth": "1px",
            "width": "20px",
            "position": "absolute",
            "offsetTop": "124px",
            "offsetStart": "70px",
            "height": "20px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcRK_yDc42L7ssYuvce24MqTgvesOvYZgQIi8Q&usqp=CAU",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "cornerRadius": "100px",
            "width": "20px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "124px",
            "offsetStart": "100px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcTBtVrDomP1KCahV0TSV9hITha-PhnvetHd0g&usqp=CAU",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "cornerRadius": "100px",
            "borderWidth": "1px",
            "width": "20px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "124px",
            "offsetStart": "130px"
          }
        ],
        "paddingAll": "0px",
        "borderColor": "#FFFF00",
        "cornerRadius": "10px",
        "borderWidth": "2px",
        "action": {
          "type": "uri",
          "label": "action",
          "uri": "http://line.me/ti/p/~Zul.1.02"
        }
      }
    }
  ]
}
}
                         cl.postTemplate(to, data)
            if msg.contentType == 6:
             if wait["responGc4"] == True:
                 a = cl.getContact(sender)
                 if msg.toType == 2:
                     b = msg.contentMetadata['GC_EVT_TYPE']
                     c = msg.contentMetadata["GC_MEDIA_TYPE"]                         
                     if c == "LIVE" and b == "S":
                         tz = pytz.timezone("Asia/Jakarta")
                         timeNow = datetime.now(tz=tz)
                         cl.getGroup(to).name
                         cl.getContact(msg._from).displayName                            
                         data = {
                                        "type": "flex",
                                        "altText": "TEAM TERMUX",
                                        "contents": {

   "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://media.suara.com/pictures/653x366/2015/04/17/o_19j3m1hgthf63ni1h951v366r6a.jpg",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:3",
            "gravity": "top"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "NOTIFCALL GRUP",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "25px"
              }
            ],
            "width": "149px",
            "height": "20px",
            "borderColor": "#FF0000",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "position": "absolute",
            "offsetTop": "5px",
            "offsetStart": "3px",
            "backgroundColor": "#000080"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://i.ibb.co.com/9tdnpsd/1652980705963.jpg",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "width": "150px",
            "height": "90px",
            "position": "absolute",
            "offsetTop": "30px",
            "offsetStart": "3px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [],
            "borderColor": "#FF0000",
            "cornerRadius": "5px",
            "borderWidth": "1px",
            "width": "150px",
            "height": "40px",
            "position": "absolute",
            "offsetTop": "147px",
            "offsetStart": "2px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "wow ada live show asik nih nonton siap siap anu yah",
                "size": "xxs",
                "color": "#FFFFFF",
                "wrap": True,
                "offsetStart": "2px",
                "offsetTop": "2px"
              }
            ],
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "width": "148px",
            "height": "38px",
            "position": "absolute",
            "offsetTop": "148px",
            "offsetStart": "3px",
            "backgroundColor": "#000000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "SUPPORT  BYE: TEAM TERMUX",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "7px"
              }
            ],
            "borderColor": "#FF00FF",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "width": "150px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "210px",
            "offsetStart": "2px",
            "backgroundColor": "#2E8B57"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "CREATOR",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "6px"
              }
            ],
            "borderColor": "#FF00FF",
            "cornerRadius": "5px",
            "borderWidth": "1px",
            "width": "70px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "188px",
            "offsetStart": "2px",
            "backgroundColor": "#800080"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "ORDER",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "15px"
              }
            ],
            "borderWidth": "1px",
            "borderColor": "#00FFFF",
            "cornerRadius": "5px",
            "width": "76px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "188px",
            "offsetStart": "75px",
            "backgroundColor": "#0000FF"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": []
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://www.blackxperience.com/assets/blackattitude/blacktips//cover-wa-300x300.jpg",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "height": "20px",
            "width": "20px",
            "cornerRadius": "100px",
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "position": "absolute",
            "offsetTop": "124px",
            "offsetStart": "3px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcQBeiKDJTqSrl0DE7K8pIaNYe1uUsXNVqz9dg&usqp=CAU",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "height": "20px",
            "width": "20px",
            "position": "absolute",
            "borderWidth": "1px",
            "cornerRadius": "100px",
            "borderColor": "#FFFF00",
            "offsetTop": "124px",
            "offsetStart": "35px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://play-lh.googleusercontent.com/74iMObG1vsR3Kfm82RjERFhf99QFMNIY211oMvN636_gULghbRBMjpVFTjOK36oxCbs",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "cornerRadius": "100px",
            "borderWidth": "1px",
            "width": "20px",
            "position": "absolute",
            "offsetTop": "124px",
            "offsetStart": "70px",
            "height": "20px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcRK_yDc42L7ssYuvce24MqTgvesOvYZgQIi8Q&usqp=CAU",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "cornerRadius": "100px",
            "width": "20px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "124px",
            "offsetStart": "100px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcTBtVrDomP1KCahV0TSV9hITha-PhnvetHd0g&usqp=CAU",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "cornerRadius": "100px",
            "borderWidth": "1px",
            "width": "20px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "124px",
            "offsetStart": "130px"
          }
        ],
        "paddingAll": "0px",
        "borderColor": "#FFFF00",
        "cornerRadius": "10px",
        "borderWidth": "2px",
        "action": {
          "type": "uri",
          "label": "action",
          "uri": "http://line.me/ti/p/~Zul.1.02"
        }
      }
    }
  ]
}
}
                         cl.postTemplate(to, data)
            if msg.contentType == 6:
             if wait["responGc5"] == True:
                 a = cl.getContact(sender)
                 if msg.toType == 2:
                     b = msg.contentMetadata['GC_EVT_TYPE']
                     c = msg.contentMetadata["GC_MEDIA_TYPE"]                         
                     if c == "LIVE" and b == "E":
                         tz = pytz.timezone("Asia/Jakarta")
                         timeNow = datetime.now(tz=tz)
                         cl.getGroup(to).name
                         cl.getContact(msg._from).displayName                            
                         data = {
                                        "type": "flex",
                                        "altText": "TEAM TERMUX",
                                        "contents": {

   "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://media.suara.com/pictures/653x366/2015/04/17/o_19j3m1hgthf63ni1h951v366r6a.jpg",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:3",
            "gravity": "top"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "NOTIFCALL GRUP",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "25px"
              }
            ],
            "width": "149px",
            "height": "20px",
            "borderColor": "#FF0000",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "position": "absolute",
            "offsetTop": "5px",
            "offsetStart": "3px",
            "backgroundColor": "#000080"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://i.ibb.co.com/9tdnpsd/1652980705963.jpg",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "width": "150px",
            "height": "90px",
            "position": "absolute",
            "offsetTop": "30px",
            "offsetStart": "3px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [],
            "borderColor": "#FF0000",
            "cornerRadius": "5px",
            "borderWidth": "1px",
            "width": "150px",
            "height": "40px",
            "position": "absolute",
            "offsetTop": "147px",
            "offsetStart": "2px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "engga asik live nyah bentar belum basah juga wkwkwk",
                "size": "xxs",
                "color": "#FFFFFF",
                "wrap": True,
                "offsetStart": "2px",
                "offsetTop": "2px"
              }
            ],
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "width": "148px",
            "height": "38px",
            "position": "absolute",
            "offsetTop": "148px",
            "offsetStart": "3px",
            "backgroundColor": "#000000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "SUPPORT  BYE: TEAM TERMUX",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "7px"
              }
            ],
            "borderColor": "#FF00FF",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "width": "150px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "210px",
            "offsetStart": "2px",
            "backgroundColor": "#2E8B57"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "CREATOR",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "6px"
              }
            ],
            "borderColor": "#FF00FF",
            "cornerRadius": "5px",
            "borderWidth": "1px",
            "width": "70px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "188px",
            "offsetStart": "2px",
            "backgroundColor": "#800080"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "ORDER",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "15px"
              }
            ],
            "borderWidth": "1px",
            "borderColor": "#00FFFF",
            "cornerRadius": "5px",
            "width": "76px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "188px",
            "offsetStart": "75px",
            "backgroundColor": "#0000FF"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": []
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://www.blackxperience.com/assets/blackattitude/blacktips//cover-wa-300x300.jpg",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "height": "20px",
            "width": "20px",
            "cornerRadius": "100px",
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "position": "absolute",
            "offsetTop": "124px",
            "offsetStart": "3px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcQBeiKDJTqSrl0DE7K8pIaNYe1uUsXNVqz9dg&usqp=CAU",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "height": "20px",
            "width": "20px",
            "position": "absolute",
            "borderWidth": "1px",
            "cornerRadius": "100px",
            "borderColor": "#FFFF00",
            "offsetTop": "124px",
            "offsetStart": "35px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://play-lh.googleusercontent.com/74iMObG1vsR3Kfm82RjERFhf99QFMNIY211oMvN636_gULghbRBMjpVFTjOK36oxCbs",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "cornerRadius": "100px",
            "borderWidth": "1px",
            "width": "20px",
            "position": "absolute",
            "offsetTop": "124px",
            "offsetStart": "70px",
            "height": "20px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcRK_yDc42L7ssYuvce24MqTgvesOvYZgQIi8Q&usqp=CAU",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "cornerRadius": "100px",
            "width": "20px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "124px",
            "offsetStart": "100px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcTBtVrDomP1KCahV0TSV9hITha-PhnvetHd0g&usqp=CAU",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "cornerRadius": "100px",
            "borderWidth": "1px",
            "width": "20px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "124px",
            "offsetStart": "130px"
          }
        ],
        "paddingAll": "0px",
        "borderColor": "#FFFF00",
        "cornerRadius": "10px",
        "borderWidth": "2px",
        "action": {
          "type": "uri",
          "label": "action",
          "uri": "http://line.me/ti/p/~Zul.1.02"
        }
      }
    }
  ]
}
}
                         cl.postTemplate(to, data)
                         Raka: Vork      

        if op.type == 13 or op.type == 124:
            if wait["autoJoin"] and mid in op.param3:
                group = cl.getGroup(op.param1)
                group.notificationDisabled = False
                cl.acceptGroupInvitation(op.param1)
                cl.updateGroup(group)
                ginfo = cl.getGroup(op.param1)
                data = {
  "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://www.wallpapertip.com/wmimgs/5-55534_iphone-8-wallpaper-in-hd-with-high-resolution.jpg",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:3",
            "gravity": "top"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "AutoJoin",
                "offsetStart": "35px",
                "color": "#FFFFFF"
              }
            ],
            "position": "absolute",
            "borderColor": "#FFFF00",
            "cornerRadius": "10px",
            "borderWidth": "2px",
            "width": "140px",
            "offsetStart": "7px",
            "offsetTop": "8px",
            "backgroundColor": "#191970"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://lh3.googleusercontent.com/jSuWySmy_T3qzqyTkwtffwTeGLGnT5AfA00JFMlBNW3Hq8WXvFfXz7cpi70H2Pqra8H3",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "cornerRadius": "100px",
            "width": "30px",
            "height": "30px",
            "position": "absolute",
            "borderWidth": "2px",
            "offsetTop": "6px",
            "offsetStart": "4px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcRLXrQgMtBucXHAbNaccI-gM2GzpncLmVkEKg&usqp=CAU",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "position": "absolute",
            "cornerRadius": "100px",
            "width": "30px",
            "height": "30px",
            "borderWidth": "2px",
            "borderColor": "#FFFF00",
            "offsetTop": "6px",
            "offsetStart": "120px",
            "action": {
              "type": "uri",
              "label": "action",
              "uri": "https://youtube.com"
            }
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://obs.line-scdn.net/{}".format(cl.getContact(op.param2).pictureStatus),
                "size": "full",
                "aspectMode": "cover",
                "aspectRatio": "2:3"
              }
            ],
            "borderColor": "#FFFF00",
            "cornerRadius": "5px",
            "borderWidth": "2px",
            "position": "absolute",
            "width": "70px",
            "offsetTop": "40px",
            "offsetStart": "5px",
            "height": "90px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://obs.line-scdn.net/{}".format(cl.getGroup(op.param1).pictureStatus),
                "aspectMode": "cover",
                "size": "full",
                "aspectRatio": "2:3"
              }
            ],
            "borderColor": "#FFFF00",
            "cornerRadius": "5px",
            "borderWidth": "2px",
            "position": "absolute",
            "width": "70px",
            "height": "90px",
            "offsetStart": "80px",
            "offsetTop": "40px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "Terima Kasih telah Undang kami Salam Kenal yah",
                "wrap": True,
                "size": "xs",
                "offsetTop": "2px",
                "offsetStart": "5px",
                "color": "#FFFFFF"
              }
            ],
            "position": "absolute",
            "borderColor": "#FFFF00",
            "cornerRadius": "5px",
            "borderWidth": "2px",
            "offsetTop": "140px",
            "offsetStart": "5px",
            "width": "140px",
            "height": "60px",
            "backgroundColor": "#663399"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "Creator",
                "color": "#FFFFFF",
                "offsetStart": "3px"
              }
            ],
            "borderColor": "#FFFF00",
            "cornerRadius": "5px",
            "width": "70px",
            "position": "absolute",
            "borderWidth": "2px",
            "offsetTop": "205px",
            "offsetStart": "6px",
            "backgroundColor": "#8B008B",
            "action": {
              "type": "uri",
              "label": "action",
              "uri": "http://line.me/ti/p/~Zul.1.02"
            }
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "Order",
                "color": "#FFFFFF",
                "offsetStart": "9px"
              }
            ],
            "position": "absolute",
            "borderColor": "#FFFF00",
            "cornerRadius": "5px",
            "borderWidth": "2px",
            "offsetTop": "205px",
            "width": "69px",
            "offsetStart": "80px",
            "backgroundColor": "#00BFFF",
            "action": {
              "type": "uri",
              "label": "action",
              "uri": "http://line.me/ti/p/~Zul.1.02"
            }
          }
        ],
        "paddingAll": "0px",
        "borderColor": "#FFFF00",
        "cornerRadius": "10px",
        "borderWidth": "2px",
        "action": {
          "type": "uri",
          "label": "action",
          "uri": "line://nv/profilePopup/mid=u1aaf34421b7a8a94e0a977095e4ff605"
        }
      }
    }
  ]
}
                cl.postFlex(op.param1, data)


        if op.type == 0:
            return
        if op.type == 5:
            if wait["autoAdd"] == True:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    if (wait["message1"] in [" "," ","\n",None]):
                        pass
                    else:
                        cl.sendMessage(op.param1, wait["message1"])

        if op.type == 13 or op.type == 124:
            if op.param1 in protectinvite:
                if op.param2 not in clMID:
                    cl.cancelGroupInvitation(op.param1,[op.param3])

        if op.type == 11 or op.type == 122:
            if op.param1 in protectqr:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    Z = cl.getGroup(op.param1)
                    if Z.preventedJoinByTicket == False:
                        Z.preventedJoinByTicket = True
                        wait["blacklist"][op.param2] = True
                
            if op.param3 in wait["blacklist"]:
                try:
                    cl.cancelGroupInvitation(op.param1,[op.param3])
                    cl.kickoutFromGroup(op.param1,[op.param2])
                    wait["blacklist"][op.param2] = True
                except:
                    try:
                        group = cl.getGroup(op.param1)
                        gMembMids = [contact.mid for contact in group.invitee]
                        for _dn in gMembMids:
                          if _dn in wait["blacklist"]:
                            cl.cancelGroupInvitation(op.param1,[_dn])
                    except:
                        cl.cancelGroupInvitation(op.param1,[op.param3])
                        cl.kickoutFromGroup(op.param1,[op.param2])
                        wait["blacklist"][op.param2] = True

        if op.type == 17 or op.type == 130:
            if op.param2 in wait["blacklist"]:
               try:
                   cl.kickoutFromGroup(op.param1,[op.param2])
                   cl.sendMessage(op.param1,"❒  ᴋɪᴋɪʟ ʀᴇᴄᴇʜᴀɴ ᴀɴᴅᴀ ᴍᴀꜱᴜᴋ ʙᴀᴄᴋʟɪꜱᴛ")
               except:
                   pass

        if op.type == 32 or op.type == 126:
            if wait["backup"] == True:
              if op.param3 in Bots:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    wait["blacklist"][op.param2] = True
                    try:
                        if op.param3 not in wait["blacklist"]:
                            cl.kickoutFromGroup(op.param1,[op.param2])
                            cl.inviteIntoGroup(op.param1,[op.param3])
                    except:
                    	pass
                return

        if op.type == 32 or op.type == 126:
            if op.param2 in wait["blacklist"]:
                try:
                    random.choice(ABC).kickoutFromGroup(op.param1,[op.param2])                   
                    print ("BLACKLIST KICK 32")
                except:
                    pass

                return

        if op.type == 19 or op.type == 133:
            if op.param3 in creator:
              if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                cl.findAndAddContactsByMid(op.param3)
                cl.inviteIntoGroup(op.param1,[op.param3])
                cl.kickoutFromGroup(op.param1,[op.param2])
                wait["blacklist"][op.param2] = True

        if op.type == 19 or op.type == 133:
            if op.param3 in admin:
              if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                cl.findAndAddContactsByMid(op.param3)
                cl.inviteIntoGroup(op.param1,[op.param3])
                cl.kickoutFromGroup(op.param1,[op.param2])
                wait["blacklist"][op.param2] = True

        if op.type == 55 or op.type == 133:            
            try:
                if op.param1 in read["readPoint"]:
                    if op.param2 in read["readMember"][op.param1]:
                        pass
                    else:
                        read["readMember"][op.param1][op.param2] = True
                else:
                   pass
            except:
                pass
                
        if op.type == 55 or op.type == 133:
            if op.param2 in wait["blacklist"]:
                cl.kickoutFromGroup(op.param1,[op.param2])
                print ("BLACKLIST KICK 55")
            else:
                pass

        if op.type == 65:
            if wait["Unsend"] == True:
                try:
                    at = op.param1
                    msg_id = op.param2
                    if msg_id in msg_dict:
                        if msg_dict[msg_id]["from"]:
                           if msg_dict[msg_id]["text"] == 'ɢᴀᴍʙᴀʀʏᴀ ɪʟᴀɴɢ':
                                ginfo = cl.getGroup(at)
                                ika = cl.getContact(msg_dict[msg_id]["from"])
                                zx = ""
                                zxc = ""
                                zx2 = []
                                xpesan =  "ᴘᴇsᴀɴ ᴅɪʜᴀᴘᴜs\nᴘᴇɴɢɪʀɪᴍ: "
                                ret_ = "ɴᴀᴍᴀ ɢʀᴜᴘ: {}".format(str(ginfo.name))
                                ret_ += "\nᴊᴀᴍ sʜᴀʀᴇ: {}".format(dt_to_str(cTime_to_datetime(msg_dict[msg_id]["createdTime"])))
                                ik = str(ika.displayName)
                                pesan = ''
                                pesan2 = pesan+"@x \n"
                                xlen = str(len(zxc)+len(xpesan))
                                xlen2 = str(len(zxc)+len(pesan2)+len(xpesan)-1)
                                zx = {'S':xlen, 'E':xlen2, 'M':raka.mid}
                                zx2.append(zx)
                                zxc += pesan2
                                text = xpesan + zxc + ret_ + ""
                                cl.sendMessage(at, text, contentMetadata={'MENTION':str('{"MENTIONEES":'+json.dumps(zx2).replace(' ','')+'}')}, contentType=0)
                           else:
                                ginfo = cl.getGroup(at)
                                raka = cl.getContact(msg_dict[msg_id]["from"])
                                raka1 = "❒   {}".format(str(raka.displayName))
                                raka2 = "❒   :{}".format(str(ginfo.name))
                                raka3 = "❒  {}".format(dt_to_str(cTime_to_datetime(msg_dict[msg_id]["createdTime"])))
                                seber = "═══「 ᴘᴇsᴀɴ ᴅɪʜᴀᴘᴜs 」═══\n{}".format(str(msg_dict[msg_id]["text"]))
                                data = {
                                        "type": "flex",
                                        "altText": "🅄🄽🅂🄴🄽🄳",
                                        "contents": {
  "styles": {
    "body": {
      "backgroundColor": "#000000"
    },
    "footer": {
      "backgroundColor": "#2f2f4f"
    }
  },
  "type": "bubble",
 "size": "micro",
      "body": {
  "contents": [
      {
        "contents": [                   
            {            
            "type": "separator",
            "color": "#33ffff"            
      },
      {
        "type": "separator",
        "color": "#33ffff"  
      },
      {         
         "contents": [
          {
          "type": "separator",
          "color": "#33ffff"   
      },
      {
            "contents": [
              {
              "type": "image",
     "url": "https://media.tenor.com/images/3cfcb167ed18a35f3a52f70e44fdf6c0/tenor.gif",
    "size": "xxs"
          },{
 "type": "text",
"text": "❒  ",
"weight": "bold",
"color": "#ccff00",
"size": "xxs",
"flex": 0
},{
"type": "text",
"text": "ᴅᴇᴛᴇᴄᴛ",
"weight": "bold",
"color": "#ccff00",
"size": "xxs",
"flex": 0
},{
"type": "text",
"text": "ᴜɴꜱᴇɴᴅ ❒  ",
"weight": "bold",
"color": "#ccff00",
"size": "xxs",
"flex": 0
      },
      {
    "type": "image",
     "url": "https://media.tenor.com/images/3cfcb167ed18a35f3a52f70e44fdf6c0/tenor.gif",
    "size": "xxs"
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "horizontal"    
      },
      {
        "type": "separator",
         "color": "#33ffff"
         }
            ],
            "type": "box",
            "layout": "horizontal"   
            },
         {
        "type": "separator",
        "color": "#33ffff"
         },
         {
       "contents": [
         {
        "type": "separator",
        "color": "#33ffff"
         },
         {
            "text": "🔂🔂🔂",
            "size": "xxs",
            "color": "#FF9900",
            "align": "center",
            "wrap": True,
            "weight": "bold",
            "type": "text"
            },{
            "type": "separator",
            "color": "#33ffff"
           },
             {
            "text": "🔀🔀🔀",
            "size": "xxs",
            "color": "#FF9900",
            "align": "center",
            "wrap": True,
            "weight": "bold",
            "type": "text"
            },{
            "type": "separator",
            "color": "#33ffff"
           },
             {
            "text": "🔁🔁🔁",
            "size": "xxs",
            "color": "#FF9900",
            "align": "center",
            "wrap": True,
            "weight": "bold",
            "type": "text"   
            },
         {
        "type": "separator",
        "color": "#33ffff"
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "horizontal"    
      },
      {
        "type": "separator",
         "color": "#33ffff"
         },
         {
       "contents": [
          {
           "type": "separator",
           "color": "#33ffff"
          },
          {
          "url": "https://obs.line-scdn.net/{}".format(str(ika.pictureStatus)),
            "type": "image",
            "size": "xxs",
            "flex": 0
          },
          {
        "type": "separator",
        "color": "#33ffff"
      },
      {      
       "contents": [              
          {
"type": "text",
"text": raka1,
"weight": "bold",
"color": "#33ffff",
"align": "center",
"size": "xxs",
"flex": 0
},{
"type": "separator",
"color": "#33ffff"
},{
"type": "text",
"text": raka3, #===============================❒  ❒  ❒  ❒  ❒  ❒  ❒  ❒  ❒  ❒  ❒  ❒  ❒  ❒  
"weight": "bold",
"color": "#ccffff",
#"align": "center",
"size": "xxs",
"flex": 0
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "vertical"
      },
      {
        "type": "separator",
        "color": "#33ffff"
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "horizontal"
      },
      {
        "type": "separator",
         "color": "#33ffff"
       },
       {     
       "contents": [           
         { 
           "type": "separator",
           "color": "#33ffff"
            },
           {
            "contents": [
              {
              "type": "separator",
           "color": "#33ffff"
            },
           {
          "type": "text",
"text": raka2, #"{}".format(cl.getContact(mid).displayName),
"weight": "bold",
"color": "#ffff00",
#"align": "center",
"size": "xxs",
"flex": 0
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "vertical"    
      },
      {
        "type": "separator",
         "color": "#33ffff"
         }
            ],
            "type": "box",
            "layout": "horizontal"   
            },
         {
        "type": "separator",
        "color": "#33ffff"
         },
         {          
         "contents": [
         { 
           "type": "separator",
           "color": "#33ffff"
            },
           {
            "contents": [
              {
              "type": "separator",
           "color": "#33ffff"
            },
           {
          "text": seber,
           "size": "xxs",
       #   "align": "center",
           "color": "#00ff00",
           "wrap": True,
           "weight": "bold",
           "type": "text"
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "vertical"    
      },
      {
        "type": "separator",
         "color": "#33ffff"
         }
            ],
            "type": "box",
            "layout": "horizontal"   
            },
         {
        "type": "separator",
        "color": "#33ffff"
         },
         {
       "contents": [
         {
        "type": "separator",
        "color": "#33ffff"
         },
         {
            "text": "🔂🔂🔂",
            "size": "xxs",
            "color": "#FF9900",
            "align": "center",
            "wrap": True,
            "weight": "bold",
            "type": "text"
            },{
            "type": "separator",
            "color": "#33ffff"
           },
             {
            "text": "🔀🔀🔀",
            "size": "xxs",
            "color": "#FF9900",
            "align": "center",
            "wrap": True,
            "weight": "bold",
            "type": "text"
            },{
            "type": "separator",
            "color": "#33ffff"
           },
             {
            "text": "🔁🔁🔁",
            "size": "xxs",
            "color": "#FF9900",
            "align": "center",
            "wrap": True,
            "weight": "bold",
            "type": "text"   
          },
         {
        "type": "separator",
        "color": "#33ffff"
         }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "horizontal"    
      },
      {
        "type": "separator",
         "color": "#33ffff"
         },
         {
      "contents": [
          {
            "type": "separator",
            "color": "#33ffff"
            },
             {
            "type": "image",
            "url": "https://i.ibb.co.com/XWQd8rj/20190625-201419.png",
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "https://youtube.com",
           }, 
            "flex": 1
          },
          {
          "type": "image",
            "url": "https://i.ibb.co.com/b53ztTR/20190427-191019.png", #linehttps://icon-icons.com/icons2/70/PNG/512/line_14096.png", #line
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "http://line.me/ti/p/~Zul.1.02",             
           }, 
            "flex": 1            
          },
          {
          "type": "image",
            "url": "https://i.ibb.co.com/ZHtFDts/20190427-185307.png", #chathttps://i.ibb.co.com/b53ztTR/20190427-191019.png", #linehttps://icon-icons.com/icons2/70/PNG/512/line_14096.png", #line
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "line://nv/chat" #"http://line.me/ti/p/~Zul.1.02",
            },         
            "flex": 1          
            },
          {
          "type": "image",
            "url": "https://i.ibb.co.com/CntKh4x/20190525-152240.png", #smule
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "Https://smule.com/KSS4LY44",
            },         
            "flex": 1          
          },
          {
          "type": "image",
            "url": "https://i.ibb.co.com/Wf8bQ2Z/20190625-105354.png",
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "line://nv/cameraRoll/multi"
            },
            "flex": 1
            },
            {
            "contents": [
            {
            "type": "image",
            "url": "https://i.ibb.co.com/1sGhJdC/20190428-232658.png",
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "http://line.me/ti/p/~Zul.1.02"
          },
            "flex": 1           
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "vertical"    
      },
      {
        "type": "separator",
         "color": "#33ffff"
         }
            ],
            "type": "box",
            "layout": "horizontal"   
            },
         {
        "type": "separator",
        "color": "#33ffff"
        },{
        "contents": [         
              {
            "type": "separator",
            "color": "#33ffff"
            },
             {          
            "contents": [
               {
    "type": "image",
    "url": "https://media.tenor.com/images/3cfcb167ed18a35f3a52f70e44fdf6c0/tenor.gif",
    "size": "xxs"
    },{
 "type": "text",
"text": "SB TEAM TERMUX",
"weight": "bold",
"color": "#ccff00",
"size": "xxs",
"flex": 0
},{
"type": "text",
"text": "™Bₒₜₛ",
"weight": "bold",
"color": "#ccff00",
"size": "xxs",
"flex": 0
},{
"type": "text",
"text": "SB TEAM TERMUX",
"weight": "bold",
"color": "#ccff00",
"size": "xxs",
"flex": 0
      },
      {
    "type": "image",
    "url": "https://media.tenor.com/images/3cfcb167ed18a35f3a52f70e44fdf6c0/tenor.gif",
    "size": "xxs"
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "horizontal"    
      },
      {
        "type": "separator",
         "color": "#33ffff"
         }
            ],
            "type": "box",
            "layout": "horizontal"   
            },
         {
        "type": "separator", #batas APK
        "color": "#33ffff"     
          }
        ],
        "type": "box",
        "layout": "vertical"
      }
    ],
    "type": "box",
    "spacing": "xs",
    "layout": "vertical"
  }
}
}
                                cl.postTemplate(at, data)
                                cl.sendImage(at, msg_dict[msg_id]["data"])
                        del msg_dict[msg_id]
                except Exception as e:
                    print(e)

        if op.type == 65:
            if wait["Unsend"] == True:
                try:
                    at = op.param1
                    msg_id = op.param2
                    if msg_id in msg_dict1:
                        if msg_dict1[msg_id]["from"]:
                                ginfo = cl.getGroup(at)
                                ryan = cl.getContact(msg_dict1[msg_id]["from"])
                                ret_ =  "╔══「❒   sᴛɪᴄᴋᴇʀ ɪɴғᴏ ❒  」\n"
                                ret_ += "┣[]►❒  : {}".format(str(ryan.displayName))
                                ret_ += "\n┣[]►❒  : {}".format(str(ginfo.name))
                                ret_ += "\n┣[]►❒  : {}".format(dt_to_str(cTime_to_datetime(msg_dict1[msg_id]["createdTime"])))
                                ret_ += "\n╚══「❒   ᴜɴsᴇɴᴅ ғɪɴɪsʜ ❒  」"
                                ret_ += "{}".format(str(msg_dict1[msg_id]["text"]))
                                sendTextTemplate2(at, str(ret_))
                                cl.sendImage(at, msg_dict1[msg_id]["data"])
                        del msg_dict1[msg_id]
                except Exception as e:
                    print(e)
        if op.type == 26:
            msg = op.message
            text = msg.text
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            if msg.toType == 0 or msg.toType == 1 or msg.toType == 2:
                if msg.toType == 0:
                    if sender != cl.profile.mid:
                        to = sender
                    else:
                        to = receiver
                elif msg.toType == 1:
                    to = receiver
                elif msg.toType == 2:
                    to = receiver
                if msg.contentType == 0:
                    msg_dict[msg.id] = {"text": msg.text, "from": msg._from, "createdTime": msg.createdTime, "contentType": msg.contentType, "contentMetadata": msg.contentMetadata}
                if msg.contentType == 1:
                    path = cl.downloadObjectMsg(msg_id)
                    msg_dict[msg.id] = {"text":'ɢᴀᴍʙᴀʀʏᴀ ᴅɪʙᴀᴡᴀʜ',"data":path,"from":msg._from,"createdTime":msg.createdTime}
                if msg.contentType == 7:
                   stk_id = msg.contentMetadata["STKID"]
                   stk_ver = msg.contentMetadata["STKVER"]
                   pkg_id = msg.contentMetadata["STKPKGID"]
                   ret_ = "\n╔══「❒   sᴛɪᴄᴋᴇʀ ɪɴғᴏ ❒  ]"
                   ret_ += "\n┣[]❒   sᴛɪᴄᴋᴇʀ ɪᴅ: {}".format(stk_id)
                   ret_ += "\n┣[]❒   sᴛɪᴄᴋᴇʀ ᴠᴇʀsɪᴏɴ: {}".format(stk_ver)
                   ret_ += "\n┣[]❒   sᴛɪᴄᴋᴇʀ: {}".format(pkg_id)
                   ret_ += "\n┣[]❒   ᴜʀʟ:{}".format(pkg_id)
                   ret_ += "\n╚══「❒   ᴜɴsᴇɴᴅ ғɪɴɪsʜ ❒  」"
                   query = int(stk_id)
                   if type(query) == int:
                            data = 'https://stickershop.line-scdn.net/stickershop/v1/sticker/'+str(query)+'/ANDROID/sticker.png'
                            path = cl.downloadFileURL(data)
                            msg_dict1[msg.id] = {"text":str(ret_),"data":path,"from":msg._from,"createdTime":msg.createdTime}
#===============================❒  ❒  ❒  ❒  ❒  ❒  ❒  ❒  ❒  ❒  ❒  ❒  ❒  ❒  
        if op.type == 17:
            if op.param1 in welcome:
                ginfo = cl.getGroup(op.param1)
             #   cl.updateGroup(group)
                contact = cl.getContact(op.param2)
                #cover = cl.getProfileCoverURL(op.param2)
                welcomeMembers(op.param1, [op.param2])
                tz = pytz.timezone("Asia/Jakarta")
                timeNow = datetime.now(tz=tz)
                data = {
                                       "type": "flex",
                                       "altText": "🅆🄴🄻🄲🄾🄼🄴",
                                       "contents": {

  "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "kilo",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://i.ibb.co.com/Gcy4K6Q/ezgif-com-gif-to-apng-10.png",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:1",
            "gravity": "top",
            "animated": True
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [],
            "borderColor": "#00FFFF",
            "borderWidth": "1px",
            "cornerRadius": "2px",
            "position": "absolute",
            "width": "250px",
            "height": "30px",
            "offsetTop": "4px",
            "offsetStart": "4px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": " "+ datetime.strftime(timeNow,'%H:%M:%S'),
                "size": "xxs",
                "color": "#FFFFFF",
                "style": "italic",
                "offsetTop": "2px",
                "offsetStart": "25px"
              }
            ],
            "borderColor": "#00FFFF",
            "cornerRadius": "2px",
            "borderWidth": "1px",
            "width": "120px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "33px",
            "offsetStart": "4px",
            "backgroundColor": "#000080"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": " "+ datetime.strftime(timeNow,'%Y-%m-%d'),
                "size": "xxs",
                "style": "italic",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "50px"
              }
            ],
            "borderColor": "#00FFFF",
            "borderWidth": "1px",
            "cornerRadius": "2px",
            "width": "131px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "33px",
            "offsetStart": "123px",
            "backgroundColor": "#DC143C"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [],
            "position": "absolute",
            "borderColor": "#00FFFF",
            "cornerRadius": "2px",
            "borderWidth": "1px",
            "width": "90px",
            "height": "72px",
            "offsetTop": "52px",
            "offsetStart": "4px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "TEAM TERMUX",
                "size": "xxs",
                "color": "#FFFFFF",
                "style": "italic",
                "offsetTop": "2px",
                "offsetStart": "34px"
              }
            ],
            "borderColor": "#00FFFF",
            "borderWidth": "1px",
            "cornerRadius": "2px",
            "position": "absolute",
            "width": "161px",
            "height": "20px",
            "offsetTop": "52px",
            "offsetStart": "93px",
            "backgroundColor": "#8B0000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [],
            "borderColor": "#00FFFF",
            "borderWidth": "1px",
            "cornerRadius": "2px",
            "width": "161px",
            "height": "53px",
            "position": "absolute",
            "offsetTop": "71px",
            "offsetStart": "93px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://obs.line-scdn.net/{}".format(cl.getContact(op.param2).pictureStatus),
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FF1493",
            "cornerRadius": "2px",
            "borderWidth": "1px",
            "width": "87px",
            "height": "70px",
            "position": "absolute",
            "offsetTop": "53px",
            "offsetStart": "6px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "W E L L C O M E ",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "4px",
                "offsetStart": "80px"
              }
            ],
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "cornerRadius": "2px",
            "position": "absolute",
            "width": "248px",
            "height": "28px",
            "offsetTop": "5px",
            "offsetStart": "5px",
            "backgroundColor": "#000000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": wait["welcome"],
                "size": "xxs",
                "color": "#FFFFFF",
                "style": "italic",
                "offsetTop": "2px",
                "offsetStart": "1px",
                "wrap": True
              }
            ],
            "position": "absolute",
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "cornerRadius": "2px",
            "width": "159px",
            "height": "51px",
            "offsetTop": "72px",
            "offsetStart": "94px",
            "backgroundColor": "#800080"
          }
        ],
        "paddingAll": "0px",
        "borderColor": "#00FFFF",
        "borderWidth": "1px",
        "cornerRadius": "10px",
        "action": {
          "type": "uri",
          "label": "action",
          "uri": "http://line.me/ti/p/~Zul.1.02"
        }
      }
    }
  ]
}
}

                cl.postTemplate(op.param1, data)
        if op.type == 15:
            if op.param1 in welcome:
                ginfo = cl.getGroup(op.param1)
              #  cl.updateGroup(group)
                contact = cl.getContact(op.param2)
                #cover = cl.getProfileCoverURL(op.param2)
                leaveMembers(op.param1, [op.param2])
                tz = pytz.timezone("Asia/Jakarta")
                timeNow = datetime.now(tz=tz)
                data = {
                                       "type": "flex",
                                       "altText": "🄰🅄🅃🄾🄻🄴🄰🅅🄴",
                                       "contents": {

  "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://i.ibb.co.com/Gcy4K6Q/ezgif-com-gif-to-apng-10.png",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:3",
            "gravity": "top",
            "animated": True,
            "action": {
              "type": "uri",
              "label": "action",
              "uri": "http://line.me/ti/p/~Zul.1.02"
            }
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [],
            "borderColor": "#00FFFF",
            "borderWidth": "1px",
            "cornerRadius": "2px",
            "position": "absolute",
            "width": "150px",
            "height": "40px",
            "offsetTop": "3px",
            "offsetStart": "4px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "MEMBER LEAVE",
                "size": "xxs",
                "color": "#FFFFFF",
                "style": "italic",
                "offsetTop": "4px",
                "offsetStart": "32px"
              }
            ],
            "position": "absolute",
            "borderColor": "#00FFFF",
            "borderWidth": "1px",
            "cornerRadius": "2px",
            "width": "150px",
            "height": "25px",
            "offsetTop": "42px",
            "offsetStart": "4px",
            "backgroundColor": "#000000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "✬  {}".format(cl.getContact(mid).displayName),
                "size": "xxs",
                "color": "#FFFFFF",
                "style": "italic",
                "offsetTop": "2px",
                "offsetStart": "2px"
              }
            ],
            "borderColor": "#00FFFF",
            "borderWidth": "1px",
            "cornerRadius": "2px",
            "width": "150px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "140px",
            "offsetStart": "4px",
            "backgroundColor": "#800080"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": wait["autoLeave"],
                "size": "xxs",
                "color": "#FFFFFF",
                "style": "italic",
                "offsetTop": "3px",
                "offsetStart": "4px",
                "wrap": True
              }
            ],
            "position": "absolute",
            "borderColor": "#00FFFF",
            "borderWidth": "1px",
            "cornerRadius": "2px",
            "width": "150px",
            "height": "45px",
            "offsetTop": "159px",
            "offsetStart": "4px",
            "backgroundColor": "#000000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [],
            "borderColor": "#00FFFF",
            "borderWidth": "1px",
            "cornerRadius": "2px",
            "width": "150px",
            "height": "30px",
            "position": "absolute",
            "offsetTop": "203px",
            "offsetStart": "4px",
            "backgroundColor": "#000080"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://obs.line-scdn.net/{}".format(cl.getContact(op.param2).pictureStatus),
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#00FFFF",
            "borderWidth": "1px",
            "cornerRadius": "2px",
            "width": "78px",
            "height": "75px",
            "position": "absolute",
            "offsetTop": "66px",
            "offsetStart": "4px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://obs.line-scdn.net/{}".format(cl.getContact(mid).pictureStatus),
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#00FFFF",
            "borderWidth": "1px",
            "cornerRadius": "2px",
            "width": "70px",
            "height": "40px",
            "position": "absolute",
            "offsetTop": "3px",
            "offsetStart": "4px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": " "+ datetime.strftime(timeNow,'%Y-%m-%d'),
                "size": "xxs",
                "style": "italic",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "2px"
              }
            ],
            "borderColor": "#00FFFF",
            "borderWidth": "1px",
            "cornerRadius": "2px",
            "width": "81px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "3px",
            "offsetStart": "73px",
            "backgroundColor": "#8B008B"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": " "+ datetime.strftime(timeNow,'%H:%M:%S'),
                "size": "xxs",
                "color": "#FFFFFF",
                "style": "italic",
                "offsetTop": "2px",
                "offsetStart": "2px"
              }
            ],
            "borderColor": "#00FFFF",
            "borderWidth": "1px",
            "cornerRadius": "2px",
            "width": "81px",
            "height": "21px",
            "position": "absolute",
            "offsetTop": "22px",
            "offsetStart": "73px",
            "backgroundColor": "#A52A2A"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [],
            "borderColor": "#00FFFF",
            "borderWidth": "1px",
            "cornerRadius": "2px",
            "width": "73px",
            "height": "75px",
            "offsetTop": "66px",
            "position": "absolute",
            "offsetStart": "81px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "CREATOR",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "10px",
                "offsetStart": "8px"
              }
            ],
            "position": "absolute",
            "borderColor": "#00FFFF",
            "borderWidth": "1px",
            "cornerRadius": "2px",
            "width": "73px",
            "height": "40px",
            "offsetTop": "66px",
            "offsetStart": "81px",
            "backgroundColor": "#000000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": []
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [],
            "borderColor": "#00FFFF",
            "borderWidth": "1px",
            "cornerRadius": "2px",
            "width": "73px",
            "height": "10px",
            "position": "absolute",
            "offsetTop": "105px",
            "offsetStart": "81px",
            "backgroundColor": "#FF0000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "ORDER",
                "size": "xxs",
                "color": "#FFFFFF",
                "style": "italic",
                "offsetTop": "5px",
                "offsetStart": "12px"
              }
            ],
            "borderColor": "#00FFFF",
            "borderWidth": "1px",
            "cornerRadius": "2px",
            "width": "73px",
            "height": "27px",
            "position": "absolute",
            "offsetTop": "114px",
            "offsetStart": "81px",
            "backgroundColor": "#000000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "TEAM TERMUX",
                "size": "xxs",
                "style": "italic",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "15px"
              }
            ],
            "borderColor": "#00FFFF",
            "borderWidth": "1px",
            "cornerRadius": "2px",
            "width": "141px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "208px",
            "offsetStart": "9px",
            "backgroundColor": "#000000"
          }
        ],
        "paddingAll": "0px",
        "borderColor": "#00FFFF",
        "cornerRadius": "10px",
        "borderWidth": "1px"
      }
    }
  ]
}
}

                cl.postTemplate(op.param1, data)
                
        if op.type == 55:
                try:
                    if cctv2['cyduk2'][op.param1]==True:
                        if op.param1 in cctv2['point2']:
                            Name = cl.getContact(op.param2).displayName
                            if Name in cctv2['sidermem2'][op.param1]:
                                pass
                            else:
                                cctv2['sidermem2'][op.param1] += "\n~ " + Name
                                summon(op.param1,[op.param2])
                                zxn=["Woy Bayar Utang Loe","Loe Yang Ratain Room Yah","Hallo Sayang Cium Dong","Cek Tuh Pm Gosong","Minta Vip Smule Dong","Aku Ga Punya Tikel Beliin Nah","Undang Aku Di Room Kamu Dong","Loe Yang Ngintip Gue Mandi Yah","Akun Gue Banchat Tolong Ajarin Puskun Gimana","Aku Pengen Nenen Sama Kamu Boleh","Kamu Ternyata Manis Yah Aku Baru Tau","Jadi Ga Besok Ke Rumah Gue","Di Gc Kamu Ada Janda Ga Coba Invite","Emang Bener Kata Orang Loe Punya Gajah","Aku Pengen Curhat Sama Kamu Boleh","Kemana Ajah Kamu Ga pernah Keliatan","Gimana Kabar Kamu Sehat Kapan Mati","Pinjemin Duit Dong Buat Beli Pulsa","Kemarin Aku Kirim Pulsa Masuk Ga","Nomer Rekening Yang Kemarin Bener Ga Aku Mau Transfer","Kemarin Aku Punya Hutang Yah Belum Di Bayar","Kemarin Gue Tungguin Loe Katanyah Mau Tlpn Bohong","Kapan Gue Di Kojomin Sama Loe Lagi Coba","Aku Pengen Login Bot Dong Berapa Harganyah","Tolong Undang Dong Akun Ku Yang Baru"]
                                say = random.choice(zxn)
                                cl.sendMessage(op.param1, say)
                        else:
                            pass
                    else:
                        pass
                except:
                    pass
        else:
            pass

        if op.type == 55:
            if cctv['cyduk'][op.param1]==True:
                if op.param1 in cctv['point']:
                    Name = cl.getContact(op.param2).displayName
                    if Name in cctv['sidermem'][op.param1]:
                        pass
                    else:
                        cctv['sidermem'][op.param1] += "\n~ " + Name
                        siderMembers(op.param1, [op.param2])
                        contact = cl.getContact(op.param2)
                        warna1 = ("#00FF00","#33FFFF","#ADFF2F","#FFFF00","#FF0000","#1e90ff","#ff1493","#00ffff","#4363d6","#d6514c","#d75c23","#23f690","#e72aa6","#883b8a")
                        warnanya1 = random.choice(warna1)
                        #cover = cl.getProfileCoverURL(op.param2)
                        tz = pytz.timezone("Asia/Jakarta")
                        timeNow = datetime.now(tz=tz)
                        data = {
                                       "type": "flex",
                                       "altText": "TEAM TERMUX",
                                       "contents": {
                                       
  "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://i.ibb.co.com/3kTMsnR/ezgif-com-gif-maker.png",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:2",
            "animated": True
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "size": "full",
                "aspectMode": "cover",
                "url": "https://www.kibrispdr.org/data/wallpaper-melengkung-1.jpg"
              }
            ],
            "borderColor": "#F0F8FF",
            "borderWidth": "1px",
            "cornerRadius": "2px",
            "width": "148px",
            "height": "147px",
            "position": "absolute",
            "offsetTop": "5px",
            "offsetStart": "5px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "SIDER MEMBER",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "1px",
                "offsetStart": "30px"
              }
            ],
            "borderColor": "#F0F8FF",
            "borderWidth": "1px",
            "cornerRadius": "2px",
            "width": "148px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "5px",
            "offsetStart": "5px",
            "backgroundColor": "#000080"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "TEAM TERMUX",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "17px"
              }
            ],
            "borderColor": "#F0F8FF",
            "borderWidth": "1px",
            "cornerRadius": "2px",
            "width": "148px",
            "height": "20px",
            "position": "absolute",
            "offsetStart": "5px",
            "offsetTop": "132px",
            "backgroundColor": "#8B0000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "SELFBOT",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "1px",
                "offsetStart": "15px"
              }
            ],
            "borderColor": "#F0F8FF",
            "borderWidth": "1px",
            "cornerRadius": "2px",
            "width": "80px",
            "height": "20px",
            "position": "absolute",
            "offsetStart": "5px",
            "offsetTop": "24px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "PROFILE",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "1px",
                "offsetStart": "10px"
              }
            ],
            "borderColor": "#F0F8FF",
            "borderWidth": "1px",
            "cornerRadius": "2px",
            "width": "69px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "24px",
            "offsetStart": "84px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [],
            "borderColor": "#F0F8FF",
            "cornerRadius": "1px",
            "borderWidth": "1px",
            "width": "70px",
            "height": "70px",
            "position": "absolute",
            "offsetTop": "43px",
            "offsetStart": "5px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": wait["mention"],
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "1px",
                "offsetStart": "1px"
              }
            ],
            "borderColor": "#F0F8FF",
            "borderWidth": "1px",
            "cornerRadius": "2px",
            "position": "absolute",
            "width": "148px",
            "height": "21px",
            "offsetTop": "112px",
            "offsetStart": "5px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://i.ibb.co.com/TMj9gJD/ezgif-com-gif-maker.png",
                "size": "full",
                "aspectMode": "cover",
                "animated": True
              }
            ],
            "borderColor": "#F0F8FF",
            "borderWidth": "1px",
            "cornerRadius": "2px",
            "width": "68px",
            "height": "66px",
            "position": "absolute",
            "offsetTop": "43px",
            "offsetStart": "80px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "⌚ "+ datetime.strftime(timeNow,'%H:%M:%S'),
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "1px",
                "offsetStart": "1px"
              }
            ],
            "borderColor": "#F0F8FF",
            "borderWidth": "1px",
            "cornerRadius": "2px",
            "width": "70px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "47px",
            "offsetStart": "5px",
            "backgroundColor": "#800080"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "🗓️ "+ datetime.strftime(timeNow,'%Y-%m-%d'),
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "1px"
              }
            ],
            "borderColor": "#F0F8FF",
            "borderWidth": "1px",
            "cornerRadius": "2px",
            "width": "70px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "70px",
            "offsetStart": "5px",
            "backgroundColor": "#008080"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://obs.line-scdn.net/{}".format(cl.getContact(op.param2).pictureStatus),
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderWidth": "1px",
            "cornerRadius": "100px",
            "width": "50px",
            "height": "50px",
            "position": "absolute",
            "offsetTop": "52px",
            "offsetStart": "88px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": " {} ".format(cl.getContact(op.param2).displayName),
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "1px",
                "offsetStart": "1px"
              }
            ],
            "borderColor": "#F0F8FF",
            "borderWidth": "1px",
            "cornerRadius": "2px",
            "position": "absolute",
            "width": "70px",
            "height": "21px",
            "offsetTop": "92px",
            "offsetStart": "5px",
            "backgroundColor": "#8B0000"
          }
        ],
        "paddingAll": "0px",
        "borderColor": warnanya1,
        "borderWidth": "1px",
        "cornerRadius": "10px",
        "action": {
          "type": "uri",
          "label": "action",
          "uri": "http://line.me/ti/p/~Zul.1.02"
        }
      }
    }
  ]
}
}
                        cl.postTemplate(op.param1, data),
#===============================❒  ❒  ❒  ❒  ❒  ❒  ❒  ❒  ❒  ❒  ❒  ❒  ❒  ❒  
        if op.type == 26:
            msg = op.message
            text = msg.text
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            if settings ["Aip"] == True:
                if msg.text in ["byepass"]:
                    cl.kickoutFromGroup(receiver,[sender])
            if wait["selfbot"] == True:
               if msg._from not in Bots:
                 if wait["talkban"] == True:
                   if msg._from in wait["Talkblacklist"]:
                      try:
                          cl.kickoutFromGroup(msg.to, [msg._from])
                      except:
                          try:
                              cl.kickoutFromGroup(msg.to, [msg._from])
                          except:
                              try:
                                  cl.kickoutFromGroup(msg.to, [msg._from])
                              except:
                                  try:
                                  	cl.kickoutFromGroup(msg.to, [msg._from])
                                  except:
                                      pass
               if msg.contentMetadata is not None and 'MENTION' in msg.contentMetadata:
                 if wait["detectMention"] == True:
                   contact = cl.getContact(msg._from)
                   tz = pytz.timezone("Asia/Jakarta")
                   timeNow = datetime.now(tz=tz)
                   #cover = cl.getProfileCoverURL(sender)
                   name = re.findall(r'@(\w+)', msg.text)
                   image = "http://dl.profile.line-cdn.net/" + contact.pictureStatus
                   mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                   mentionees = mention['MENTIONEES']
                   for mention in mentionees:
                        if mention ['M'] in mid:
                           data = {
                                       "type": "flex",
                                       "altText": "TEAM TERMUX",
                                       "contents": {
   "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://i.ibb.co.com/3kTMsnR/ezgif-com-gif-maker.png",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:1",
            "gravity": "top",
            "animated": True
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [],
            "borderColor": "#F0F8FF",
            "borderWidth": "1px",
            "cornerRadius": "2px",
            "width": "149px",
            "height": "70px",
            "position": "absolute",
            "offsetTop": "5px",
            "offsetStart": "4px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "AUTORESPON",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetStart": "45px"
              }
            ],
            "borderColor": "#F0F8FF",
            "borderWidth": "1px",
            "cornerRadius": "2px",
            "position": "absolute",
            "width": "149px",
            "height": "15px",
            "offsetTop": "5px",
            "offsetStart": "4px",
            "backgroundColor": "#000000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": " {} ".format(contact.displayName),
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetStart": "50px"
              }
            ],
            "borderColor": "#F0F8FF",
            "borderWidth": "1px",
            "cornerRadius": "2px",
            "width": "149px",
            "height": "15px",
            "position": "absolute",
            "offsetTop": "60px",
            "offsetStart": "4px",
            "backgroundColor": "#000000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://obs.line-scdn.net/{}".format(contact.pictureStatus),
                "size": "full",
                "aspectMode": "cover",
                "aspectRatio": "3:4"
              }
            ],
            "borderColor": "#F0F8FF",
            "borderWidth": "1px",
            "cornerRadius": "2px",
            "width": "50px",
            "height": "56px",
            "position": "absolute",
            "offsetTop": "19px",
            "offsetStart": "4px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "⌚ "+ datetime.strftime(timeNow,'%H:%M:%S'),
                "size": "xxs",
                "color": "#FFFFFF"
              }
            ],
            "borderColor": "#F0F8FF",
            "borderWidth": "1px",
            "cornerRadius": "2px",
            "width": "100px",
            "height": "15px",
            "position": "absolute",
            "offsetTop": "19px",
            "offsetStart": "53px",
            "backgroundColor": "#000000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": wait["Respontag"],
                "size": "xxs",
                "color": "#FFFFFF",
                "wrap": True
              }
            ],
            "borderColor": "#F0F8FF",
            "borderWidth": "1px",
            "cornerRadius": "2px",
            "width": "100px",
            "height": "28px",
            "position": "absolute",
            "offsetTop": "33px",
            "offsetStart": "53px",
            "backgroundColor": "#000000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://i.ibb.co.com/105TkPD/ezgif-com-gif-maker-1.png",
                "size": "full",
                "aspectMode": "cover",
                "animated": True
              }
            ],
            "borderColor": "#F0F8FF",
            "borderWidth": "1px",
            "cornerRadius": "2px",
            "width": "149px",
            "height": "70px",
            "position": "absolute",
            "offsetTop": "5px",
            "offsetStart": "4px"
          }
        ],
        "paddingAll": "0px",
        "borderWidth": "1px",
        "cornerRadius": "10px",
        "borderColor": "#F0F8FF",
        "action": {
          "type": "uri",
          "label": "action",
          "uri": "http://line.me/ti/p/~Zul.1.02",
        }
      }
    }
  ]
}
}
                           cl.postTemplate(to, data)
                        #   cl.sendMessage(msg.to, None, contentMetadata={"STKID":"155808605","STKPKGID":"6700627","STKVER":"1"}, contentType=7)
                           break
               if msg.contentMetadata is not None and 'MENTION' in msg.contentMetadata:
                if msg._from not in Bots:
                 if wait["Mentionkick"] == True:
                   name = re.findall(r'@(\w+)', msg.text)
                   mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                   mentionees = mention['MENTIONEES']
                   for mention in mentionees:
                        if mention ['M'] in Bots:
                           sendFooter1(msg.to,"JANGAN TAG GUE TEK JITAK LOE")
                           cl.kickoutFromGroup(msg.to, [msg._from])
                           break
               if msg.contentMetadata is not None and 'MENTION' in msg.contentMetadata:
                 if wait["detectMention2"] == True:
                   contact = cl.getContact(msg._from)
                   tz = pytz.timezone("Asia/Jakarta")
                   timeNow = datetime.now(tz=tz)
                   #cover = cl.getProfileCoverURL(sender)
                   name = re.findall(r'@(\w+)', msg.text)
                   image = "http://dl.profile.line-cdn.net/" + contact.pictureStatus
                   mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                   mentionees = mention['MENTIONEES']
                   for mention in mentionees:
                        if mention ['M'] in mid:
                           data = {
                                "type": "flex",
                                "altText": "TEAM TERMUX",
                                "contents": {
"type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://obs.line-scdn.net/{}".format(contact.pictureStatus),
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:2",
            "gravity": "top"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://cdn-2.tstatic.net/style/foto/bank/images/cara-mudah-melihat-status-whatsapp-wa-teman-yang-telah-hilang-dihapus-tanpa-aplikasi.jpg",
                "aspectMode": "cover",
                "size": "full"
              }
            ],
            "borderColor": "#FFFF00",
            "cornerRadius": "100px",
            "position": "absolute",
            "width": "20px",
            "height": "20px",
            "borderWidth": "1px",
            "offsetTop": "85px",
            "offsetStart": "5px",
            "action": {
              "type": "uri",
              "label": "action",
              "uri": "https://wa.me/085757076639"
            }
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://media.cdnandroid.com/item_images/146592/imagen-autorap-by-smule-0big.jpg",
                "aspectMode": "cover",
                "size": "full"
              }
            ],
            "borderColor": "#FFFF00",
            "cornerRadius": "100px",
            "width": "20px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "85px",
            "borderWidth": "1px",
            "offsetStart": "30px",
            "action": {
              "type": "uri",
              "label": "action",
              "uri": "Https://smule.com/Zul_moko"
            }
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://lh3.googleusercontent.com/74iMObG1vsR3Kfm82RjERFhf99QFMNIY211oMvN636_gULghbRBMjpVFTjOK36oxCbs",
                "aspectMode": "cover",
                "size": "full"
              }
            ],
            "borderColor": "#FFFF00",
            "cornerRadius": "100px",
            "width": "20px",
            "height": "20px",
            "position": "absolute",
            "borderWidth": "1px",
            "offsetTop": "85px",
            "offsetStart": "55px",
            "action": {
              "type": "uri",
              "label": "action",
              "uri": "http://line.me/ti/p/~Zul.1.02"
            }
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcRdk-3SeEWHKW-gKsWaz3XgxEEIie8aTGZ5wA&usqp=CAU",
                "aspectMode": "cover",
                "size": "full"
              }
            ],
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "cornerRadius": "100px",
            "width": "20px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "85px",
            "offsetStart": "80px",
            "action": {
              "type": "uri",
              "label": "action",
              "uri": "http://line.me/ti/p/~Zul.1.02"
            }
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcTc6Cw39LgZKhLA93UcYYZgn-UN2eFh0xBPzA&usqp=CAU",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "position": "absolute",
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "cornerRadius": "100px",
            "height": "20px",
            "width": "20px",
            "offsetTop": "85px",
            "offsetStart": "105px",
            "action": {
              "type": "uri",
              "label": "action",
              "uri": "https://youtube.com"
            }
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "size": "full",
                "aspectMode": "cover",
                "url": "https://pbs.twimg.com/profile_images/1274990757024129025/Pha6dxth_400x400.jpg"
              }
            ],
            "position": "absolute",
            "cornerRadius": "100px",
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "width": "20px",
            "height": "20px",
            "offsetTop": "85px",
            "offsetStart": "130px",
            "action": {
              "type": "uri",
              "label": "action",
              "uri": "https://joox.com"
            }
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": wait["Respontag2"],
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetStart": "2px"
              }
            ],
            "borderColor": "#FFFF00",
            "borderWidth": "2px",
            "cornerRadius": "5px",
            "width": "143px",
            "position": "absolute",
            "offsetTop": "133px",
            "offsetStart": "5px",
            "backgroundColor": "#C71585"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "❒  {} ".format(contact.displayName),
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetStart": "5px"
              }
            ],
            "position": "absolute",
            "borderColor": "#FFFF00",
            "borderWidth": "2px",
            "cornerRadius": "5px",
            "width": "143px",
            "offsetTop": "110px",
            "backgroundColor": "#C71585",
            "offsetStart": "5px"
          }
        ],
        "paddingAll": "0px",
        "borderColor": "#FFFF00",
        "cornerRadius": "10px",
        "borderWidth": "2px",
        "action": {
          "type": "uri",
          "label": "action",
          "uri": "line://nv/profilePopup/mid=u1aaf34421b7a8a94e0a977095e4ff605"
        }
      }
    }
  ]
}
}
                           cl.postTemplate(to, data)
                        #   cl.sendMessage(msg.to, None, contentMetadata={"STKID":"155808605","STKPKGID":"6700627","STKVER":"1"}, contentType=7)
                           break
#===============================❒  ❒  ❒  ❒  ❒  ❒  ❒  ❒  ❒  ❒  ❒  ❒  ❒  ❒  
                 if msg.contentMetadata is not None and 'MENTION' in msg.contentMetadata:
                  if wait["detectMention3"] == True:
                   contact = cl.getContact(msg._from)
                   name = re.findall(r'@(\w+)', msg.text)
                   image = "http://dl.profile.line-cdn.net/" + contact.pictureStatus
                   mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                   mentionees = mention['MENTIONEES']
                   for mention in mentionees:
                        if mention ['M'] in Bots:
                           cl.sendMessage(msg.to, wait["Respontag"])
                           break
#===============================❒  ❒  ❒  ❒  ❒  ❒  ❒  ❒  ❒  ❒  ❒  ❒  ❒  ❒  
               if msg.contentMetadata is not None and 'MENTION' in msg.contentMetadata:
                  if wait["detectMention4"] == True:
                   contact = cl.getContact(msg._from)
                   tz = pytz.timezone("Asia/Jakarta")
                   timeNow = datetime.now(tz=tz)
                   #cover = cl.getProfileCoverURL(sender)
                   name = re.findall(r'@(\w+)', msg.text)
                   image = "http://dl.profile.line-cdn.net/" + contact.pictureStatus
                   mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                   mentionees = mention['MENTIONEES']
                   for mention in mentionees:
                        if mention ['M'] in mid:
                           data = {

  "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://z-p3-scontent.fsrg4-1.fna.fbcdn.net/v/t1.0-9/cp0/e15/q65/p720x720/122461038_1769003916585577_810017809072295920_o.jpg?_nc_cat=100&ccb=2&_nc_sid=110474&efg=eyJpIjoidCJ9&_nc_eui2=AeGYf3ouXqgyV6A9eh7jxrgkpKHo7ZkyQJ2koejtmTJAnTk426PI76LAXy60tyJP4sxv7OS3rrcEPI_U3Wrs8Upi&_nc_ohc=IC9ByXPlf9YAX_0OIA1&_nc_ht=z-p3-scontent.fsrg4-1.fna&tp=3&oh=7b7939ef7df196f1d77f5a8f9622938e&oe=5FBE98A8",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:1",
            "gravity": "top"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "❒  {} ".format(contact.displayName),
                "color": "#FFFFFF",
                "size": "xxs",
                "offsetStart": "38px"
              }
            ],
            "borderColor": "#FF1493",
            "borderWidth": "2px",
            "cornerRadius": "10px",
            "width": "120px",
            "position": "absolute",
            "height": "20px",
            "offsetTop": "124px",
            "offsetStart": "8px",
            "backgroundColor": "#000080"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://obs.line-scdn.net/{}".format(contact.pictureStatus),
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FF1493",
            "borderWidth": "2px",
            "cornerRadius": "100px",
            "position": "absolute",
            "height": "40px",
            "width": "40px",
            "offsetTop": "106px",
            "offsetStart": "4px"
          }
        ],
        "paddingAll": "0px",
        "borderColor": "#FF1493",
        "cornerRadius": "15px",
        "borderWidth": "2px",
        "action": {
          "type": "uri",
          "label": "action",
          "uri": "http://line.me/ti/p/~Zul.1.02"
        }
      }
    }
  ]
}
                           cl.postFlex(to, data)
                           break
#===============================❒  ❒  ❒  ❒  ❒  ❒  ❒  ❒  ❒  ❒  ❒  ❒  ❒  ❒  
               if msg.contentMetadata is not None and 'MENTION' in msg.contentMetadata:
                 if wait["arespon"] == True:
                   name = re.findall(r'@(\w+)', msg.text)
                   mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                   mentionees = mention['MENTIONEES']
                   lists = []
                   for mention in mentionees:
                        if mention ['M'] in mid:
                           contact = cl.getContact(msg._from)
                           cl.sendImageWithURL(msg._from, "http://dl.profile.line-cdn.net{}".format(contact.picturePath))
                           sendMention1(sender, "╭──────────────────╮\n╠ ❒  ɴᴜᴍᴘᴀɴɢ ᴘʀᴏᴍᴏ ʏᴀ ᴋᴀᴋᴀᴋ    │\n╰──────────────────╯\n╭──────────────────\n╠ ❒  ʀᴇᴀᴅʏ ʙᴏᴛ ᴘʀᴏᴛᴇᴄᴛ\n╠ ❒  ʀᴏᴏᴍ sᴍᴜʟᴇ / ᴇᴠᴇɴᴛ \n╠ ❒  ʀᴇᴀᴅʏ sʙ ᴏɴʟʏ \n╠ ❒  sʙ ᴏɴʟʏ + ᴀᴊs \n╠ ❒  sʙ + ᴀssɪsᴛ + ᴀᴊs \n╠ ❒  ʟᴏɢɪɴ ᴊs / ʙʏᴘᴀs / ɴɪɴᴊᴀ\n╠ ❒  ɴᴇᴡ ᴘᴇᴍʙᴜᴀᴛᴀɴ sᴄ ʙᴏᴛ \n├❒ ɴᴇᴡ ʙᴇʟᴀᴊᴀʀ ʙᴏᴛ \n╠ ❒  ᴘᴇᴍᴀsᴀɴɢ sʙ ᴋᴇ  ™Bₒₜₛ\n╠ ❒  ʀᴇᴀᴅʏ ᴀᴋᴜɴ ᴄᴏɪɴ\n╠ ❒  ʀᴇᴀᴅʏ ᴄᴏɪɴ ɢɪғᴛ \n╰────────────────── \n╭─────────────────\n├ ❒  ️ line.me/ti/p/~Zul.1.02\n╰─────────────────", [sender])
                           break

#===============================❒  ❒  ❒  ❒  ❒  ❒  ❒  ❒  ❒  ❒  ❒  ❒  ❒  ❒  
               if msg.contentType == 7:
                 if wait["sticker"] == True:
                    msg.contentType = 0
                    cl.sendMessage(msg.to,"「Cek ID Sticker」\n°❂° STKID : " + msg.contentMetadata["STKID"] + "\n°❂° STKPKGID : " + msg.contentMetadata["STKPKGID"] + "\n°❂° STKVER : " + msg.contentMetadata["STKVER"]+ "\n\n「Link Sticker」" + "\nline://shop/detail/" + msg.contentMetadata["STKPKGID"])
               if msg.contentType == 13:
                 if wait["contact"] == True:
                    msg.contentType = 0
                    cl.sendMessage(msg.to,msg.contentMetadata["mid"])
                    if 'displayName' in msg.contentMetadata:
                        contact = cl.getContact(msg.contentMetadata["mid"])
                        path = cl.getContact(msg.contentMetadata["mid"]).picturePath
                        image = 'http://dl.profile.line.naver.jp'+path
                        cl.sendMessage(msg.to,"°❂° Nama : " + msg.contentMetadata["displayName"] + "\n°❂° MID : " + msg.contentMetadata["mid"] + "\n°❂° Status Msg : " + contact.statusMessage + "\n°❂° Picture URL : http://dl.profile.line-cdn.net/" + contact.pictureStatus)
                        cl.sendImageWithURL(msg.to, image)
        if op.type == 25 or op.type == 26:
            msg = op.message
            text = msg.text
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            if msg.toType == 0 and msg.toType == 2:
                if sender != cl.profile.mid:
                    to = sender
                else:
                    to = receiver
            elif msg.toType == 1:
                to = receiver
            elif msg.toType == 2:
                to = receiver
            if msg.contentType == 0:
                to = receiver
            if msg.contentType == 16:
              if settings["checkPost"] == True:
                contact = cl.getContact(msg._from)
                url = msg.contentMetadata["postEndUrl"]
                tz = pytz.timezone("Asia/Jakarta")
                timeNow = datetime.now(tz=tz)
                cl.likePost(url[25:58], url[66:], likeType=1004)
                cl.createComment(url[25:58], url[66:], wait["comment"])
                #cover = cl.getProfileCoverURL(sender)
                data = {
                                "type": "flex",
                                "altText": "🄰🅄🅃🄾🄻🄸🄺🄴 🄼🄴🄼🄱🄴🅁",
                                "contents": {
"type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "nano",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcQ6J3WFRE31c8xbx9WGenzE01GTJ-EgZtryYA&usqp=CAU",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:3",
            "gravity": "top"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "AUTOLIKE",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "28px"
              }
            ],
            "position": "absolute",
            "borderWidth": "1px",
            "borderColor": "#FF0000",
            "cornerRadius": "5px",
            "width": "109px",
            "height": "20px",
            "offsetStart": "3px",
            "offsetTop": "2px",
            "backgroundColor": "#663399"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": []
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://obs.line-scdn.net/{}".format(cl.getContact(sender).pictureStatus),
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "position": "absolute",
            "width": "106px",
            "height": "70px",
            "borderWidth": "1px",
            "cornerRadius": "16px",
            "borderColor": "#FFFF00",
            "offsetTop": "25px",
            "offsetStart": "5px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "❒   "+ datetime.strftime(timeNow,'%H:%M:%S'),
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "2px"
              }
            ],
            "borderWidth": "1px",
            "borderColor": "#FF0000",
            "cornerRadius": "5px",
            "width": "110px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "100px",
            "offsetStart": "3px",
            "backgroundColor": "#000000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "TEAM TERMUX",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "18px"
              }
            ],
            "position": "absolute",
            "width": "110px",
            "height": "20px",
            "cornerRadius": "5px",
            "borderColor": "#FF0000",
            "borderWidth": "1px",
            "offsetTop": "153px",
            "offsetStart": "3px",
            "backgroundColor": "#000080"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcSlutPwzHYWHdy5nxCb6DDhlCvOcg3axNG58g&usqp=CAU",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderWidth": "1px",
            "borderColor": "#FFFF00",
            "cornerRadius": "100px",
            "width": "25px",
            "height": "25px",
            "position": "absolute",
            "offsetTop": "123px",
            "offsetStart": "10px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://www.facebook.com/images/fb_icon_325x325.png",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "cornerRadius": "100px",
            "width": "25px",
            "height": "25px",
            "position": "absolute",
            "offsetTop": "123px",
            "offsetStart": "45px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://play-lh.googleusercontent.com/74iMObG1vsR3Kfm82RjERFhf99QFMNIY211oMvN636_gULghbRBMjpVFTjOK36oxCbs",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "position": "absolute",
            "width": "25px",
            "height": "25px",
            "borderWidth": "1px",
            "borderColor": "#FFFF00",
            "cornerRadius": "100px",
            "offsetTop": "123px",
            "offsetStart": "80px"
          }
        ],
        "paddingAll": "0px",
        "borderColor": "#FF0000",
        "borderWidth": "2px",
        "cornerRadius": "10px",
        "action": {
          "type": "uri",
          "label": "action",
          "uri": "http://line.me/ti/p/~Zul.1.02"
        }
      }
    }
  ]
}
}
                cl.postTemplate(to, data)
                
            if msg.contentType == 0 or msg.toType == 2:
               if msg.toType == 0:
                    to = receiver
               elif msg.toType == 2:
                    to = receiver
               if msg.contentType == 7:
                 if wait["sticker"] == True:
                    msg.contentType = 0
                    cl.sendMessage(msg.to,"STKID : " + msg.contentMetadata["STKID"] + "\nSTKPKGID : " + msg.contentMetadata["STKPKGID"] + "\nSTKVER : " + msg.contentMetadata["STKVER"]+ "\n\n「Link Sticker」" + "\nline://shop/detail/" + msg.contentMetadata["STKPKGID"])
               if msg.contentType == 13:
                 if wait["contact"] == True:
                    msg.contentType = 0
                    cl.sendMessage(msg.to,msg.contentMetadata["mid"])
                    if 'displayName' in msg.contentMetadata:
                        contact = cl.getContact(msg.contentMetadata["mid"])
                        path = cl.getContact(msg.contentMetadata["mid"]).picturePath
                        image = 'http://dl.profile.line.naver.jp'+path
                        cl.sendMessage(msg.to,"Nama : " + msg.contentMetadata["displayName"] + "\nMID : " + msg.contentMetadata["mid"] + "\nStatus Msg : " + contact.statusMessage + "\nPicture URL : http://dl.profile.line-cdn.net/" + contact.pictureStatus)
                        cl.sendImageWithURL(msg.to, image)
               if msg.contentType == 13:
                if msg._from in admin:
                  if wait["invite"] == True:
                    msg.contentType = 0
                    contact = cl.getContact(msg.contentMetadata["mid"])
                    invite = msg.contentMetadata["mid"]
                    groups = cl.getGroup(msg.to)
                    pending = groups.invitee
                    targets = []
                    for s in groups.members:
                        if invite in wait["blacklist"]:
                            sendFooter1(msg.to, "ʟɪsᴛ ʙʟ")
                            break
                        else:
                            targets.append(invite)
                    if targets == []:
                        pass
                    else:
                         for target in targets:
                             try:
                                  cl.findAndAddContactsByMid(target)
                                  cl.inviteIntoGroup(msg.to,[target])
                                  ryan = cl.getContact(target)
                                  zx = ""
                                  zxc = ""
                                  zx2 = []
                                  xpesan =  "「 sᴜᴋsᴇs ɪɴᴠɪᴛᴇ 」\nɴᴀᴍᴀ"
                                  ret_ = "ᴋᴇᴛɪᴋ ɪɴᴠɪᴛᴇ ᴏғғ ᴊɪᴋᴀ sᴜᴅᴀʜ ᴅᴏɴᴇ"
                                  ry = str(ryan.displayName)
                                  pesan = ''
                                  pesan2 = pesan+"@x\n"
                                  xlen = str(len(zxc)+len(xpesan))
                                  xlen2 = str(len(zxc)+len(pesan2)+len(xpesan)-1)
                                  zx = {'S':xlen, 'E':xlen2, 'M':ryan.mid}
                                  zx2.append(zx)
                                  zxc += pesan2
                                  text = xpesan + zxc + ret_ + ""
                                  cl.sendMessage(msg.to, text, contentMetadata={'MENTION':str('{"MENTIONEES":'+json.dumps(zx2).replace(' ','')+'}')}, contentType=0)
                                  wait["invite"] = False
                                  break
                             except:
                                  sendFooter1(msg.to,"❒   Akun Anda Terkena Limit")
                                  wait["invite"] = False
                                  break
                                  
               if msg.contentType == 13:
                 if wait["Invi"] == True:
                        _name = msg.contentMetadata["displayName"]
                        invite = msg.contentMetadata["mid"]
                        groups = cl.getGroup(msg.to)
                        pending = groups.invitee
                        targets = []
                        for s in groups.members:
                            if _name in s.displayName:
                                cl.sendMessage(msg.to,"-> " + _name + " was here")
                                wait["Invi"] = False
                                break         
                            else:
                                targets.append(invite)
                        if targets == []:
                            pass
                        else:
                            for target in targets:
                                cl.findAndAddContactsByMid(target)
                                cl.inviteIntoGroup(msg.to,[target])
                                cl.sendMessage(msg.to,"❒   ᴅᴏɴᴇ ᴊᴇᴘɪᴛ\n➡" + _name)
                                wait["Invi"] = False
                                break
#===============================

               if msg.contentType == 2:
                   if msg._from in admin:
                       if msg._from in settings["ChangeVideoProfilevid"]:
                            settings["ChangeVideoProfilePicture"][msg._from] = True
                            del settings["ChangeVideoProfilevid"][msg._from]
                            cl.downloadObjectMsg(msg_id,'path','video.mp4')
                            sendFooter1(msg.to,"❒   Sillahkan Kirim Gambar nyah")
               if msg.contentType == 1:
                   if msg._from in admin:
                       if msg._from in settings["ChangeVideoProfilePicture"]:
                            del settings["ChangeVideoProfilePicture"][msg._from]
                            cl.downloadObjectMsg(msg_id,'path','image.jpg')
                            cl.nadyacantikimut('video.mp4','image.jpg')
                            sendFooter1(msg.to,"❒   Vidio Profile Sukses Boss")
               if msg.contentType == 1:
                  if msg._from in admin:
                     if settings["Addimage"]["status"] == True:
                         path = cl.downloadObjectMsg(msg.id)
                         images[settings["Addimage"]["name"]] = str(path)
                         f = codecs.open("image.json","w","utf-8")
                         json.dump(images, f, sort_keys=True, indent=4, ensure_ascii=False)
                         sendFooter1(msg.to, "❒   ᴅᴏɴᴇ ɢᴀᴍʙᴀʀ {}".format(str(settings["Addimage"]["name"])))
                         settings["Addimage"]["status"] = False
                         settings["Addimage"]["name"] = ""
               if msg.contentType == 2:
                  if msg._from in admin:
                     if settings["Addvideo"]["status"] == True:
                         path = cl.downloadObjectMsg(msg.id)
                         videos[settings["Addvideo"]["name"]] = str(path)
                         f = codecs.open("video.json","w","utf-8")
                         json.dump(videos, f, sort_keys=True, indent=4, ensure_ascii=False)
                         sendFooter1(msg.to, "❒   Berhasil menambahkan video {}".format(str(settings["Addvideo"]["name"])))
                         settings["Addvideo"]["status"] = False
                         settings["Addvideo"]["name"] = ""
               if msg.contentType == 7:
                  if msg._from in admin:
                     if settings["Addsticker"]["status"] == True:
                         stickers[settings["Addsticker"]["name"]] = {"STKID":msg.contentMetadata["STKID"],"STKPKGID":msg.contentMetadata["STKPKGID"]}
                         f = codecs.open("sticker.json","w","utf-8")
                         json.dump(stickers, f, sort_keys=True, indent=4, ensure_ascii=False)
                         sendFooter1(msg.to, "❒   ᴅᴏɴᴇ sᴛɪᴄᴋᴇʀ {}".format(str(settings["Addsticker"]["name"])))
                         settings["Addsticker"]["status"] = False
                         settings["Addsticker"]["name"] = ""
               if msg.contentType == 3:
                  if msg._from in admin:
                     if settings["Addaudio"]["status"] == True:
                         path = cl.downloadObjectMsg(msg.id)
                         audios[settings["Addaudio"]["name"]] = str(path)
                         f = codecs.open("audio.json","w","utf-8")
                         json.dump(audios, f, sort_keys=True, indent=4, ensure_ascii=False)
                         sendFooter1(msg.to, "❒   Berhasil menambahkan mp3 {}".format(str(settings["Addaudio"]["name"])))
                         settings["Addaudio"]["status"] = False
                         settings["Addaudio"]["name"] = ""
               if msg.contentType == 0:
                  if settings["autoRead"] == True:
                      cl.sendChatChecked(msg.to, msg_id)
                  if text is None:
                      return
                  else:
                         for sticker in stickers:
                            if text.lower() == sticker:
                               sid = stickers[text.lower()]["STKID"]
                               spkg = stickers[text.lower()]["STKPKGID"]
                               cl.sendSticker(to, spkg, sid)
                         for image in images:
                            if text.lower() == image:
                               cl.sendImage(msg.to, images[image])
                         for audio in audios:
                            if text.lower() == audio:
                               cl.sendAudio(msg.to, audios[audio])
                         for video in videos:
                            if text.lower() == video:
                               cl.sendVideo(msg.to, videos[video])
               if msg.contentType == 13:
                 if msg._from in owner:
                  if wait["addbots"] == True:
                    if msg.contentMetadata["mid"] in Bots:
                        sendFooter(msg.to,"❒   Already in bot")
                        wait["addbots"] = True
                    else:
                        Bots.append(msg.contentMetadata["mid"])
                        wait["addbots"] = True
                        sendFooter(msg.to,"❒   Succes add bot")
                 if wait["dellbots"] == True:
                    if msg.contentMetadata["mid"] in Bots:
                        Bots.remove(msg.contentMetadata["mid"])
                        sendFooter(msg.to,"❒   Succes delete bot")
                    else:
                        wait["dellbots"] = True
                        sendFooter(msg.to,"🌺 Nothing in bot")
#TEAM TERMUX
                 if msg._from in admin:
                  if wait["delFriend"] == True:
                      cl.deleteContact(msg.contentMetadata["mid"])
                      cl.sendReplyMention(msg_id, to, "🌺 Udh Euyyy @!", [sender])

                 if msg._from in admin:
                  if wait["addstaff"] == True:
                    if msg.contentMetadata["mid"] in staff:
                        sendFooter(msg.to,"🌺 ᴡᴇs ᴊᴀᴅɪ sᴛᴀғғ")
                        wait["addstaff"] = True
                    else:
                        staff.append(msg.contentMetadata["mid"])
                        wait["addstaff"] = True
                        sendFooter(msg.to,"🌺 ᴅᴏɴᴇ ᴀᴅᴅsᴛᴀғғ")
                 if wait["dellstaff"] == True:
                    if msg.contentMetadata["mid"] in staff:
                        staff.remove(msg.contentMetadata["mid"])
                        sendFooter(msg.to,"🌺 sᴛᴀғғ ᴅɪʜᴀᴘᴜs")
                        wait["dellstaff"] = True
                    else:
                        wait["dellstaff"] = True
                        sendFooter(msg.to,"🌺 Contact itu bukan staff")
#TEAM TERMUX
                 if msg._from in admin:
                  if wait["addadmin"] == True:
                    if msg.contentMetadata["mid"] in admin:
                        sendFooter(msg.to,"🌺 Contact itu sudah jadi admin")
                        wait["addadmin"] = True
                    else:
                        admin.append(msg.contentMetadata["mid"])
                        wait["addadmin"] = True
                        sendFooter(msg.to,"🌺 ᴅᴏɴᴇ ᴀᴅᴅᴀᴅᴍɪɴ")
                 if wait["delladmin"] == True:
                    if msg.contentMetadata["mid"] in admin:
                        admin.remove(msg.contentMetadata["mid"])
                        sendFooter(msg.to,"🌺 ᴀᴅᴍɪɴ ᴅɪʜᴀᴘᴜs")
                    else:
                        wait["delladmin"] = True
                        sendFooter(msg.to,"🌺 Contact itu bukan admin")
#SB TEAM TERMUX ??𝓸❒ 𝓴 𝓑❒ 𝓽𝓼  SB TEAM TERMUX
                 if msg._from in admin:
                  if wait["wblacklist"] == True:
                    if msg.contentMetadata["mid"] in wait["blacklist"]:
                        sendFooter1(msg.to,"Contact itu sudah ada di blacklist")
                        wait["wblacklist"] = True
                    else:
                        wait["blacklist"][msg.contentMetadata["mid"]] = True
                        wait["wblacklist"] = True
                        sendFooter1(msg.to,"Berhasil menambahkan ke blacklist user")
                  if wait["dblacklist"] == True:
                    if msg.contentMetadata["mid"] in wait["blacklist"]:
                        del wait["blacklist"][msg.contentMetadata["mid"]]
                        sendFooter1(msg.to,"Berhasil menghapus dari blacklist user")
                    else:
                        wait["dblacklist"] = True
                        sendFooter1(msg.to,"Contact itu tidak ada di blacklist")
#SB TEAM TERMUX ❒ 𝓸𝓻𝓴 SB TEAM TERMUX  SB TEAM TERMUX
                 if msg._from in admin:
                  if wait["Talkwblacklist"] == True:
                    if msg.contentMetadata["mid"] in wait["Talkblacklist"]:
                        sendFooter1(msg.to,"Contact itu sudah ada di Talkban")
                        wait["Talkwblacklist"] = True
                    else:
                        wait["Talkblacklist"][msg.contentMetadata["mid"]] = True
                        wait["Talkwblacklist"] = True
                        sendTextTemplate2(msg.to,"Berhasil menambahkan ke Talkban user")
                  if wait["Talkdblacklist"] == True:
                    if msg.contentMetadata["mid"] in wait["Talkblacklist"]:
                        del wait["Talkblacklist"][msg.contentMetadata["mid"]]
                        sendTextTemplate2(msg.to,"Berhasil menghapus dari Talkban user")
                    else:
                        wait["Talkdblacklist"] = True
                        sendFooter1(msg.to,"Contact itu tidak ada di Talkban")
#TEAM TERMUX
               if msg.contentType == 1:
                 if msg._from in owner:
                    if Setmain["Addimage"] == True:
                        msgid = msg.id
                        fotoo = "https://obs.line-apps.com/talk/m/download.nhn?oid="+msgid
                        headers = cl.Talk.Headers
                        r = requests.get(fotoo, headers=headers, stream=True)
                        if r.status_code == 200:
                            path = os.path.join(os.path.dirname(__file__), 'dataPhotos/%s.jpg' % Setmain["Img"])
                            with open(path, 'wb') as fp:
                                shutil.copyfileobj(r.raw, fp)
                            sendFooter1(msg.to, "Succes add picture")
                        Setmain["Img"] = {}
                        Setmain["Addimage"] = False
               if msg.contentType == 2:
               	if settings["changevp"] == True:
               		contact = cl.getProfile()
               		path = cl.downloadFileURL("https://obs.line-scdn.net/{}".format(contact.pictureStatus))
               		path1 = cl.downloadObjectMsg(msg_id)
               		settings["changevp"] = False
               		changeVideoAndPictureProfile(path, path1)
               		sendFooter1(to, "🌺 Sukses Ganti Photo")
               if msg.contentType == 2:
                 if msg._from in owner or msg._from in admin or msg._from in staff:
                   if settings["groupPicture"] == True:
                     path = cl.downloadObjectMsg(msg_id)
                     settings["groupPicture"] = False
                     cl.updateGroupPicture(msg.to, path)
                     sendFooter1(msg.to, "🌺 Sukses Ganti Photo")

               if msg.contentType == 1:
                 if msg._from in admin:
                        if mid in Setmain["RAfoto"]:
                            path = cl.downloadObjectMsg(msg_id)
                            del Setmain["RAfoto"][mid]
                            cl.updateProfilePicture(path)
                            sendFooter1(msg.to,"🌺 Sukses Ganti Photo")
               if msg.contentType == 1:
                 if msg._from in admin:
                   if settings["changePicture"] == True:
                     path5 = cl.downloadObjectMsg(msg_id)
                     settings["changePicture"] = False
                     cl.updateProfilePicture(path)
                     cl.sendMessage(msg.to, "🌺 Sukses Ganti Photo")
               if msg.contentType == 0:
                    if Setmain["autoRead"] == True:
                        cl.sendChatChecked(msg.to, msg_id)
                    if text is None:
                        return
                    else:
                        cmd = command(text)
                        if cmd == "keybot":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               helpMessage = keybot()
                               sendTextTemplate25(msg.to, str(helpMessage))
                        if cmd == "notifsmule on":
                            if msg._from in admin:
                                wait["smule"] = True
                                sendFooter1(msg.to, "🌺 Share Notif Smule Diaktifkan")
                        elif cmd == "notifsmule off":
                            if msg._from in admin:
                                wait["smule"] = False
                                sendFooter1(msg.to, "🌺 Share Notif Smule Dimatikan")
                        if cmd == "notifcall on":
                            if msg._from in admin:
                                wait["responGc"] = True
                                wait["responGc1"] = True
                                wait["responGc2"] = True
                                wait["responGc3"] = True
                                wait["responGc4"] = True
                                wait["responGc5"] = True
                                sendFooter1(msg.to, "🌺 ɴᴏᴛɪꜰᴄᴀʟʟ ɢʀᴜᴘ ᴛᴇʟᴀʜ ᴅɪᴀᴋᴛɪꜰᴋᴀɴ")
                        elif cmd == "notifcall off":
                            if msg._from in admin:
                                wait["responGc"] = False
                                wait["responGc1"] = False
                                wait["responGc2"] = False
                                wait["responGc3"] = False
                                wait["responGc4"] = False
                                wait["responGc5"] = False
                                sendFooter1(msg.to, "🌺 ɴᴏᴛɪꜰᴄᴀʟʟ ɢʀᴜᴘ ᴛᴇʟᴀʜ ᴅɪᴍᴀᴛɪᴋᴀɴ")
                        if cmd == "notifyoutube on":
                            if msg._from in admin:
                                wait["ytube"] = True
                                sendFooter1(msg.to, "🌺 ɴᴏᴛɪꜰʏᴏᴜᴛᴜʙᴇ ᴛᴇʟᴀʜ ᴅɪᴀᴋᴛɪꜰᴋᴀɴ")
                        elif cmd == "notifyoutube off":
                            if msg._from in admin:
                                wait["ytube"] = False
                                sendFooter1(msg.to, "🌺 ɴᴏᴛɪꜰʏᴏᴜᴛᴜʙᴇ ᴛᴇʟᴀʜ ᴅɪᴍᴀᴛɪᴋᴀɴ")
                        elif cmd == "cvp":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                            	settings["changevp"] = True
                            	sendFooter1(msg.to, "🌺 ꜱʜᴀʀᴇ ᴘʜᴏᴛᴏ ᴘʀᴏꜰɪʟᴇ")
                        elif cmd == "creator" or text.lower() == 'cr':
                            if msg._from in admin:
                                cl.sendText(msg.to,"ᴄʀᴇᴀᴛᴏʀ ᴋᴀᴍɪ ᴀᴅᴅ ʏᴀʜ") 
                                ma = "u1aaf34421b7a8a94e0a977095e4ff605"
                                for i in creator:
                                    ma = cl.getContact(i)
                                    cl.sendMessage(msg.to, None, contentMetadata={'mid': i}, contentType=13)
                        elif cmd == "respon" or cmd == "rp":
                          if wait["selfbot"] == True:
                            #ifg._from in admin:
                               start = time.time()
                               cl.sendMessage(msg.to, "TEAM TERMUX")
                               elapsed_time = time.time() - start
                               cl.sendMessage(msg.to, "Asiap Bos 😡".format(str(elapsed_time)))
                                                      
                      
                        elif cmd == "help":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               contact = cl.getProfile()
                               mids = [contact.mid]
                               #cover = cl.getProfileCoverURL(sender)
                               listTimeLiking = time.time()
                               warna1 = ("#00FFFF","#0000FF","#8B0000","#FF1493","#FFFF00")
                               warnanya1 = random.choice(warna1)   
                               warna2 = ("#FFFF00","#FF1493","#8B0000","#0000FF","#00FFFF")
                               warnanya2 = random.choice(warna2)                                
                               tz = pytz.timezone("Asia/Jakarta")
                               timeNow = datetime.now(tz=tz)
                               data = {
                                       "type": "flex",
                                       "altText": "TEAM TERMUX",
                                       "contents": 
{
  "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://i.ibb.co.com/JCNgjg8/ezgif-com-gif-maker.png",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:5",
            "gravity": "top",
            "animated": True
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "HELP COMEND",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "1px",
                "offsetStart": "35px"
              }
            ],
            "borderColor": "#00FFFF",
            "borderWidth": "1px",
            "cornerRadius": "2px",
            "width": "148px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "5px",
            "offsetStart": "5px",
            "backgroundColor": "#008000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [],
            "borderColor": "#00FFFF",
            "borderWidth": "1px",
            "cornerRadius": "2px",
            "width": "148px",
            "height": "60px",
            "position": "absolute",
            "offsetTop": "24px",
            "offsetStart": "5px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "TEAM TERMUX",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "1px",
                "offsetStart": "17px"
              }
            ],
            "position": "absolute",
            "borderColor": "#00FFFF",
            "borderWidth": "1px",
            "cornerRadius": "2px",
            "width": "148px",
            "height": "20px",
            "offsetTop": "83px",
            "offsetStart": "5px",
            "backgroundColor": "#8B0000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://i.ibb.co.com/9tdnpsd/1652980705963.jpg",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#00FFFF",
            "borderWidth": "1px",
            "cornerRadius": "2px",
            "width": "80px",
            "height": "60px",
            "position": "absolute",
            "offsetTop": "24px",
            "offsetStart": "5px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "SELFBOT",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "1px",
                "offsetStart": "10px"
              }
            ],
            "borderColor": "#00FFFF",
            "cornerRadius": "2px",
            "borderWidth": "1px",
            "width": "69px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "24px",
            "offsetStart": "84px",
            "backgroundColor": "#8B008B"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "TEMPLATE",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "1px",
                "offsetStart": "5px"
              }
            ],
            "position": "absolute",
            "borderColor": "#00FFFF",
            "borderWidth": "1px",
            "cornerRadius": "2px",
            "height": "20px",
            "width": "69px",
            "offsetTop": "43px",
            "offsetStart": "84px",
            "backgroundColor": "#006400"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "VERSION",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "8px"
              }
            ],
            "borderColor": "#00FFFF",
            "borderWidth": "1px",
            "cornerRadius": "2px",
            "width": "69px",
            "height": "22px",
            "position": "absolute",
            "offsetTop": "62px",
            "offsetStart": "84px",
            "backgroundColor": "#778899"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://obs.line-scdn.net/{}".format(cl.getContact(mid).pictureStatus),
                "size": "full",
                "aspectMode": "cover",
                "aspectRatio": "1:2"
              }
            ],
            "borderColor": "#00FFFF",
            "borderWidth": "1px",
            "cornerRadius": "2px",
            "width": "148px",
            "height": "290px",
            "position": "absolute",
            "offsetTop": "102px",
            "offsetStart": "5px",
            "backgroundColor": "#000000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "HELP COMEND",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "1px",
                "offsetStart": "30px"
              }
            ],
            "borderColor": "#00FFFF",
            "cornerRadius": "2px",
            "borderWidth": "1px",
            "width": "148px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "372px",
            "offsetStart": "5px",
            "backgroundColor": "#008000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "❂➣ listvideo\n❂➣ dellvideo\n❂➣ addvideo\n❂➣ listimage\n❂➣ dellimg\n❂➣ addimg\n❂➣ liststicker\n❂➣ dellsticker\n❂➣ addsticker\n❂➣ listmp3\n❂➣ dellmp3\n❂➣ addmp3\n❂➣ mempict\n❂➣ mp3:\n❂➣ cek sider\n❂➣ cek respon2\n❂➣ cek leave1\n❂➣ cek leave\n❂➣ cek welcome\n❂➣ cek welcome1\n❂➣ Set sider3:\n❂➣ Set respon3:\n", #1
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "1px",
                "offsetStart": "1px",
                "wrap": True
              }
            ],
            "borderColor": "#00FFFF",
            "borderWidth": "1px",
            "cornerRadius": "2px",
            "width": "148px",
            "height": "271px",
            "position": "absolute",
            "offsetTop": "102px",
            "offsetStart": "5px"
          }
        ],
        "paddingAll": "0px",
        "borderColor": warnanya2,
        "borderWidth": "1px",
        "cornerRadius": "10px"
      }
    }, # Batas Help
  {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://i.ibb.co.com/JCNgjg8/ezgif-com-gif-maker.png",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:5",
            "gravity": "top",
            "animated": True
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "HELP COMEND",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "1px",
                "offsetStart": "35px"
              }
            ],
            "borderColor": "#00FFFF",
            "borderWidth": "1px",
            "cornerRadius": "2px",
            "width": "148px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "5px",
            "offsetStart": "5px",
            "backgroundColor": "#008000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [],
            "borderColor": "#00FFFF",
            "borderWidth": "1px",
            "cornerRadius": "2px",
            "width": "148px",
            "height": "60px",
            "position": "absolute",
            "offsetTop": "24px",
            "offsetStart": "5px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "TEAM TERMUX",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "1px",
                "offsetStart": "17px"
              }
            ],
            "position": "absolute",
            "borderColor": "#00FFFF",
            "borderWidth": "1px",
            "cornerRadius": "2px",
            "width": "148px",
            "height": "20px",
            "offsetTop": "83px",
            "offsetStart": "5px",
            "backgroundColor": "#8B0000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://i.ibb.co.com/9tdnpsd/1652980705963.jpg",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#00FFFF",
            "borderWidth": "1px",
            "cornerRadius": "2px",
            "width": "80px",
            "height": "60px",
            "position": "absolute",
            "offsetTop": "24px",
            "offsetStart": "5px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "SELFBOT",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "1px",
                "offsetStart": "10px"
              }
            ],
            "borderColor": "#00FFFF",
            "cornerRadius": "2px",
            "borderWidth": "1px",
            "width": "69px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "24px",
            "offsetStart": "84px",
            "backgroundColor": "#8B008B"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "TEMPLATE",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "1px",
                "offsetStart": "5px"
              }
            ],
            "position": "absolute",
            "borderColor": "#00FFFF",
            "borderWidth": "1px",
            "cornerRadius": "2px",
            "height": "20px",
            "width": "69px",
            "offsetTop": "43px",
            "offsetStart": "84px",
            "backgroundColor": "#006400"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "VERSION",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "8px"
              }
            ],
            "borderColor": "#00FFFF",
            "borderWidth": "1px",
            "cornerRadius": "2px",
            "width": "69px",
            "height": "22px",
            "position": "absolute",
            "offsetTop": "62px",
            "offsetStart": "84px",
            "backgroundColor": "#778899"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://obs.line-scdn.net/{}".format(cl.getContact(mid).pictureStatus),
                "size": "full",
                "aspectMode": "cover",
                "aspectRatio": "1:2"
              }
            ],
            "borderColor": "#00FFFF",
            "borderWidth": "1px",
            "cornerRadius": "2px",
            "width": "148px",
            "height": "290px",
            "position": "absolute",
            "offsetTop": "102px",
            "offsetStart": "5px",
            "backgroundColor": "#000000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "HELP COMEND",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "1px",
                "offsetStart": "30px"
              }
            ],
            "borderColor": "#00FFFF",
            "cornerRadius": "2px",
            "borderWidth": "1px",
            "width": "148px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "372px",
            "offsetStart": "5px",
            "backgroundColor": "#008000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "❂➣ Set respon2:\n❂➣ Set respon:\n❂➣ Set autoleave:\n❂➣ Set autoleave1:\n❂➣ Set welcome1:\n❂➣ Set welcome:\n❂➣ Set hapus:\n❂➣ Set mention:\n❂➣ Set pesan:\n❂➣ cban\n❂➣ blc\n❂➣ byeme\n❂➣ ban:on/off\n❂➣ Unban\n❂➣ Ban\n❂➣ Staffdell\n❂➣ Admindell\n❂➣ Staffadd\n❂➣ Adminadd\n❂➣ refresh\n❂➣ unsend on/off\n❂➣ invite on/off\n", #1
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "1px",
                "offsetStart": "1px",
                "wrap": True
              }
            ],
            "borderColor": "#00FFFF",
            "borderWidth": "1px",
            "cornerRadius": "2px",
            "width": "148px",
            "height": "271px",
            "position": "absolute",
            "offsetTop": "102px",
            "offsetStart": "5px"
          }
        ],
        "paddingAll": "0px",
        "borderColor": warnanya1,
        "borderWidth": "1px",
        "cornerRadius": "10px"
      }
    }, # Batas
  {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://i.ibb.co.com/JCNgjg8/ezgif-com-gif-maker.png",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:5",
            "gravity": "top",
            "animated": True
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "HELP COMEND",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "1px",
                "offsetStart": "35px"
              }
            ],
            "borderColor": "#00FFFF",
            "borderWidth": "1px",
            "cornerRadius": "2px",
            "width": "148px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "5px",
            "offsetStart": "5px",
            "backgroundColor": "#008000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [],
            "borderColor": "#00FFFF",
            "borderWidth": "1px",
            "cornerRadius": "2px",
            "width": "148px",
            "height": "60px",
            "position": "absolute",
            "offsetTop": "24px",
            "offsetStart": "5px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "TEAM TERMUX",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "1px",
                "offsetStart": "17px"
              }
            ],
            "position": "absolute",
            "borderColor": "#00FFFF",
            "borderWidth": "1px",
            "cornerRadius": "2px",
            "width": "148px",
            "height": "20px",
            "offsetTop": "83px",
            "offsetStart": "5px",
            "backgroundColor": "#8B0000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://i.ibb.co.com/9tdnpsd/1652980705963.jpg",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#00FFFF",
            "borderWidth": "1px",
            "cornerRadius": "2px",
            "width": "80px",
            "height": "60px",
            "position": "absolute",
            "offsetTop": "24px",
            "offsetStart": "5px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "SELFBOT",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "1px",
                "offsetStart": "10px"
              }
            ],
            "borderColor": "#00FFFF",
            "cornerRadius": "2px",
            "borderWidth": "1px",
            "width": "69px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "24px",
            "offsetStart": "84px",
            "backgroundColor": "#8B008B"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "TEMPLATE",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "1px",
                "offsetStart": "5px"
              }
            ],
            "position": "absolute",
            "borderColor": "#00FFFF",
            "borderWidth": "1px",
            "cornerRadius": "2px",
            "height": "20px",
            "width": "69px",
            "offsetTop": "43px",
            "offsetStart": "84px",
            "backgroundColor": "#006400"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "VERSION",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "8px"
              }
            ],
            "borderColor": "#00FFFF",
            "borderWidth": "1px",
            "cornerRadius": "2px",
            "width": "69px",
            "height": "22px",
            "position": "absolute",
            "offsetTop": "62px",
            "offsetStart": "84px",
            "backgroundColor": "#778899"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://obs.line-scdn.net/{}".format(cl.getContact(mid).pictureStatus),
                "size": "full",
                "aspectMode": "cover",
                "aspectRatio": "1:2"
              }
            ],
            "borderColor": "#00FFFF",
            "borderWidth": "1px",
            "cornerRadius": "2px",
            "width": "148px",
            "height": "290px",
            "position": "absolute",
            "offsetTop": "102px",
            "offsetStart": "5px",
            "backgroundColor": "#000000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "HELP COMEND",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "1px",
                "offsetStart": "30px"
              }
            ],
            "borderColor": "#00FFFF",
            "cornerRadius": "2px",
            "borderWidth": "1px",
            "width": "148px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "372px",
            "offsetStart": "5px",
            "backgroundColor": "#008000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "❂➣ like on/off\n❂➣ post on/off\n❂➣ autoblock on/off\n❂➣ jointicket on/off\n❂➣ sticker on/off\n❂➣ autoadd on/off\n❂➣ autoleave on/off\n❂➣ autojoin on/off\n❂➣ contact on/off\n❂➣ respon4 on/off\n❂➣ respon2 on/off\n❂➣ respon on/off\n❂➣ respon3 on/off\n❂➣ Jepit\n❂➣ Cancelall\n❂➣ tiup\n❂➣ Gkick\n❂➣ Welcome on/off\n❂➣ Welcome1 on/off\n❂➣ spamcall\n❂➣ spamtag\n❂➣ naik\n", #1
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "1px",
                "offsetStart": "1px",
                "wrap": True
              }
            ],
            "borderColor": "#00FFFF",
            "borderWidth": "1px",
            "cornerRadius": "2px",
            "width": "148px",
            "height": "271px",
            "position": "absolute",
            "offsetTop": "102px",
            "offsetStart": "5px"
          }
        ],
        "paddingAll": "0px",
        "borderColor": warnanya2,
        "borderWidth": "1px",
        "cornerRadius": "10px"
      }
    }, #
  {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://i.ibb.co.com/JCNgjg8/ezgif-com-gif-maker.png",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:5",
            "gravity": "top",
            "animated": True
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "HELP COMEND",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "1px",
                "offsetStart": "35px"
              }
            ],
            "borderColor": "#00FFFF",
            "borderWidth": "1px",
            "cornerRadius": "2px",
            "width": "148px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "5px",
            "offsetStart": "5px",
            "backgroundColor": "#008000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [],
            "borderColor": "#00FFFF",
            "borderWidth": "1px",
            "cornerRadius": "2px",
            "width": "148px",
            "height": "60px",
            "position": "absolute",
            "offsetTop": "24px",
            "offsetStart": "5px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "TEAM TERMUX",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "1px",
                "offsetStart": "17px"
              }
            ],
            "position": "absolute",
            "borderColor": "#00FFFF",
            "borderWidth": "1px",
            "cornerRadius": "2px",
            "width": "148px",
            "height": "20px",
            "offsetTop": "83px",
            "offsetStart": "5px",
            "backgroundColor": "#8B0000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://i.ibb.co.com/9tdnpsd/1652980705963.jpg",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#00FFFF",
            "borderWidth": "1px",
            "cornerRadius": "2px",
            "width": "80px",
            "height": "60px",
            "position": "absolute",
            "offsetTop": "24px",
            "offsetStart": "5px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "SELFBOT",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "1px",
                "offsetStart": "10px"
              }
            ],
            "borderColor": "#00FFFF",
            "cornerRadius": "2px",
            "borderWidth": "1px",
            "width": "69px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "24px",
            "offsetStart": "84px",
            "backgroundColor": "#8B008B"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "TEMPLATE",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "1px",
                "offsetStart": "5px"
              }
            ],
            "position": "absolute",
            "borderColor": "#00FFFF",
            "borderWidth": "1px",
            "cornerRadius": "2px",
            "height": "20px",
            "width": "69px",
            "offsetTop": "43px",
            "offsetStart": "84px",
            "backgroundColor": "#006400"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "VERSION",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "8px"
              }
            ],
            "borderColor": "#00FFFF",
            "borderWidth": "1px",
            "cornerRadius": "2px",
            "width": "69px",
            "height": "22px",
            "position": "absolute",
            "offsetTop": "62px",
            "offsetStart": "84px",
            "backgroundColor": "#778899"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://obs.line-scdn.net/{}".format(cl.getContact(mid).pictureStatus),
                "size": "full",
                "aspectMode": "cover",
                "aspectRatio": "1:2"
              }
            ],
            "borderColor": "#00FFFF",
            "borderWidth": "1px",
            "cornerRadius": "2px",
            "width": "148px",
            "height": "290px",
            "position": "absolute",
            "offsetTop": "102px",
            "offsetStart": "5px",
            "backgroundColor": "#000000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "HELP COMEND",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "1px",
                "offsetStart": "30px"
              }
            ],
            "borderColor": "#00FFFF",
            "cornerRadius": "2px",
            "borderWidth": "1px",
            "width": "148px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "372px",
            "offsetStart": "5px",
            "backgroundColor": "#008000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "❂➣ unsendme\n❂➣ clone\n❂➣ speed\n❂➣ tagall\n❂➣ sider on/off\n❂➣ sider2 on/off\n❂➣ sider3 on/off\n❂➣ myname:\n❂➣ myfoto\n❂➣ upgrup\n❂➣ publik on/off\n❂➣ close qr\n❂➣ open qr\n❂➣ gruplist\n❂➣ Invite\n❂➣ friendlist\n❂➣ infomem\n❂➣ infogrup\n❂➣ ginfo\n❂➣ listmember\n❂➣ listpending\n❂➣ runtime\n", #1
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "1px",
                "offsetStart": "1px",
                "wrap": True
              }
            ],
            "borderColor": "#00FFFF",
            "borderWidth": "1px",
            "cornerRadius": "2px",
            "width": "148px",
            "height": "271px",
            "position": "absolute",
            "offsetTop": "102px",
            "offsetStart": "5px"
          }
        ],
        "paddingAll": "0px",
        "borderColor": warnanya1,
        "borderWidth": "1px",
        "cornerRadius": "10px"
      }
    }, #
  {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://i.ibb.co.com/JCNgjg8/ezgif-com-gif-maker.png",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:5",
            "gravity": "top",
            "animated": True
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "HELP COMEND",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "1px",
                "offsetStart": "35px"
              }
            ],
            "borderColor": "#00FFFF",
            "borderWidth": "1px",
            "cornerRadius": "2px",
            "width": "148px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "5px",
            "offsetStart": "5px",
            "backgroundColor": "#008000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [],
            "borderColor": "#00FFFF",
            "borderWidth": "1px",
            "cornerRadius": "2px",
            "width": "148px",
            "height": "60px",
            "position": "absolute",
            "offsetTop": "24px",
            "offsetStart": "5px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "TEAM TERMUX",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "1px",
                "offsetStart": "17px"
              }
            ],
            "position": "absolute",
            "borderColor": "#00FFFF",
            "borderWidth": "1px",
            "cornerRadius": "2px",
            "width": "148px",
            "height": "20px",
            "offsetTop": "83px",
            "offsetStart": "5px",
            "backgroundColor": "#8B0000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://i.ibb.co.com/9tdnpsd/1652980705963.jpg",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#00FFFF",
            "borderWidth": "1px",
            "cornerRadius": "2px",
            "width": "80px",
            "height": "60px",
            "position": "absolute",
            "offsetTop": "24px",
            "offsetStart": "5px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "SELFBOT",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "1px",
                "offsetStart": "10px"
              }
            ],
            "borderColor": "#00FFFF",
            "cornerRadius": "2px",
            "borderWidth": "1px",
            "width": "69px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "24px",
            "offsetStart": "84px",
            "backgroundColor": "#8B008B"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "TEMPLATE",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "1px",
                "offsetStart": "5px"
              }
            ],
            "position": "absolute",
            "borderColor": "#00FFFF",
            "borderWidth": "1px",
            "cornerRadius": "2px",
            "height": "20px",
            "width": "69px",
            "offsetTop": "43px",
            "offsetStart": "84px",
            "backgroundColor": "#006400"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "VERSION",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "8px"
              }
            ],
            "borderColor": "#00FFFF",
            "borderWidth": "1px",
            "cornerRadius": "2px",
            "width": "69px",
            "height": "22px",
            "position": "absolute",
            "offsetTop": "62px",
            "offsetStart": "84px",
            "backgroundColor": "#778899"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://obs.line-scdn.net/{}".format(cl.getContact(mid).pictureStatus),
                "size": "full",
                "aspectMode": "cover",
                "aspectRatio": "1:2"
              }
            ],
            "borderColor": "#00FFFF",
            "borderWidth": "1px",
            "cornerRadius": "2px",
            "width": "148px",
            "height": "290px",
            "position": "absolute",
            "offsetTop": "102px",
            "offsetStart": "5px",
            "backgroundColor": "#000000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "HELP COMEND",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "1px",
                "offsetStart": "30px"
              }
            ],
            "borderColor": "#00FFFF",
            "cornerRadius": "2px",
            "borderWidth": "1px",
            "width": "148px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "372px",
            "offsetStart": "5px",
            "backgroundColor": "#008000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "❂➣ notifcall on/off\n❂➣ reboot\n❂➣ Contact:\n❂➣ Getmid\n❂➣ addme\n❂➣ block\n❂➣ broadcast:\n❂➣ kalender\n❂➣ Getbio\n❂➣ listblock\n❂➣ Getinfo\n❂➣ Getprofile\n❂➣ stickerjumbo on/off\n❂➣ setting\n❂➣ autoread on/off\n❂➣ cvp\n❂➣ notifsmule on/off\n❂➣ mybio\n❂➣ Picture\n", #1
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "1px",
                "offsetStart": "1px",
                "wrap": True
              }
            ],
            "borderColor": "#00FFFF",
            "borderWidth": "1px",
            "cornerRadius": "2px",
            "width": "148px",
            "height": "271px",
            "position": "absolute",
            "offsetTop": "102px",
            "offsetStart": "5px"
          }
        ],
        "paddingAll": "0px",
        "borderColor": warnanya2,
        "borderWidth": "1px",
        "cornerRadius": "10px"
      }
    }
  ]
}
}

                               cl.postTemplate(to, data)

                        elif cmd == "setting":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                contact = cl.getProfile()
                                mids = [contact.mid]
                                #cover = cl.getProfileCoverURL(sender)
                                listTimeLiking = time.time()
                                tz = pytz.timezone("Asia/Jakarta")
                                timeNow = datetime.now(tz=tz)
                                md = "╔════════════════\n"
                                if settings["checkPost"] == True: md+="╟🔵 checkPost\n"
                                else: md+="╟🔴 checkPost \n"
                                if wait["contact"] == True: md+="╟🔵 contact\n"
                                else: md+="╟🔴 contact\n"
                                if wait["Mentionkick"] == True: md+="╟🔵 Mentionkick\n"
                                else: md+="╟🔴 Mentionkick\n"
                                if wait["detectMention"] == True: md+="╟🔵 detectMention\n"
                                else: md+="╟🔴 detectMention\n"
                                if wait["detectMention2"] == True: md+="╟🔵 detectMention2\n"
                                else: md+="╟🔴 detectMention2\n"
                                if wait["detectMention3"] == True: md+="╟🔵 detectMention3\n"
                                else: md+="╟🔴 detectMention3\n"
                                if wait["detectMention4"] == True: md+="╟🔵 detectMention4\n"
                                else: md+="╟🔴 detectMention4\n"                              
                                if wait["Unsend"] == True: md+="╟🔵 Unsend\n"
                                else: md+="╟🔴 Unsend\n"
                                if wait["autoAdd"] == True: md+="╟🔵 autoAdd\n"
                                else: md+="╟🔴 autoAdd\n"
                                if wait["autoLeave"] == True: md+="╟🔵 autoLeave\n"
                                else: md+="╟🔴 autoLeave\n"
                                if wait["autoJoin"] == True: md+="╟🔵 autoJoin\n"
                                else: md+="╟🔴 autoJoin\n"
                                if wait["sticker"] == True: md+="╟🔵 sticker\n"
                                else: md+="╟🔴 sticker\n"
                                if settings["autoJoinTicket"] == True: md+="╟🔵 autoJoinTicket\n"
                                else: md+="╟🔴 autoJoinTicket\n"
                                if wait["autoReject"] == True: md+="╟🔵 autoReject\n"
                                else: md+="╟🔴 autoReject\n"
                                if wait["autoBlock"] == True: md+="╟🔵 autoBlock\n"
                                else: md+="╟🔴 autoBlock\n"
                                if wait["smule"] == True: md+="╟🔵 smule\n"
                                else: md+="╟🔴 smule\n"
                                if wait["responGc"] == True: md+="╟🔵 responGc\n"
                                else: md+="╟🔴 responGc\n"
                                if wait["ytube"] == True: md+="╟🔵 ytube\n"
                                else: md+="╟🔴 ytube\n"                             
                                if settings["welcome"] == True: md+="╟🔵 wellcome\n"
                                else: md+="╟🔴 wellcome\n╰──────────────╯"                         
                                sendTextSeting(msg.to, md+"\n📅 ᴛᴀɴɢɢᴀʟ : "+ datetime.strftime(timeNow,'%Y-%m-%d')+"\n⏰ ᴊᴀᴍ [ "+ datetime.strftime(timeNow,'%H:%M:%S')+" ]")
                     
#===========================================================
                        elif cmd == "bot" or text.lower() == 'bot' or text.lower() == '1368o' or text.lower() == 'bot':
                          if wait["selfbot"] == True:                            
                               sendFooter2(msg.to, "ɢᴜᴇ ʙᴜᴋᴀɴ ʙᴏᴛ ᴋᴜʏᴀ ʟᴏᴇ ʏᴀɴɢ ʙᴏᴛ")
                               
                        elif cmd == "pm" or text.lower() == 'pm' or text.lower() == '1368o' or text.lower() == 'bot':
                          if wait["selfbot"] == True:                            
                               sendFooter2(msg.to, "ᴍᴀᴀꜰ ᴛɪᴅᴀᴋ ᴍᴇɴᴇʀɪᴍᴀ ᴘᴍ")
                               
                        elif cmd == "bang" or text.lower() == 'bang' or text.lower() == '1368o' or text.lower() == 'bot':
                          if wait["selfbot"] == True:                            
                               sendFooter2(msg.to, "ᴀᴅᴀ ᴀᴘᴀ ꜱᴀʏᴀɴɢ ᴍᴀᴜ ᴍɪɴᴛᴀ ᴊᴀᴛᴀʜ ʏᴀʜ")
                               
                        elif cmd == "sepi" or text.lower() == 'sepi' or text.lower() == '1368o' or text.lower() == 'bot':
                          if wait["selfbot"] == True:                            
                               sendFooter2(msg.to, "ꜱᴇᴘɪ ᴛɪᴅᴀᴋ ᴀᴅᴀ ᴏʀᴀɴɢ ʟᴀɢɪ ᴘᴀᴅᴀ ᴋᴇʟᴏɴ ᴍᴜɴɢᴋɪɴ")
                               
                        elif cmd == "kangen" or text.lower() == 'kangen' or text.lower() == '1368o' or text.lower() == 'bot':
                          if wait["selfbot"] == True:                            
                               sendFooter2(msg.to, "ꜱᴀᴍᴀ ꜱᴀʏᴀɴɢ ᴀᴋᴜ ᴊᴜɢᴀ ᴋᴀɴɢᴇɴ ᴋᴀᴍᴜ ᴄɪᴜᴍ ᴅᴜʟᴜ ᴅᴏɴɢ")
                               
                        elif cmd == "selamat malam" or text.lower() == 'selamat malam' or text.lower() == '1368o' or text.lower() == 'bot':
                          if wait["selfbot"] == True:                            
                               sendFooter2(msg.to, "ᴍᴀʟᴀᴍ ᴊᴜɢᴀ ꜱᴀʏᴀɴɢ ᴊᴀɴɢᴀɴ ʟᴜᴘᴀ ᴛɪᴅᴜʀ ʏᴀʜ")
                               
                        elif cmd == "selamat pagi" or text.lower() == 'selamat pagi' or text.lower() == '1368o' or text.lower() == 'bot':
                          if wait["selfbot"] == True:                            
                               sendFooter2(msg.to, "ꜱᴇʟᴀᴍᴀᴛ ᴘᴀɢɪ ᴊᴜɢᴀ ꜱᴀʏᴀɴɢᴋᴜ ᴊᴀɴɢᴀɴ ʟᴜᴘᴀ ʙᴀʜᴀɢɪᴀ")
                               
                        elif cmd == "assalamualaikum" or text.lower() == 'as' or text.lower() == '1368o' or text.lower() == 'bot':
                          if wait["selfbot"] == True:                            
                               sendFooter2(msg.to, "ُوَعَلَيْكُمْ السَّلاَمُ وَرَحْمَةُ اللهِ وَبَرَكَاتُهُ  ")
                               
                        elif cmd == "selamat siang" or text.lower() == 'selamat siang' or text.lower() == '1368o' or text.lower() == 'bot':
                          if wait["selfbot"] == True:                            
                               sendFooter2(msg.to, "ꜱᴇʟᴀᴍᴀᴛ ꜱɪᴀɴɢ ꜱᴀʏᴀɴɢ ᴊᴀɴɢᴀɴ ʟᴜᴘᴀ ɴɢᴏᴘɪ ʙɪᴀʀ ʙᴀʜᴀɢɪᴀ")
                               
                        elif cmd == "selamat sore" or text.lower() == 'selamat sore' or text.lower() == '1368o' or text.lower() == 'bot':
                          if wait["selfbot"] == True:                            
                               sendFooter2(msg.to, "ꜱᴇʟᴀᴍᴀᴛ ꜱᴏʀᴇ ᴊᴜɢᴀ ᴊᴀɴɢᴀɴ ʟᴜᴘᴀ ᴍᴀɴᴅɪ ʏᴀɴɢ ʙᴇʀꜱɪʜ")
                               
                        elif cmd == "pm mesla" or text.lower() == 'pm mesla' or text.lower() == '1368o' or text.lower() == 'bot':
                          if wait["selfbot"] == True:                            
                               sendFooter2(msg.to, "ᴘᴍ ᴍᴇꜱʀᴀ ᴍᴀᴜ ᴘɪɴᴊᴇᴍ ᴅᴜɪᴛ ɴɪʜ ᴏʀᴀɴɢ")
                               
                        elif cmd == "kojom" or text.lower() == 'kojom' or text.lower() == '1368o' or text.lower() == 'bot':
                          if wait["selfbot"] == True:                            
                               sendFooter2(msg.to, "ᴋᴏᴊᴏᴍ ᴍᴜʟᴜ ᴀᴡᴀꜱ ʜᴘ ɴʏᴀʜ ʙᴜɴᴛɪɴɢ")
                               
                        elif cmd == "bentar" or text.lower() == 'bentar' or text.lower() == '1368o' or text.lower() == 'bot':
                          if wait["selfbot"] == True:                            
                               sendFooter2(msg.to, "ʙᴇɴᴛᴀʀ ᴀᴋᴜ ᴀᴅᴀ ᴛᴀᴍᴜ ᴘᴀᴋ ʀᴛ ꜱᴜʀᴜʜ ʙɪᴋɪɴᴋᴀɴ ᴋᴏᴘɪ")
                               
                        elif cmd == "salken semua" or text.lower() == 'salken semua' or text.lower() == '1368o' or text.lower() == 'bot':
                          if wait["selfbot"] == True:                            
                               sendFooter2(msg.to, "ꜱᴇᴍᴜᴀ ɪᴛᴜ ꜱɪᴀᴘᴀ ᴀᴊᴀʜ ᴀᴋᴜ ᴛᴇʀᴍᴀꜱᴜᴋ ɢᴀ ɴɪʜ")
                               
                        elif cmd == "wc" or text.lower() == 'wc' or text.lower() == '1368o' or text.lower() == 'bot':
                          if wait["selfbot"] == True:                            
                               sendFooter2(msg.to, "ꜱᴇʟᴀᴍᴀᴛ ᴅᴀᴛᴀɴɢ ᴅɪ ʀᴏᴏᴍ ᴋᴀᴍɪ ꜱᴀʟᴀᴍ ᴋᴇɴᴀʟ ʏᴀʜ ᴅᴀʀɪ ᴀᴋᴜ ᴊᴀɴɢᴀɴ ʟᴜᴘᴀ ᴘᴍ ᴍᴇꜱʀᴀ")
                               
                        elif cmd == "sibuk" or text.lower() == 'sibuk' or text.lower() == '1368o' or text.lower() == 'bot':
                          if wait["selfbot"] == True:                            
                               sendFooter2(msg.to, "ꜱɪʙᴜᴋ ᴍᴀᴜ ᴋᴇᴍᴀɴᴀ ᴘᴀʟɪɴɢ ᴋᴇʟᴏɴ ꜱᴀᴍᴀ ʙᴏᴊᴏɴʏᴀʜ")
                               
                        elif cmd == "wa" or text.lower() == 'wa' or text.lower() == '1368o' or text.lower() == 'bot':
                          if wait["selfbot"] == True:                            
                               sendFooter2(msg.to, "وَعَلَيْكُمْ السَّلاَمُ وَرَحْمَةُ اللهِ وَبَرَكَاتُهُ  ")
                               
                        elif cmd == "puskun" or text.lower() == 'puskun' or text.lower() == '1368o' or text.lower() == 'bot':
                          if wait["selfbot"] == True:                            
                               sendFooter2(msg.to, "ᴀᴡᴀꜱ ᴛᴜʜ ᴀɴᴀᴋ ᴏʀᴀɴɢ ᴅɪ ʙᴀᴘᴇʀɪɴ ᴋᴀꜱɪᴀɴ ʟᴏʜ")
                               
                        elif cmd == "tunggu bentar" or text.lower() == 'tunggu bentar' or text.lower() == '1368o' or text.lower() == 'bot':
                          if wait["selfbot"] == True:                            
                               sendFooter2(msg.to, "ʙᴇɴᴛᴀʀ ᴀᴅᴀ ᴘᴀᴋ ʀᴛ")
                               
                        elif cmd == "war" or text.lower() == 'war' or text.lower() == '1368o' or text.lower() == 'bot':
                          if wait["selfbot"] == True:                            
                               sendFooter2(msg.to, "ᴄᴏʙᴀ ʀᴇꜱᴘᴏɴɪɴ ʙᴏᴛɴʏᴀ")
                               
                        elif cmd == "naik" or text.lower() == 'naik' or text.lower() == '1368o' or text.lower() == 'bot':
                          if wait["selfbot"] == True:                            
                               sendFooter2(msg.to, "ɴᴀɪᴋ ᴋᴇᴍᴀɴᴀ ꜱᴀʏᴀʜ ʙᴇʟᴜᴍ ᴘɪɴᴊᴀᴍ ᴛᴀɴɢɢᴀ")
                               
                        elif cmd == "banyak cctv" or text.lower() == 'banyak cctv' or text.lower() == '1368o' or text.lower() == 'bot':
                          if wait["selfbot"] == True:                            
                               sendFooter2(msg.to, "ɪʏᴀʜ ᴘᴀᴅᴀ ɴʏɪᴍᴀᴋ ɪᴛᴜ ᴊᴏɴᴇꜱ ꜱᴇᴍᴜᴀ")
                               
                        elif cmd == "done" or text.lower() == 'sukses' or text.lower() == '1368o' or text.lower() == 'bot':
                          if wait["selfbot"] == True:         
                            if msg._from in owner or msg._from in admin:
                               sendFooter2(msg.to, "ʙɪʟᴀɴɢ ᴛᴇʀɪᴍᴀᴋᴀꜱɪʜ ᴋᴇ ʙᴀɴɢ ʀᴀᴋᴀ ꜱʙ ɴʏᴀʜ ꜱᴜᴅᴀʜ ʙᴇʀʜᴀꜱɪʟ ʟᴏɢɪɴ ᴅᴀɴ ᴊᴀɴɢᴀɴ ʟᴜᴘᴀ ɴᴀɴᴛɪ ᴍᴀʟᴀᴍ ᴋᴏᴊᴏᴍ ʏᴀʜ")
                               
                        elif cmd == "good night" or text.lower() == 'good night' or text.lower() == '1368o' or text.lower() == 'bot':
                          if wait["selfbot"] == True:                            
                               sendFooter2(msg.to, "ꜱᴇʟᴀᴍᴀᴛ ᴍᴀʟᴀᴍ ᴊᴜɢᴀ ꜱᴇʟᴀᴍᴀᴛ ʙᴏʙᴏ ᴍɪᴍᴘɪ ɪɴᴅᴀʜ ʏᴀʜ ꜱᴀʏᴀɴɢᴋᴜ")
                               
                        elif cmd == "bang pm" or text.lower() == 'bang pm' or text.lower() == '1368o' or text.lower() == 'bot':
                          if wait["selfbot"] == True:                            
                               sendFooter2(msg.to, "ᴘᴍ ᴍᴀᴜ ᴍᴏᴅᴜꜱ ɴɪʜ ᴏʀᴀɴɢ ᴘᴀʟɪɴɢ ɴɢᴀᴊᴀᴋɪɴ ᴋᴏᴊᴏᴍ")
                             
                        elif cmd == "d" or text.lower() == 'd' or text.lower() == '1368o' or text.lower() == 'bot':
                          if wait["selfbot"] == True:                            
                               sendFooter2(msg.to, "Dengan Adanyah Kamu Aku Merasa Bahagia")                              
                             
                        elif cmd == "sinyal" or text.lower() == 'sinyal' or text.lower() == '1368o' or text.lower() == 'bot':
                          if wait["selfbot"] == True:                            
                               sendFooter2(msg.to, "ᴄᴏʙᴀ ɴᴀɪᴋ ᴛɪʜᴀɴɢ ʙᴇɴᴅᴇʀᴀ ʙɪᴀʀ ʙᴀɴʏᴀᴋ ꜱɪɴʏᴀʟ")
                                                  
                        elif cmd == "wait" or text.lower() == 'wait' or text.lower() == '1368o' or text.lower() == 'bot':
                          if wait["selfbot"] == True:                            
                               sendFooter2(msg.to, "ᴡᴀɪᴛ ɪᴛᴜ ᴀᴘᴀᴀɴ ꜱᴀʏᴀʜ ᴛɪᴅᴀᴋ ᴘᴀʜᴀᴍ ʙᴀʜᴀꜱᴀɴʏᴀ")
                               
                        elif cmd == "dudul" or text.lower() == 'dudul' or text.lower() == '1368o' or text.lower() == 'bot':
                          if wait["selfbot"] == True:                            
                               sendFooter2(msg.to, "ᴋᴀᴍᴜ ᴛᴜʜ ʏᴀɴɢ ᴅᴜᴅᴜʟ ᴋᴜʏᴀ ᴅᴀꜱᴀʀ")
                               
                        elif cmd == "bomat" or text.lower() == 'bomat' or text.lower() == '1368o' or text.lower() == 'bot':
                          if wait["selfbot"] == True:                            
                               sendFooter2(msg.to, "ʙᴏᴍᴀᴛ ɪᴛᴜ ᴀᴘᴀᴀɴ ꜱᴀʏᴀʜ ɢᴀ ᴘᴀʜᴀᴍ ᴋᴋ")
                               
                        elif cmd == "awas" or text.lower() == 'awas' or text.lower() == '1368o' or text.lower() == 'bot':
                          if wait["selfbot"] == True:                            
                               sendFooter2(msg.to, "ᴀᴡᴀꜱ ᴅɪᴀ ᴘᴇʟᴀᴋᴏʀ ᴊᴀɴɢᴀɴ ᴍᴇɴᴅᴇᴋᴀᴛ")
                               
                        elif cmd == "salken" or text.lower() == 'salken':
                          if wait["selfbot"] == True:                            
                               sendFooter2(msg.to, "ꜱᴀʟᴋᴇɴ ᴍᴜʟᴜ ᴊᴀᴅɪᴀɴ ᴋᴀɢᴀᴋ ᴋᴀɴ ꜱᴜᴇ ")
                               
                        elif cmd == "as" or text.lower() == 'as':
                          if wait["selfbot"] == True:         
                           if msg._from in owner or msg._from in admin:                    
                               sendFooter2(msg.to, "السَّلاَمُ عَلَيْكُمْ وَرَحْمَةُ اللهِ ")
                               
                          elif cmd == "sue" or text.lower() == 'sue':
                           if wait["selfbot"] == True:                            
                               sendFooter2(msg.to, "ᴀᴘᴀɴ ꜱɪʜ ᴘᴇᴀ ᴋᴍᴜ")
                               
                          elif cmd == "asem" or text.lower() == 'asem':
                           if wait["selfbot"] == True:                            
                               sendFooter2(msg.to, "ꜱᴜᴇ ʏᴀʜ ᴅɪ ᴊᴀʜɪᴛ ʟᴀʜ ʙɪᴀʀ ᴘᴇʀᴀᴡᴀɴ ʟᴀɢɪ")
                               
                          elif cmd == "walaikumsalam" or text.lower() == 'walaikumsalam':
                           if wait["selfbot"] == True:                            
                               sendFooter2(msg.to, "ꜱᴇꜱᴀᴍᴀ ᴏʀᴀɴɢ ᴍᴜꜱʟɪᴍ ᴡᴀᴊɪʙ ᴛᴜʜ ᴊᴀᴡᴀʙ ꜱᴀʟᴀᴍ")
                                                 
                        elif cmd == "kikil" or text.lower() == 'kikil':
                          if wait["selfbot"] == True:                            
                               sendFooter2(msg.to, "ʟᴏᴇ ᴛᴜʜ ʏᴀɴɢ ᴋɪᴋɪʟ ᴛᴜᴋᴀɴɢ ᴊꜱ ʀᴏᴏᴍ ᴏʀᴀɴɢ")
                               
                        elif cmd == "nah" or text.lower() == 'nahhh':
                          if wait["selfbot"] == True:                            
                               sendFooter2(msg.to, "ɴᴀʜ ᴋᴇɴᴀᴘᴀ ꜱᴜᴅᴀʜ ᴄᴀᴘᴇ ʏᴀʜ ᴍᴏᴅᴜꜱɪɴ ᴏʀᴀɴɢ")
                               
                        elif cmd == "liff":
                          if wait["selfbot"] == True:      
                           if msg._from in owner or msg._from in admin:
                               sendFooter2(msg.to, "line://app/1602687308-GXq4Vvk9")
#===========================================================
                        elif text.lower() == "mid":
                          if wait["selfbot"] == True:
                           if msg._from in owner or msg._from in admin:
                               middd = "Name : " +cl.getContact(msg._from).displayName + "\nMid : " +msg._from
                               sendFooter(msg.to,middd)
                         
                        elif ("gname " in msg.text):
                          if msg._from in admin:
                              X = cl.getGroup(msg.to)
                              X.name = msg.text.replace("Gname ","")
                              cl.updateGroup(X)

                        elif "gruppict" in msg.text:
                          if msg._from in admin:
                                group = cl.getGroup(msg.to)
                                path = "http://dl.profile.line-cdn.net/" + group.pictureStatus
                                cl.sendImageWithURL(msg.to,path)

                        elif "getprofile " in msg.text:
                          if msg._from in admin:
                            if msg.contentMetadata is not None and 'MENTION' in msg.contentMetadata:
                                names = re.findall(r'@(\w+)', msg.text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                for mention in mentionees:
                                    try:
                                        profile = cl.getContact(mention['M'])
                                        cl.sendImageWithURL(msg.to,"http://dl.profile.line.naver.jp/"+profile.pictureStatus)
                                    except Exception as e:
                                        pass

                        elif "getinfo " in msg.text:
                          if msg._from in admin:
                            key = eval(msg.contentMetadata["MENTION"])
                            key1 = key["MENTIONEES"][0]["M"]
                            contact = cl.getContact(key1)
                            image = "http://dl.profile.line-cdn.net/" + contact.pictureStatus
                            try:
                                sendFooter1(msg.to,"Nama:\n" + contact.displayName)
                                sendFooter1(msg.to,"Bio:\n" + contact.statusMessage)
                                cl.sendImageWithURL(msg.to,image)
                            except:
                                pass

                        elif cmd == 'listblock':
                          if msg._from in admin:
                            blockedlist = cl.getBlockedContactIds()
                            kontak = cl.getContacts(blockedlist)
                            num=1
                            msgs="List Blocked"
                            for ids in kontak:
                                msgs+="\n[%i] %s" % (num, ids.displayName)
                                num=(num+1)
                            msgs+="\n\nTotal Blocked : %i" % len(kontak)
                            sendTextTemplate2(to, msgs)

                        elif "Getbio " in msg.text:
                          if msg._from in admin:
                            key = eval(msg.contentMetadata["MENTION"])
                            key1 = key["MENTIONEES"][0]["M"]
                            contact = cl.getContact(key1)
                            try:
                                sendFooter1(msg.to,contact.statusMessage)
                            except:
                                sendFooter1(msg.to,"⟦ʙɪᴏ ᴇᴍᴘᴛʏ⟧")

                        elif text.lower() == 'kalender':
                          if msg._from in admin:
                            tz = pytz.timezone("Asia/Jakarta")
                            timeNow = datetime.now(tz=tz)
                            day = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday","Friday", "Saturday"]
                            hari = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"]
                            bulan = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"]
                            hr = timeNow.strftime("%A")
                            bln = timeNow.strftime("%m")
                            for i in range(len(day)):
                                if hr == day[i]: hasil = hari[i]
                            for k in range(0, len(bulan)):
                                if bln == str(k): bln = bulan[k-1]
                            readTime = "❒   "+ hasil + " : " + timeNow.strftime('%d') + " - " + bln + " - " + timeNow.strftime('%Y') + "\n\n❒   Jam : ❒   " + timeNow.strftime('%H:%M:%S') + " ❒  "
                            sendFooter2(msg.to, readTime)

                        elif cmd.startswith("unsendme "):
                          if msg._from in admin:
                            args = cmd.replace("unsendme ","")
                            mes = 0
                            try:
                                mes = int(args[1])
                            except:
                                mes = 1
                            M = cl.getRecentMessagesV2(to, 101)
                            MId = []
                            for ind,i in enumerate(M):
                                if ind == 0:
                                    pass
                                else:
                                    if i._from == cl.profile.mid:
                                        MId.append(i.id)
                                        if len(MId) == mes:
                                            break
                            def unsMes(id):
                                cl.unsendMessage(id)
                            for i in MId:
                                thread1 = threading.Thread(target=unsMes, args=(i,))
                                thread1.start()
                                thread1.join()
                            sendFooter1(msg.to, "Success unsend {} message".format(len(MId)))

                        elif cmd == "myname":
                          if msg._from in admin:
                            contact = cl.getContact(sender)
                            sendFooter1(to, "[ ᴅɪsᴘʟᴀʏ ɴᴀᴍᴇ ]\n{}".format(contact.displayName))

                        elif cmd == "mybio":
                          if msg._from in admin:
                            contact = cl.getContact(sender)
                            sendFooter1(to, "[ sᴛᴀᴛᴜs ʟɪɴᴇ ]\n{}".format(contact.statusMessage))

                        elif cmd == "Picture":
                          if msg._from in admin:
                            contact = cl.getContact(sender)
                            cl.sendImageWithURL(to,"http://dl.profile.line-cdn.net/{}".format(contact.pictureStatus))

                        elif cmd == "myvideo":
                          if msg._from in admin:
                            contact = cl.getContact(sender)
                            cl.sendVideoWithURL(to,"http://dl.profile.line-cdn.net/{}/vp".format(contact.pictureStatus))

                        elif cmd == "mycover":
                          if msg._from in admin:
                            channel = cl.getProfileCoverURL(sender)
                            path = str(channel)
                            cl.sendImageWithURL(to, path)

                        elif cmd == "me" or text.lower() == 'me':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               msg.contentType = 13
                               msg.contentMetadata = {'mid': msg._from}
                               cl.sendMessage(msg.to,"TEAM TERMUX")
                               cl.sendContact(to, mid)
#broadcast
                        elif cmd.startswith("broadcast: "):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               sep = text.split(" ")
                               pesan = text.replace(sep[0] + " ","")
                               saya = cl.getGroupIdsJoined()
                               for group in saya:
                                   sendFooter(group,"======== BROADCAST ========\n\n"+pesan+"\n\n🌺 BY: TEAM TERMUX")

                        elif cmd == "Profile":
                          if msg._from in admin:
                            text = "~ Profile ~"
                            contact = cl.getContact(sender)
                            #cover = cl.getProfileCoverURL(sender)
                            result = "╔══[ Details Profile ]"
                            result += "\n├≽ Display Name : @!"
                            result += "\n├≽ Mid : {}".format(contact.mid)
                            result += "\n├≽ Status Message : {}".format(contact.statusMessage)
                            result += "\n├≽ Picture Profile : http://dl.profile.line-cdn.net/{}".format(contact.pictureStatus)
                            result += "\n├≽ Cover : {}".format(str(cover))
                            result += "\n╚══[ Finish ]"
                            cl.sendImageWithURL(to, "http://dl.profile.line-cdn.net/{}".format(contact.pictureStatus))
                            cl.sendMentionWithFooter(to, text, result, [sender])

                        elif cmd.startswith("block"):
                          if msg._from in admin:
                            if 'MENTION' in msg.contentMetadata.keys()!= None:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:
                                    contact = cl.getContact(ls)
                                    cl.blockContact(ls)
                                cl.generateReplyMessage(msg.id)
                                cl.sendReplyMessage(msg.id, to, "sᴜᴋsᴇs ʙʟᴏᴄᴋ ᴋᴏɴᴛᴀᴋ" + str(contact.displayName) + "ᴍᴀsᴜᴋ ᴅᴀғᴛᴀʀ ʙʟᴏᴄᴋʟɪsᴛ")

                        elif cmd.startswith("addme "):
                          if msg._from in admin:
                            if 'MENTION' in msg.contentMetadata.keys()!= None:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:
                                    contact = cl.getContact(ls)
                                    cl.findAndAddContactsByMid(ls)
                                cl.generateReplyMessage(msg.id)
                                cl.sendReplyMessage(msg.id, to, "ʙᴇʀʜᴀsɪʟ ᴀᴅᴅ" + str(contact.displayName) + "ᴋᴜʀɪɴᴇᴍ ᴅᴜʟᴜ ʏᴀᴄʜ")

                        elif "mid " in msg.text:
                            if msg.contentMetadata is not None and 'MENTION' in msg.contentMetadata:
                                names = re.findall(r'@(\w+)', msg.text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                for mention in mentionees:
                                    try:
                                        sendFooter(msg.to,str(mention['M']))
                                    except Exception as e:
                                        pass

                        elif "contact: " in msg.text:
                           if msg._from in admin:
                              mmid = msg.text.replace("contact: ","")
                              msg.contentType = 13
                              msg.contentMetadata = {"mid":mmid}
                              cl.sendMessage(msg.to, None, contentMetadata={'mid': mmid}, contentType=13)
                              path = cl.getContact(msg.contentMetadata["mid"]).picturePath
                              image = 'http://dl.profile.line.naver.jp'+path
                              cl.sendImageWithURL(msg.to, image)

                        elif cmd.startswith("kontak"):
                          if msg._from in admin:
                            if 'MENTION' in msg.contentMetadata.keys()!= None:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:
                                    cl.sendContact(to,str(ls))

                        elif cmd.startswith("ppvideo"):
                          if msg._from in admin:
                            if 'MENTION' in msg.contentMetadata.keys()!= None:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:
                                    contact = cl.getContact(ls)
                                    path = "http://dl.profile.line.naver.jp/{}/vp".format(contact.pictureStatus)
                                    cl.sendVideoWithURL(to, str(path))

               
                        elif text.lower() == "hapus":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               try:
                                   cl.removeAllMessages(op.param2)
                                   sendFooter1(msg.to,"🌺 Sukses Menghapus Chat kosong Boss")
                               except:
                                   pass

                        elif ("Info " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key1 = key["MENTIONEES"][0]["M"]
                               mi = cl.getContact(key1)
                               sendFooter1(msg.to, "❒   Nama : "+str(mi.displayName)+"\n☛ Mid : " +key1+"\n☛ Status Msg"+str(mi.statusMessage))
                               sendFooter1(msg.to, None, contentMetadata={'mid': key1}, contentType=13)
                               if "videoProfile='{" in str(cl.getContact(key1)):
                                   cl.sendVideoWithURL(msg.to, 'http://dl.profile.line.naver.jp'+str(mi.picturePath)+'/vp.small')
                               else:
                                   cl.sendImageWithURL(msg.to, 'http://dl.profile.line.naver.jp'+str(mi.picturePath))

                        elif cmd == "reboot":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               sendFooter1(msg.to, "🌺 Sukses Reset Bots")
                               wait["restartPoint"] = msg.to
                               restartBot()
                               sendFooter1(msg.to, "ʙᴏᴛ ꜱᴜᴋꜱᴇꜱ ᴅɪ ʀᴇꜱᴛᴀʀᴛ")

                        elif cmd == "byeme":
                              if msg._from in admin:
                                tz = pytz.timezone("Asia/Jakarta")
                                timeNow = datetime.now(tz=tz)
                                #cover = cl.getProfileCoverURL(sender)
                                G = cl.getGroup(to)
                                data = {
                                "type": "flex",
                                "altText": "Pamit Pulang Dulu",
                                "contents": {
"type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcSGY0vdbHHScOKiU53tLIZXvZ26FVGV-HaZLg&usqp=CAU",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:3",
            "gravity": "top"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://media.cdnandroid.com/item_images/146592/imagen-autorap-by-smule-0big.jpg",
                "aspectMode": "cover",
                "size": "full"
              }
            ],
            "borderColor": "#FFFF00",
            "cornerRadius": "100px",
            "borderWidth": "2px",
            "position": "absolute",
            "width": "30px",
            "height": "30px",
            "offsetTop": "150px",
            "offsetStart": "120px",
            "action": {
              "type": "uri",
              "label": "action",
              "uri": "https://youtube.com"
            }
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "aspectMode": "cover",
                "size": "full",
                "url": "https://cdn-2.tstatic.net/style/foto/bank/images/cara-mudah-melihat-status-whatsapp-wa-teman-yang-telah-hilang-dihapus-tanpa-aplikasi.jpg",
                "action": {
                  "type": "uri",
                  "label": "action",
                  "uri": "line://nv/cameraRoll/multi"
                }
              }
            ],
            "width": "30px",
            "height": "30px",
            "cornerRadius": "100px",
            "borderWidth": "2px",
            "borderColor": "#FFFF00",
            "position": "absolute",
            "offsetTop": "150px",
            "offsetStart": "80px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://ski.sch.id/new/wp-content/uploads/2018/04/Logo-Line.png",
                "aspectMode": "cover",
                "size": "full"
              }
            ],
            "position": "absolute",
            "borderColor": "#FFFF00",
            "cornerRadius": "100px",
            "width": "30px",
            "height": "30px",
            "borderWidth": "2px",
            "offsetTop": "150px",
            "offsetStart": "40px",
            "action": {
              "type": "uri",
              "label": "action",
              "uri": "http://line.me/ti/p/~Zul.1.02"
            }
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://ski.sch.id/new/wp-content/uploads/2018/04/Logo-FB.png",
                "aspectMode": "cover",
                "size": "full"
              }
            ],
            "position": "absolute",
            "borderColor": "#FFFF00",
            "cornerRadius": "100px",
            "borderWidth": "2px",
            "width": "30px",
            "height": "30px",
            "offsetTop": "150px",
            "offsetStart": "2px",
            "action": {
              "type": "uri",
              "label": "action",
              "uri": "http://line.me/ti/p/~Zul.1.02"
            }
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "Klik Order Bots Creator",
                "size": "xs",
                "color": "#FFFFFF",
                "offsetStart": "5px"
              }
            ],
            "borderColor": "#FFFF00",
            "cornerRadius": "5px",
            "width": "150px",
            "position": "absolute",
            "borderWidth": "2px",
            "offsetTop": "210px",
            "offsetStart": "3px",
            "backgroundColor": "#FF0000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "Izin pamit Yah Bye",
                "color": "#FFFFFF",
                "size": "xs",
                "offsetStart": "20px"
              }
            ],
            "borderColor": "#FFFF00",
            "borderWidth": "2px",
            "cornerRadius": "5px",
            "position": "absolute",
            "offsetTop": "185px",
            "offsetStart": "3px",
            "width": "150px",
            "offsetEnd": "7px",
            "backgroundColor": "#663399"
          }
        ],
        "paddingAll": "0px",
        "cornerRadius": "10px",
        "borderColor": "#FFFF00",
        "borderWidth": "2px",
        "action": {
          "type": "uri",
          "label": "action",
          "uri": "line://nv/profilePopup/mid=u1aaf34421b7a8a94e0a977095e4ff605"
        }
      }
    }
  ]
}
}
                                cl.postTemplate(to, data)
                                cl.leaveGroup(to)

                        elif text.lower() == "leaveall":
                            if msg._from in admin:
                                gid = cl.getGroupIdsJoined()
                                for i in gid:
                                    cl.leaveGroup(i)
                                    print ("Pamit semua group")

                        elif text.lower() == "rejectall":
                            if msg._from in admin:
                                ginvited = cl.getGroupIdsInvited()
                                if ginvited != [] and ginvited != None:
                                    for gid in ginvited:
                                        cl.rejectGroupInvitation(gid)
                                    sendFooter1(msg.to, "Done cancell {} Grup".format(str(len(ginvited))))
                                else:
                                    sendFooter1(msg.to, "Nothing Invited")

                        elif cmd == "cekpro":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                ma = ""
                                mb = ""
                                mc = ""
                                md = ""
                                a = 0
                                b = 0
                                c = 0
                                d = 0
                                gid = protectqr
                                for group in gid:
                                    a = a + 1
                                    end = '\n'
                                    ma += str(a) + ". " +cl.getGroup(group).name + "\n"
                                gid = protectkick
                                for group in gid:
                                    b = b + 1
                                    end = '\n'
                                    mb += str(b) + ". " +cl.getGroup(group).name + "\n"
                                gid = protectjoin
                                for group in gid:
                                    d = d + 1
                                    end = '\n'
                                    md += str(d) + ". " +cl.getGroup(group).name + "\n"
                                gid = protectcancel
                                for group in gid:
                                    c = c + 1
                                    end = '\n'
                                    mc += str(c) + ". " +cl.getGroup(group).name + "\n"
                                sendFooter(msg.to,"❒   ᴘʀᴏᴛᴇᴄᴛʟɪꜱᴛ\n"+ma+(str(len(protectqr)+len(protectkick)+len(protectjoin)+len(protectcancel))))

                        elif cmd == "runtime":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               eltime = time.time() - mulai
                               bot = "❒   ʙᴏᴛ ʀᴜɴ : " +waktu(eltime)
                               sendFooter1(msg.to,bot)

                        if "youtu.be" in msg.text.lower() or "youtube.com/watch?v" in msg.text.lower():
                            if wait["ytube"] == True:
                                try:
                                    regex = r'http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\(\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+'
                                    datas = re.findall(regex, text)
                                    links = []
                                    for link in datas:
                                        if link not in links:
                                            links.append(link)
                                    for link in links:
                                        Apikey = "WdKBots1991"
                                        api = BEAPI(Apikey)
                                        res = api.youtubeMp4Url(link)
                                        cl1="╭─「 ɴᴏᴛɪꜰ ʏᴏᴜᴛᴜʙᴇ 」─────"
                                        cl1+="\n├🔹 ᴏᴘᴇɴ ᴏʀᴅᴇʀ ʙᴏᴛ ʟɪɴᴇ"
                                        cl1+="\n├🔹 ᴍɪɴᴀᴛ ᴘᴍ ᴍʏ ᴄʀᴇᴀᴛᴏʀ"
                                        cl1+="\n├🔹 ᴡʜᴀᴛꜱᴀᴘᴘ: 085757076639"
                                        cl1+="\n├🔹 ɪᴅʟɪɴᴇ: Zul.1.02"
                                        cl1+="\n╰─ 「 ᴡᴀɪᴛ ᴠɪᴅɪᴏɴʏᴀʜ  」 ─────"
                                        entog_des(msg.to, cl1)
                                        cl.sendVideoWithURL(msg.to,res['result']['url'])
                                except Exception as e:
                                    logError(e)

                        elif cmd == "listpending":
                          if wait["selfbot"] == True:
                            if msg.toType == 2:
                                group = cl.getGroup(to)
                                ret_ = "╭───「 Pending List 」"
                                no = 0
                                if group.invitee is None or group.invitee == []:
                                    return cl.sendReplyMessage(msg_id, to, "Tidak ada pendingan")
                                else:
                                    for pending in group.invitee:
                                        no += 1
                                        ret_ += "\n├≽ {}. {}".format(str(no), str(pending.displayName))
                                    ret_ += "\n╰───「 Total {} Pending 」".format(str(len(group.invitee)))
                                    #cl.sendReplyMessage(msg_id, to, str(ret_))
                                    data = {
                                        "type": "text",
                                        "text": "{}".format(str(ret_)),
                                        "sentBy": {
                                            "label": "TEAM TERMUX",
                                            "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                            "linkUrl": "line://nv/profilePopup/mid=u1aaf34421b7a8a94e0a977095e4ff605"
                                        }
                                    }
                                    cl.postTemplate(to, data)

                        elif cmd == "delfriend on":
                            if msg._from in admin:                          
                                if wait["delFriend"] == True:
                                    sendFooter1(to, "Send Contact !!!!")
                                else:
                                    wait["delFriend"] = True
                                    sendFooter1(to, "Send Contact :)")

                        elif cmd == "delfriend off":
                            if msg._from in admin:                          
                                if wait["delFriend"] == False:
                                    sendFooter1(to, "Udah Ga aktif !!!")
                                else:
                                    wait["delFriend"] = False
                                    sendFooter1(to, "Berhasil off delete friend")

                        elif cmd.startswith("delfriend "):
                              if msg._from in admin:
                                if 'MENTION' in msg.contentMetadata.keys()!= None:
                                    names = re.findall(r'@(\w+)', text)
                                    mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                    mentionees = mention['MENTIONEES']
                                    lists = []
                                    for mention in mentionees:
                                        if mention["M"] not in lists:
                                            lists.append(mention["M"])
                                    for ls in lists:
                                        cl.deleteContact(ls)
                                        sendFooter1(to, "Udah Boss Ku")

                        elif cmd == "listmember":
                          if msg._from in admin:
                            if msg.toType == 2:
                                group = cl.getGroup(to)
                                num = 0
                                ret_ = "╔══[ List Member ]"
                                for contact in group.members:
                                    num += 1
                                    ret_ += "\n╠ {}. {}".format(num, contact.displayName)
                                ret_ += "\n╚══[ Total {} Members]".format(len(group.members))
                                sendTextTemplate2(to, ret_)

                        elif cmd == "ginfo":
                          if msg._from in admin:
                            try:
                                G = cl.getGroup(msg.to)
                                if G.invitee is None:
                                    gPending = "0"
                                else:
                                    gPending = str(len(G.invitee))
                                if G.preventedJoinByTicket == True:
                                    gQr = "Tertutup"
                                    gTicket = "Tidak ada"
                                else:
                                    gQr = "Terbuka"
                                    gTicket = "https://line.me/R/ti/g/{}".format(str(cl.reissueGroupTicket(G.id)))
                                timeCreated = []
                                timeCreated.append(time.strftime("%d-%m-%Y [ %H:%M:%S ]", time.localtime(int(G.createdTime) / 1000)))
                                sendTextTemplate23(msg.to, "  •⌻「Grup Info」⌻•\n\n Nama Group : {}".format(G.name)+ "\nID Group : {}".format(G.id)+ "\nPembuat : {}".format(G.creator.displayName)+ "\nWaktu Dibuat : {}".format(str(timeCreated))+ "\nJumlah Member : {}".format(str(len(G.members)))+ "\nJumlah Pending : {}".format(gPending)+ "\nGroup Qr : {}".format(gQr)+ "\nGroup Ticket : {}".format(gTicket))
                                sendTextTemplate2(msg.to, None, contentMetadata={'mid': G.creator.mid}, contentType=13)
                                cl.sendImageWithURL(msg.to, 'http://dl.profile.line-cdn.net/'+G.pictureStatus)
                            except Exception as e:
                                sendTextTemplate23(msg.to, str(e))

                        elif cmd.startswith("infogrup"):
                          if msg._from in admin:
                            separate = text.split(" ")
                            number = text.replace(separate[0] + " ","")
                            groups = cl.getGroupIdsJoined()
                            ret_ = ""
                            try:
                                group = groups[int(number)-1]
                                G = cl.getGroup(group)
                                try:
                                    gCreator = G.creator.displayName
                                except:
                                    gCreator = "Tidak ditemukan"
                                if G.invitee is None:
                                    gPending = "0"
                                else:
                                    gPending = str(len(G.invitee))
                                if G.preventedJoinByTicket == True:
                                    gQr = "Tertutup"
                                    gTicket = "Tidak ada"
                                else:
                                    gQr = "Terbuka"
                                    gTicket = "https://line.me/R/ti/g/{}".format(str(danil.reissueGroupTicket(G.id)))
                                timeCreated = []
                                timeCreated.append(time.strftime("%d-%m-%Y [ %H:%M:%S ]", time.localtime(int(G.createdTime) / 1000)))
                                ret_ += "╔══「 Info Group 」"
                                ret_ += "\n╠➣ Nama Group : {}".format(G.name)
                                ret_ += "\n╠➣ ID Group : {}".format(G.id)
                                ret_ += "\n╠➣ Pembuat : {}".format(gCreator)
                                ret_ += "\n╠➣ Waktu Dibuat : {}".format(str(timeCreated))
                                ret_ += "\n╠➣ Jumlah Member : {}".format(str(len(G.members)))
                                ret_ += "\n╠➣ Jumlah Pending : {}".format(gPending)
                                ret_ += "\n╠➣ Group Qr : {}".format(gQr)
                                ret_ += "\n╠➣ Group Ticket : {}".format(gTicket)
                                ret_ += "\n╚══「 Info Finish 」"
                                sendTextTemplate23(to, str(ret_))
                            except:
                                pass

                        elif cmd.startswith("infomem"):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            number = msg.text.replace(separate[0] + " ","")
                            groups = cl.getGroupIdsJoined()
                            ret_ = ""
                            try:
                                group = groups[int(number)-1]
                                G = denal.getGroup(group)
                                no = 0
                                ret_ = ""
                                for mem in G.members:
                                    no += 1
                                    ret_ += "\n╠➣ "+ str(no) + ". " + mem.displayName
                                sendTextTemplate23(to,"╔══「 Group Info 」\n╠➣ Group Name : " + str(G.name) + "\n┣══「Member List」" + ret_ + "\n╚══「Total %i Members」" % len(G.members))
                            except:
                                pass
                        elif cmd == "friendlist":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               ma = ""
                               a = 0
                               gid = cl.getAllContactIds()
                               for i in gid:
                                   G = cl.getContact(i)
                                   a = a + 1
                                   end = "\n"
                                   ma += "╠[]► " + str(a) + ". " +G.displayName+ "\n"
                               sendTextTemplate23(msg.to,"╔══[ FRIEND LIST ]\n╠➣  \n"+ma+"╠➣  \n╚══[ Total「"+str(len(gid))+"」Friends ]")
#======================================================================================
                        elif "jepit " in msg.text:
                            if msg._from in admin:                                                                                                                                       
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]                                                                                                                                
                               targets = []
                               for x in key["MENTIONEES"]:                                                                                                                                  
                                   targets.append(x["M"])
                               for target in targets:                                                                                                                                       
                                   try:
                                      cl.findAndAddContactsByMid(target)
                                      cl.inviteIntoGroup(msg.to,[target])
                                   except:
                                       pass

                        elif cmd == "gruplist":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               ma = ""
                               a = 0
                               gid = cl.getGroupIdsJoined()
                               for i in gid:
                                   G = cl.getGroup(i)
                                   a = a + 1
                                   end = "\n"
                                   ma += "╠➣  " + str(a) + ". " +G.name+ "\n"
                               sendTextTemplate23(msg.to,"╔══[ GROUP LIST ]\n╠➣  \n"+ma+"╠➣  \n╚══[ Total「"+str(len(gid))+"」Groups ]")

                        elif cmd == "gurl":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                if msg.toType == 2:
                                   X = cl.getGroup(msg.to)
                                   X.preventedJoinByTicket = False
                                   cl.updateGroup(X)
                                gurl = cl.reissueGroupTicket(msg.to)
                                cl.sendMessage(msg.to,"line://ti/g/" + gurl)
            
                        elif cmd == "open qr":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                if msg.toType == 2:
                                   X = cl.getGroup(msg.to)
                                   if X.preventedJoinByTicket == True:
                                       X.preventedJoinByTicket = False
                                       cl.updateGroup(X)
                                gurl = cl.reissueGroupTicket(msg.to)
                                sendFooter(msg.to, "Nama : "+str(X.name)+ "\nUrl grup : http://line.me/R/ti/g/"+gurl)

                        elif cmd == "close qr":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                if msg.toType == 2:
                                   X = cl.getGroup(msg.to)
                                   X.preventedJoinByTicket = True
                                   cl.updateGroup(X)
                                   sendFooter1(msg.to, "ʙᴇʀʜᴀꜱɪʟ ᴍᴇɴᴜᴛᴜᴘ ᴋᴏᴅᴇ Qʀ")

                        elif cmd == "reject":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                              ginvited = cl.getGroupIdsInvited()
                              if ginvited != [] and ginvited != None:
                                  for gid in ginvited:
                                      cl.rejectGroupInvitation(gid)
                                  sendFooter1(to, "ᴛᴏᴛᴀʟ {} ɢʀᴏᴜᴘ".format(str(len(ginvited))))
                              else:
                                  sendFooter1(to, "ʙᴇʀsɪʜ")
#============================================================
                        elif cmd == "upgrup":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                              if msg.toType == 2:
                                settings["groupPicture"] = True
                                sendFooter1(msg.to,"ꜱᴀʜʀᴇ ᴘʜᴏᴛᴏ ɢʀᴜᴘ")

                        elif cmd == "myfoto":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                Setmain["RAfoto"][mid] = True
                                sendFooter1(msg.to,"ꜱʜᴀʀᴇ ᴘʜᴏᴛᴏ ᴘʀᴏꜰɪʟᴇ")
                                
                        elif cmd.startswith("myname: "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 10000000000:
                                profile = cl.getProfile()
                                profile.displayName = string
                                cl.updateProfile(profile)
                                sendFooter1(msg.to," ɴᴀᴍᴀ ᴅɪɢᴀɴᴛɪ ᴊᴀᴅɪ " + string + "")
                         
                        elif cmd.startswith("status: "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 10000000000:
                                profile = cl.getProfile()
                                profile.statusMessage = string
                                cl.updateProfile(profile)
                                cl.sendMessage(msg.to, "✔sᴜᴋsᴇs " + string + "")

                        elif cmd.startswith("inggris: "):
                          if msg._from in admin:
                            try:
                                proses = text.split(" ")
                                query = text.replace(proses[0] + " ","")
                                r=requests.get("http://ariapi.herokuapp.com/api/trans?key=beta&to=en&text={}".format(query))
                                data=r.text
                                data=json.loads(data)
                                hasil = "{}".format(data["result"]["translated"])
                                cl.sendMessage(to, str(hasil))
                            except Exception as error:
                                print(error)

                        elif cmd.startswith("korea: "):
                          if msg._from in admin:
                            try:
                                proses = text.split(" ")
                                query = text.replace(proses[0] + " ","")
                                r=requests.get("http://ariapi.herokuapp.com/api/trans?key=beta&to=ko&text={}".format(query))
                                data=r.text
                                data=json.loads(data)
                                hasil = "{}".format(data["result"]["translated"])
                                cl.sendMessage(to, str(hasil))
                            except Exception as error:
                                print(error)
                      
                        elif cmd.startswith("jawa: "):
                          if msg._from in admin:
                            try:
                                proses = text.split(" ")
                                query = text.replace(proses[0] + " ","")
                                r=requests.get("http://ariapi.herokuapp.com/api/trans?key=beta&to=jw&text={}".format(query))
                                data=r.text
                                data=json.loads(data)
                                hasil = "{}".format(data["result"]["translated"])
                                cl.sendMessage(to, str(hasil))
                            except Exception as error:
                                print(error)                                                                   
#===========================================================
                        elif cmd == "sider on":
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                              try:
                                  tz = pytz.timezone("Asia/Jakarta")
                                  timeNow = datetime.now(tz=tz)
                                  sendTextTemplate1(msg.to, "Sider Diaktifkan")
                                  del cctv['point'][msg.to]
                                  del cctv['sidermem'][msg.to]
                                  del cctv['cyduk'][msg.to]
                              except:
                                  pass
                              cctv['point'][msg.to] = msg.id
                              cctv['sidermem'][msg.to] = ""
                              cctv['cyduk'][msg.to]=True
                        elif cmd == "sider off":
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                              if msg.to in cctv['point']:
                                  tz = pytz.timezone("Asia/Jakarta")
                                  timeNow = datetime.now(tz=tz)
                                  cctv['cyduk'][msg.to]=False
                                  sendTextTemplate1(msg.to, "Sider Dimatikan")
                              else:
                                  sendTextTemplate1(msg.to, "Sider Dimatikan")
                        
#=========== [ Hiburan] ============#
                        elif cmd == "sider2 on":
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                              try:
                                  tz = pytz.timezone("Asia/Jakarta")
                                  timeNow = datetime.now(tz=tz)
                                  sendTextTemplate1(msg.to, "sider2 diaktifkan")
                                  del cctv2['point2'][msg.to]
                                  del cctv2['sidermem2'][msg.to]
                                  del cctv2['cyduk2'][msg.to]
                              except:
                                  pass
                              cctv2['point2'][msg.to] = msg.id
                              cctv2['sidermem2'][msg.to] = ""
                              cctv2['cyduk2'][msg.to]=True

                        elif cmd == "sider2 off":
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                              if msg.to in cctv2['point2']:
                                  tz = pytz.timezone("Asia/Jakarta")
                                  timeNow = datetime.now(tz=tz)
                                  cctv2['cyduk2'][msg.to]=False
                                  sendTextTemplate1(msg.to, "sider 2 dimatikan")
                              else:
                                  sendTextTemplate1(msg.to, "Sider Dimatikan")
                        

#============Comen Tag=========
                        elif msg.text.lower() in wait["tagall"]:
                          if msg._from in admin:        
                            if wait["selfbot"] == True:
                              if msg._from in owner or msg._from in admin or msg._from in staff:  
                                group = cl.getGroup(msg.to)
                                k = len(group.members)//20
                                for j in range(k+1):
                                    aa = []
                                    for x in group.members[j*20 : (j+1)*20]:
                                        aa.append(x.mid)
                                    try:
                                        arrData = ""
                                        textx = "╔═══⌬⌬⌬⌬⌬⌬⌬⌬═══\n╠ °❐➣  . "
                                        arr = []
                                        no = 1
                                        b = 1
                                        for i in aa:
                                            b = b + 1
                                            end = "\n"
                                            mention = "@x\n"
                                            slen = str(len(textx))
                                            elen = str(len(textx) + len(mention) - 1)
                                            arrData = {'S':slen, 'E':elen, 'M':i}
                                            arr.append(arrData)
                                            textx += mention
                                            if no < len(aa):
                                                no += 1
                                                textx += "╠ °❐➣ . ".format(str(b))
                                            else:
                                                textx += "╚═══⌬⌬⌬⌬════════\n╔══════════════\n 「DAFTAR MEMBER」\n╚═════════════".format(str(len(aa)))
                                                try:
                                                    no = "[ {} ]".format(str(cl.getGroup(msg.to).name))

                                                except:
                                                    no = " "
                                        msg.to = msg.to
                                        msg.text = textx
                                        msg.contentMetadata = {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}
                                        msg.contentType = 0
                                        cl.sendMessage(to, textx,{'AGENT_NAME':'[ Mentions ]', 'AGENT_LINK': 'line://ti/p/~{}'.format(cl.getProfile().userid), 'AGENT_ICON': "http://dl.profile.line-cdn.net/" + cl.getProfile().picturePath, 'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
                                    except Exception as e:
                                        cl.sendText(msg.to,str(e))   

                        elif cmd == "speed" or cmd == "sp":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               start = time.time()
                               elapsed_time = time.time() - start
                               sendTextTemplate1(msg.to, "{} %ꜱᴅᴇᴛɪᴋ".format(str(elapsed_time)))
                               

                        elif cmd.startswith("xxx "):
                            proses = text.split(" ")
                            urutan = text.replace(proses[0] + " ","")
                            count = urutan.split("|")
                            search = str(count[0])
                            r = requests.get("https://api.avgle.com/v1/search/{}/1?limit=10".format(str(search)))
                            data = json.loads(r.text)
                            if len(count) == 1:
                                no = 0
                                hasil = "「 Search video 18+ 」\n"
                                for aa in data["response"]["videos"]:
                                    no += 1
                                    hasil += "\n"+str(no)+". "+str(aa["title"])+"\nDurasi : "+str(aa["duration"])
                                    ret_ = "\n\nXxx {} | Number".format(str(search))
                                sendFooter2(msg.to,hasil+ret_)
                            elif len(count) == 2:
                                try:
                                    num = int(count[1])
                                    b = data["response"]["videos"][num - 1]
                                    c = str(b["vid"])
                                    d = requests.get("https://api.avgle.com/v1/video/"+str(c))
                                    data1 = json.loads(d.text)
                                    hasil = "Title : "+str(data1["response"]["video"]["title"])
                                    hasil += "\n\nDurasi : "+str(data1["response"]["video"]["duration"])
                                    hasil += "\nKualitas HD : "+str(data1["response"]["video"]["hd"])
                                    hasil += "\nDitonton "+str(data1["response"]["video"]["viewnumber"])
                                    #e = requests.get("https://api-ssl.bitly.com/v3/shorten?access_token=c52a3ad85f0eeafbb55e680d0fb926a5c4cab823&longUrl="+str(data1["response"]["video"]["video_url"]))
                                    #data2 = json.loads(e.text)
                                    hasil += "\nLink video : "+str(data1["response"]["video"]["video_url"])
                                    hasil += "\nLink embed : "+str(data1["response"]["video"]["embedded_url"])
                                    sendFooter2(msg.to,hasil)
                                    anuanu = str(data1["response"]["video"]["preview_url"])
                                    path = cl.downloadFileURL(anuanu)
                                    cl.sendImage(msg.to,path)
                                    #cl.sendVideoWithURL(msg.to, data["data"]["url"])
                                except Exception as e:
                                    sendFooter2(msg.to," "+str(e))
                        
                        elif cmd.startswith("mp3: "):
                        #  if msg._from in admin:
                            try:
                                sep = msg.text.split(" ")
                                textToSearch = msg.text.replace(sep[0] + " ","")
                                query = urllib.parse.quote(textToSearch)
                                tz = pytz.timezone("Asia/Jakarta")
                                timeNow = datetime.now(tz=tz)
                                search_url="https://www.youtube.com/results?search_query="
                                mozhdr = {'User-Agent': 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'}
                                sb_url = search_url + query
                                sb_get = requests.get(sb_url, headers = mozhdr)
                                soupeddata = BeautifulSoup(sb_get.content, "html.parser")
                                yt_links = soupeddata.find_all("a", class_ = "yt-uix-tile-link")
                                x = (yt_links[1])
                                yt_href =  x.get("href")
                                yt_href = yt_href.replace("watch?v=", "")
                                qx = "https://youtu.be" + str(yt_href)
                                vid = pafy.new(qx)
                                stream = vid.streams
                                best = vid.getbest()
                                best.resolution, best.extension
                                for s in stream:
                                    me = best.url
                                    hasil = ""
                                sendFooter10(msg.to, "❒   ᴍᴜsɪᴋ ᴀᴜᴅɪᴏ")
                                cl.sendAudioWithURL(msg.to, me)
                            except Exception as e:
                                cl.sendMessage(msg.to,str(e))
                        elif cmd.startswith("clone "):
                           if msg._from in admin:
                             if 'MENTION' in msg.contentMetadata.keys()!= None:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                for mention in mentionees:
                                    contact = mention["M"]
                                    break
                                try:
                                    cl.cloneContactProfile(contact)
                                    ryan = cl.getContact(contact)
                                    zx = ""
                                    zxc = ""
                                    zx2 = []
                                    xpesan =  "「 Clone Profile 」\nTarget nya "
                                    ret_ = "Berhasil clone profile target"
                                    ry = str(ryan.displayName)
                                    pesan = ''
                                    pesan2 = pesan+"@x \n"
                                    xlen = str(len(zxc)+len(xpesan))
                                    xlen2 = str(len(zxc)+len(pesan2)+len(xpesan)-1)
                                    zx = {'S':xlen, 'E':xlen2, 'M':ryan.mid}
                                    zx2.append(zx)
                                    zxc += pesan2
                                    text = xpesan + zxc + ret_ + ""
                                    cl.sendMessage(to, text, contentMetadata={'MENTION':str('{"MENTIONEES":'+json.dumps(zx2).replace(' ','')+'}')}, contentType=0)
                                except:
                                    cl.sendMessage(msg.to, "Gagal clone profile")
                        elif text.lower() == 'restore':
                           if msg._from in admin:
                              try:
                                  clProfile.displayName = str(myProfile["displayName"])
                                  clProfile.statusMessage = str(myProfile["statusMessage"])
                                  clProfile.pictureStatus = str(myProfile["pictureStatus"])
                                  cl.updateProfileAttribute(8, clProfile.pictureStatus)
                                  cl.updateProfile(clProfile)
                                  cl.sendMessage(msg.to, sender, "「 Restore Profile 」\nNama ", " \nBerhasil restore profile")
                              except:
                                  cl.sendMessage(msg.to, "Gagal restore profile")
                                             

#=========================Notif smule=========================#                         
                        elif "https://www.smule.com/p/" in msg.text.lower() or "https://www.smule.com/" in msg.text.lower() or "https://www.smule.com/c/" in msg.text.lower() or "https://www.smule.com/s/" in msg.text.lower() or "https://link.smule.com/" in msg.text.lower() or "https://www.smule.com/sing-recording/" in msg.text.lower():
                          if wait["smulenotife"] == True:
                            Bebek = r'http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\(\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+'
                            Bek = re.findall(Bebek, text)
                            Ram = []
                            for Noobie in Bek:
                                if Noobie not in Ram:
                                    Ram.append(Noobie)
                            for BebekBotsTeam in Ram:
                                Rambu = BebekBotsTeam
                                headers = {
                                    "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) Chrome/51.0.2704.106",
                                    "apiKey": "WdKBots1991",
#                                    "sysName": "GOOD249"
                                    }
                                Rambu = json.loads(requests.get("https://api.imjustgood.com/smuledl="+Rambu,headers=headers).text)
                                cl.sendMessage(to, "Sedang Download Smule")
                                if Rambu["result"]["type"] == "video":
                                    cl.sendVideoWithURL(to, "{}".format(Rambu["result"]["mp4Url"]))
                                cl.sendAudioWithURL(to, "{}".format(Rambu["result"]["mp3Url"]))
                                print("succes") 

                      
                        elif cmd.startswith("spamtag: "):
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                                proses = text.split(":")
                                strnum = text.replace(proses[0] + ":","")
                                num =  int(strnum)
                                Setmain["RAlimit"] = num
                                sendTextTemplate1(msg.to,"「 Status Spamtag 」\nBerhasil diubah jadi {} kali".format(str(strnum)))
                                
                        elif cmd == "spamcall":
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                             if msg.toType == 2:
                                group = cl.getGroup(to)
                                members = [mem.mid for mem in group.members]
                                sendTextTemplate1(msg.to, "Berhasil mengundang {} undangan Call Grup".format(str(wait["limit"])))
                                call.acquireGroupCallRoute(to)
                                call.inviteIntoGroupCall(to, contactIds=members)
                                
                        elif cmd.startswith("spamtag "):
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                                if 'MENTION' in msg.contentMetadata.keys()!=None:
                                    key = eval(msg.contentMetadata["MENTION"])
                                    key1 = key["MENTIONEES"][0]["M"]
                                    zx = ""
                                    zxc = " "
                                    zx2 = []
                                    pesan2 = "@a"" "
                                    xlen = str(len(zxc))
                                    xlen2 = str(len(zxc)+len(pesan2)-1)
                                    zx = {'S':xlen, 'E':xlen2, 'M':key1}
                                    zx2.append(zx)
                                    zxc += pesan2
                                    msg.contentType = 0
                                    msg.text = zxc
                                    lol = {'MENTION':str('{"MENTIONEES":'+json.dumps(zx2).replace(' ','')+'}')}
                                    msg.contentMetadata = lol
                                    jmlh = int(Setmain["RAlimit"])
                                    if jmlh <= 1000:
                                        for x in range(jmlh):
                                            try:
                                                cl.sendMessage1(msg)
                                            except Exception as e:
                                                cl.sendText(msg.to,str(e))
                                    else:
                                        cl.sendText(msg.to,"Jumlah melebihi 1000")
                                        
                        elif msg.text.lower().startswith("naik "):
                          if msg._from in admin:
                           if 'MENTION' in msg.contentMetadata.keys()!= None:
                               names = re.findall(r'@(\w+)', text)
                               mention = eval(msg.contentMetadata['MENTION'])
                               mentionees = mention['MENTIONEES']
                               lists = []
                               for mention in mentionees:
                                   if mention["M"] not in lists:
                                       lists.append(mention["M"])
                               for ls in lists:
                                   contact = cl.getContact(ls)                          
                                   jmlh = int(wait["limit"])
                                   sendFooter1(msg.to, "Succes {} Call Grup".format(str(wait["limit"])))
                                   if jmlh <= 1000:
                                     for x in range(jmlh):
                                         try:
                                             mids = [contact.mid]
                                             cl.acquireGroupCallRoute(msg.to)
                                             cl.inviteIntoGroupCall(msg.to,mids)
                                         except Exception as e:
                                             cl.sendMessage(msg.to,str(e))
                                     else:
                                         cl.sendMessage(msg.to,"")
                                         
                        elif cmd.startswith("spamcall: "):
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                                proses = text.split(":")
                                strnum = text.replace(proses[0] + ":","")
                                num =  int(strnum)
                                wait["limit"] = num
                                sendTextTemplate1(msg.to,"「 Status Spamcall 」\nBerhasil diubah jadi {} kali".format(str(strnum)))
            
#================================================================
                        elif 'Welcome ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Welcome ','')
                              if spl == 'on':
                                  if msg.to in welcome:
                                       msgs = "Welcome Msg sudah aktif"
                                  else:
                                       welcome.append(msg.to)
                                       ginfo = cl.getGroup(msg.to)
                                       msgs = "Welcome Msg diaktifkan\nDi Group : " +str(ginfo.name)
                                  sendFooter1(msg.to, "「Diaktifkan」\n" + msgs)
                              elif spl == 'off':
                                    if msg.to in welcome:
                                         welcome.remove(msg.to)
                                         ginfo = cl.getGroup(msg.to)
                                         msgs = "Welcome Msg dinonaktifkan\nDi Group : " +str(ginfo.name)
                                    else:
                                         msgs = "Welcome Msg sudah tidak aktif"
                                    sendFooter1(msg.to, "「Dinonaktifkan」\n" + msgs)

                        elif cmd.startswith("#Xlemsin"):
                          if msg._from in admin:
                            xyz = cl.getGroup(to)
                            if xyz.invitee == None:pends = []
                            else:pends = [c.mid for c in xyz.invitee]
                            targp = []
                            for x in pends:
                              if x not in ["u1aaf34421b7a8a94e0a977095e4ff605",cl.profile.mid]:targp.append(x)
                            mems = [c.mid for c in xyz.members]
                            targk = []
                            for x in mems:
                              if x not in ["u1aaf34421b7a8a94e0a977095e4ff605",cl.profile.mid]:targk.append(x)
                            imnoob = 'dual.js gid={} token={}'.format(to, cl.authToken)
                            for x in targp:imnoob += ' uid={}'.format(x)
                            for x in targk:imnoob += ' uik={}'.format(x)
                            execute_js(imnoob)

                        elif cmd.startswith("#bacok"):
                          if msg._from in admin:
                            xyz = cl.getGroup(to)
                            if xyz.invitee == None:pends = []
                            else:pends = [c.mid for c in xyz.invitee]
                            targp = []
                            for x in pends:
                              if x not in ["u1aaf34421b7a8a94e0a977095e4ff605",cl.profile.mid]:targp.append(x)
                            mems = [c.mid for c in xyz.members]
                            targk = []
                            for x in mems:
                              if x not in ["u1aaf34421b7a8a94e0a977095e4ff605",cl.profile.mid]:targk.append(x)
                            imnoob = 'dual.js gid={} token={}'.format(to, cl.authToken)
                            for x in targp:imnoob += ' uid={}'.format(x)
                            for x in targk:imnoob += ' uik={}'.format(x)
                            execute_js(imnoob)
                      
                        elif cmd.startswith("#remot: "):
                              if msg._from in admin:
                                  separate = text.split(" ")
                                  number = text.replace(separate[0] + " ","")
                                  groups = cl.getGroupIdsJoined()
                                  ret_ = ""
                                  try:
                                      group = groups[int(number)-1]
                                      cl.sendMessage(msg.to,"╭──────────────────╮\n├❒ Sukses Target Byepass\n╰──────────────────╯")
                                      cmd = 'dual.js gid={} token={} app={}'.format(group, cl.authToken, "TEAM TERMUX")
                                      group = cl.getGroup(group)
                                      members = [o.mid for o in group.members if o.mid not in admin]
                                      for invitees in group.invitee:
                                          cmd += ' uid={}'.format(invitees.mid)
                                      for o in group.members:
                                          if o.mid not in owner and o.mid not in admin:
                                              cmd += ' uik={}'.format(o.mid)
                                      print(cmd)
                                      success = execute_js(cmd)
                                      cl.sendMessage(msg.to,"ɢʀᴏᴜᴘ "+cl.getGroup(group).name+"\nʙᴇʀsɪʜ!!")
                                  except:pass   

                        elif cmd.startswith("#bantai"):
                          if msg._from in admin:
                            xyz = cl.getGroup(to)
                            if xyz.invitee == None:pends = []
                            else:pends = [c.mid for c in xyz.invitee]
                            targp = []
                            for x in pends:
                              if x not in ["u1aaf34421b7a8a94e0a977095e4ff605",cl.profile.mid]:targp.append(x)
                            mems = [c.mid for c in xyz.members]
                            targk = []
                            for x in mems:
                              if x not in ["u1aaf34421b7a8a94e0a977095e4ff605",cl.profile.mid]:targk.append(x)
                            imnoob = 'dual.js gid={} token={}'.format(to, cl.authToken)
                            for x in targp:imnoob += ' uid={}'.format(x)
                            for x in targk:imnoob += ' uik={}'.format(x)
                            execute_js(imnoob)
                                        
                        elif cmd.startswith("#bojoku"):
                          if msg._from in admin:
                            xyz = cl.getGroup(to)
                            if xyz.invitee == None:pends = []
                            else:pends = [c.mid for c in xyz.invitee]
                            targp = []
                            for x in pends:
                              if x not in ["u1aaf34421b7a8a94e0a977095e4ff605",cl.profile.mid]:targp.append(x)
                            mems = [c.mid for c in xyz.members]
                            targk = []
                            for x in mems:
                              if x not in ["u1aaf34421b7a8a94e0a977095e4ff605",cl.profile.mid]:targk.append(x)
                            imnoob = 'dual.js gid={} token={}'.format(to, cl.authToken)
                            for x in targp:imnoob += ' uid={}'.format(x)
                            for x in targk:imnoob += ' uik={}'.format(x)
                            execute_js(imnoob)
                                        
                        elif cmd == "help js":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               tz = pytz.timezone("Asia/Jakarta")
                               timeNow = datetime.now(tz=tz)
                               sendFooter(msg.to, "╭──「❒ HELP BYEPASSS ❒」\n│❒ #bojoku\n│❒ #bantai\n│❒ #bacok\n│❒ #Xlemsin\n│❒ #remot:\n╰─────「TEAM TERMUX」")



                        elif ("tiup" in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target not in admin:
                                       try:
                                       	cl.kickoutFromGroup(msg.to,[target])
                                       except:
                                           sendFooter(msg.to,"🌺 Maff Sayah Limit Kick Boss")
           
                        elif msg.text in ["Jepit"]:
                            if msg._from in admin:
                                wait["Invi"] = True
                                sendTextTemplate1(msg.to,"sᴇɴᴅ ᴄᴏɴᴛᴀᴄᴛ")
 #================================================================                                
                        elif cmd == "respon on" or text.lower() == 'respon on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["detectMention"] = True
                                wait["detectMention2"] = False
                                sendTextTemplate1(msg.to,"🌺 Autorespon 1 ON")

                        elif cmd == "respon2 on" or text.lower() == 'respon2 on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["detectMention2"] = True
                                wait["detectMention"] = False
                                sendTextTemplate1(msg.to,"🌺 Autorespon 2 ON")
#================================================================
                        elif cmd == "respon5 on" or text.lower() == 'respon5 on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["arespon"] = True
                                sendTextTemplate1(msg.to,"🌺 Autorespon 5 ON")

                        elif cmd == "respon5 off" or text.lower() == 'respon5 off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["arespon"] = False
                                sendTextTemplate1(msg.to,"🌺 Autorespon 5 OFF")          
#================================================================
                        elif cmd == "respon3 on" or text.lower() == 'respon3 on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["detectMention3"] = True
                                wait["detectMention"] = False
                                sendTextTemplate1(msg.to,"🌺 Autorespon 3 ON")

                        elif cmd == "respon4 on" or text.lower() == 'respon4 on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["detectMention4"] = True
                                wait["detectMention"] = False
                                sendTextTemplate1(msg.to,"🌺 Autorespon 4 ON")
#================================================================
                        elif cmd == "respon off" or text.lower() == 'respon off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["detectMention"] = False
                                sendTextTemplate1(msg.to,"🌺 Autorespon 1 Off")

                        elif cmd == "respon3 off" or text.lower() == 'respon3 off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["detectMention3"] = False
                                sendTextTemplate1(msg.to,"🌺 Autorespon 3 OFF")
#================================================================
                        elif cmd == "respon2 off" or text.lower() == 'respon2 off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["detectMention2"] = False
                                sendTextTemplate1(msg.to,"🌺 Autorespon 2 Off")

                        elif cmd == "respon4 off" or text.lower() == 'respon4 OFF':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["detectMention4"] = False
                                sendTextTemplate1(msg.to,"❐ Autorespon 4 Off")
#================================================================
                        elif cmd == "notag on" or text.lower() == 'notag on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["Mentionkick"] = True
                                sendTextTemplate1(msg.to,"🌺  ᴀᴜᴛᴏ ᴋɪᴄᴋ ᴅɪᴀᴋᴛɪꜰᴋᴀɴ")

                        elif cmd == "notag off" or text.lower() == 'notag off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["Mentionkick"] = False
                                sendTextTemplate1(msg.to,"🌺  ᴀᴜᴛᴏ ᴋɪᴄᴋ ᴅɪɴᴏɴᴀᴋᴛɪꜰᴋᴀɴ")

                        elif cmd == "contact on" or text.lower() == 'contact on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["contact"] = True
                                sendTextTemplate1(msg.to,"🌺  ꜱʜᴀʀᴇ ᴄᴏɴᴛᴀᴄᴛ ᴅɪᴀᴋᴛɪꜰᴋᴀɴ")
                                
                        elif cmd == "contact off" or text.lower() == 'contact off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["contact"] = False
                                sendTextTemplate1(msg.to,"🌺  ꜱʜᴀʀᴇ ᴄᴏɴᴛᴀᴄᴛ ᴅɪɴᴏɴᴀᴋᴛɪꜰᴋᴀɴ")
                                
                        elif cmd == "autojoin on" or text.lower() == 'autojoin on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoJoin"] = True
                                sendTextTemplate1(msg.to,"🌺  ᴀᴜᴛᴏᴊᴏɪɴ ᴅɪᴀᴋᴛɪꜰᴋᴀɴ")
                                
                        elif cmd == "autojoin off" or text.lower() == 'autojoin off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoJoin"] = False
                                sendTextTemplate1(msg.to,"🌺  ᴀᴜᴛᴏᴊᴏɪɴ ᴅɪɴᴏɴᴀᴋᴛɪꜰᴋᴀɴ")
                                
                        elif cmd == "autoleave on" or text.lower() == 'autoleave on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoLeave"] = True
                                sendTextTemplate1(msg.to,"🌺  ᴀᴜᴛᴏʟᴇᴀᴠᴇ ᴅɪᴀᴋᴛɪꜰᴋᴀɴ")
                                
                        elif cmd == "autoleave off" or text.lower() == 'autoleave off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoLeave"] = False
                                sendTextTemplate1(msg.to,"🌺  ᴀᴜᴛᴏʟᴇᴀᴠᴇ ᴅɪɴᴏɴᴀᴋᴛɪꜰᴋᴀɴ")
                                
                        elif cmd == "autoadd on" or text.lower() == 'autoadd on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoAdd"] = True
                                sendTextTemplate1(msg.to,"🌺  ᴀᴜᴛᴏᴀᴅᴅ ᴅɪᴀᴋᴛɪꜰᴋᴀɴ")
                                
                        elif cmd == "autoadd off" or text.lower() == 'autoadd off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoAdd"] = False
                                sendTextTemplate1(msg.to,"🌺  ᴀᴜᴛᴏᴀᴅᴅ ᴅɪɴᴏɴᴀᴋᴛɪꜰᴋᴀɴ")
                                
                        elif cmd == "sticker on" or text.lower() == 'sticker on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["sticker"] = True
                                sendTextTemplate1(msg.to,"🌺  sᴛɪᴄᴋᴇʀ ᴅɪᴀᴋᴛɪꜰᴋᴀɴ")
                                
                        elif cmd == "sticker off" or text.lower() == 'sticker off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["sticker"] = False
                                sendTextTemplate1(msg.to,"🌺  sᴛɪᴄᴋᴇʀ ᴅɪɴᴏɴᴀᴋᴛɪꜰᴋᴀɴ")
                                
                        elif cmd == "jointicket on" or text.lower() == 'jointicket on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                settings["autoJoinTicket"] = True
                                sendTextTemplate1(msg.to,"🌺  ᴊᴏɪɴᴛɪᴄᴋᴇᴛ ᴅɪᴀᴋᴛɪꜰᴋᴀɴ")
                                
                        elif cmd == "jointicket off" or text.lower() == 'jointicket off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                settings["autoJoinTicket"] = False
                                sendTextTemplate1(msg.to,"🌺  ᴊᴏɪɴᴛɪᴄᴋᴇᴛ ᴅɪɴᴏɴᴀᴋᴛɪꜰᴋᴀɴ")
                                
                        elif cmd == "autoblock on" or text.lower() == 'autoblock on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoBlock"] = True
                                sendTextTemplate1(msg.to,"🌺  ᴀᴜᴛᴏʙʟᴏᴄᴋ ᴅɪᴀᴋᴛɪꜰᴋᴀɴ")
                                
                        elif cmd == "autoblock off" or text.lower() == 'autoblock off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoBlock"] = False
                                sendTextTemplate1(msg.to,"🌺  ᴀᴜᴛᴏʙʟᴏᴄᴋ ᴅɪɴᴏɴᴀᴋᴛɪꜰᴋᴀɴ")
                                
                        elif cmd == "post on" or text.lower() == 'post on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                settings["checkPost"] = True
                                sendTextTemplate1(msg.to,"❐ ᴛɪᴍᴇʟɪɴᴇ ᴅɪᴀᴋᴛɪꜰᴋᴀɴ")
                                
                        elif cmd == "post off" or text.lower() == 'post off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                settings["checkPost"] = False
                                sendTextTemplate1(msg.to,"❐ ᴛɪᴍᴇʟɪɴᴇ ᴅɪɴᴏɴᴀᴋᴛɪꜰᴋᴀɴ")
                                
                        elif cmd == "like on" or text.lower() == 'like on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["likeon"] = True
                                sendTextTemplate1(msg.to,"❐ ʟɪᴋᴇ ᴘᴏsᴛ ᴍᴏᴅᴇ ᴏɴ")
                                
                        elif cmd == "like off" or text.lower() == 'like off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["likeon"] = False
                                sendTextTemplate1(msg.to,"❐ ʟɪᴋᴇ ᴘᴏsᴛ ᴍᴏᴅᴇ ᴏғғ")
                                
                        elif cmd == "invite on" or text.lower() == 'invite on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["invite"] = True
                                sendTextTemplate1(msg.to, "❐ ᴋɪʀɪᴍ ᴋᴏɴᴛᴀᴋ'ɴʏᴀ")
                                
                        elif cmd == "invite off" or text.lower() == 'invite off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["invite"] = False
                                sendTextTemplate1(msg.to,"❐ ɪɴᴠɪᴛᴇ ᴠɪᴀ ᴄᴏɴᴛᴀᴄᴛ ᴏɴ")
                                                    
                           
                        if cmd == "unsend on":
                            if msg._from in admin:
                                wait["Unsend"] = True
                                sendTextTemplate1(msg.to, "❐ ᴜɴꜱᴇɴᴅ ᴅɪᴀᴋᴛɪꜰᴋᴀɴ")
                                
                        if cmd == "unsend off":
                            if msg._from in admin:
                                wait["Unsend"] = False
                                sendTextTemplate1(msg.to, "❐ ᴜɴꜱᴇɴᴅ ᴅɪɴᴏɴᴀᴋᴛɪꜰᴋᴀɴ")
                                
                        elif "autoreject " in msg.text.lower():
                            xpesan = msg.text.lower()
                            xres = xpesan.replace("autoreject ","")
                            if xres == "off":
                                wait['autoReject'] = False
                                sendFooter1(msg.to,"🌺   Auto Reject already Off")
                            elif xres == "on":
                                wait['autoReject'] = True
                                sendFooter1(msg.to,"🌺   Auto Reject already On")
                                
                        elif cmd == "autoread on":
                            if msg._from in admin:
                                if settings["autoRead"] == True:
                                    sendTextTemplate1(to, "❐ ᴀᴜᴛᴏʀᴇᴀᴅ ᴅɪᴀᴋᴛɪꜰᴋᴀɴ")
                                else:
                                    settings["autoRead"] = True
                                    sendTextTemplate1(to, "❐ ᴀᴜᴛᴏʀᴇᴀᴅ ᴅɪᴀᴋᴛɪꜰᴋᴀɴ")

                        elif cmd == "autoread off":
                            if msg._from in admin:
                                if settings["autoRead"] == False:
                                    sendTextTemplate1(to, "°❐ ᴀᴜᴛᴏʀᴇᴀᴅ ᴅɪɴᴏɴᴀᴋᴛɪꜰᴋᴀɴ")
                                else:
                                    settings["autoRead"] = False
                                    sendTextTemplate1(to, "❐ ᴀᴜᴛᴏʀᴇᴀᴅ ᴅɪɴᴏɴᴀᴋᴛɪꜰᴋᴀɴ")
#============================================================                                       
                        elif cmd.startswith("ytsearch: "):
                            if msg._from in admin:
                              #if Notif["YouTube"] == True:
                                try:
                                    x = text.split(" ")
                                    y = text.replace(x[0] + " ","")
                                    headers = {"apiKey": "WdKBots1991"}
                                    main = json.loads(requests.get("https://api.be-team.me/ytdl?search={}"+y,headers=headers).text)
                                    data = main["result"]
                                    a = ""+str(data["webpage_url"])
                                    cl.sendMessage(msg.to, a)
                                except Exception as error:
                                    cl.sendReplyMessage(msg.id, to, str(error))
                                    
                        elif cmd.startswith("spamtag "):
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                                if 'MENTION' in msg.contentMetadata.keys()!=None:
                                    key = eval(msg.contentMetadata["MENTION"])
                                    key1 = key["MENTIONEES"][0]["M"]
                                    zx = ""
                                    zxc = " "
                                    zx2 = []
                                    pesan2 = "@a"" "
                                    xlen = str(len(zxc))
                                    xlen2 = str(len(zxc)+len(pesan2)-1)
                                    zx = {'S':xlen, 'E':xlen2, 'M':key1}
                                    zx2.append(zx)
                                    zxc += pesan2
                                    msg.contentType = 0
                                    msg.text = zxc
                                    lol = {'MENTION':str('{"MENTIONEES":'+json.dumps(zx2).replace(' ','')+'}')}
                                    msg.contentMetadata = lol
                                    jmlh = int(Setmain["ARlimit"])
                                    if jmlh <= 1000:
                                        for x in range(jmlh):
                                            try:
                                                cl.sendMessage1(msg)
                                            except Exception as e:
                                                cl.sendText(msg.to,str(e))
                                    else:
                                        cl.sendText(msg.to,"Jumlah melebihi 1000")                            
                    
                          elif cmd.startswith("jumlah: "):
                                if wait["selfbot"] == True:
                                  if msg._from in admin:
                                    proses = text.split(":")
                                    strnum = text.replace(proses[0] + ":","")
                                    num =  int(strnum)
                                    Setmain["ARlimit"] = num
                                    sendTextTemplate1(msg.to,"Total Spamtag Diubah Menjadi " +strnum)

#===============================❒  ❒  ❒  ❒  ❒  ❒  ❒  ❒  ❒  ❒  ❒  ❒  ❒  ❒  
                        
                        elif ("Admin " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           admin.append(target)
                                           sendTextTemplate1(msg.to,"❒   ᴅᴏɴᴇ ᴀᴅᴅᴀᴅᴍɪɴ")
                                       except:
                                           pass
                        elif ("Staff " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           staff.append(target)
                                           sendTextTemplate1(msg.to,"❒   Telah Diangkat Menjadi Staff Bot")
                                       except:
                                           pass
                        elif ("Admindell " in msg.text):
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target not in Saints:
                                       try:
                                           admin.remove(target)
                                           sendTextTemplate1(msg.to,"❒   Telah Dihapus Menjadi Admin Bot")
                                       except:
                                           pass
                        elif ("Staffdell " in msg.text):
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target not in Saints:
                                       try:
                                           staff.remove(target)
                                           sendTextTemplate1(msg.to,"❒ Telah Dihapus Menjadi Staff Bot")
                                       except:
                                           pass
#===============================
                        elif ("Ban " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           wait["blacklist"][target] = True
                                           sendFooter(msg.to,"❒ Berhasil menambahkan blacklist")
                                       except:
                                           pass
                                           
                        elif 'Protecturl ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Protecturl ','')
                              if spl == 'on':
                                  if msg.to in protectqr:
                                       msgs = "⌬ Protect url sudah aktif"
                                  else:
                                       protectqr.append(msg.to)
                                       ginfo = cl.getGroup(msg.to)
                                       msgs = "⌬ Protect url diaktifkan\nDi Group : " +str(ginfo.name)
                                  cl.sendMessage(msg.to, "「Diaktifkan」\n" + msgs)
                              elif spl == 'off':
                                    if msg.to in protectqr:
                                         protectqr.remove(msg.to)
                                         ginfo = cl.getGroup(msg.to)
                                         msgs = "Protect url dinonaktifkan\nDi Group : " +str(ginfo.name)
                                    else:
                                         msgs = "⌬ Protect url sudah tidak aktif"
                                    cl.sendMessage(msg.to, "「Dinonaktifkan」\n" + msgs)

                        elif 'Protectkick ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Protectkick ','')
                              if spl == 'on':
                                  if msg.to in protectkick:
                                       msgs = "⌬ Protect kick sudah aktif"
                                  else:
                                       protectkick.append(msg.to)
                                       ginfo = cl.getGroup(msg.to)
                                       msgs = "⌬ Protect kick diaktifkan\nDi Group : " +str(ginfo.name)
                                  cl.sendMessage(msg.to, "「Diaktifkan」\n" + msgs)
                              elif spl == 'off':
                                    if msg.to in protectkick:
                                         protectkick.remove(msg.to)
                                         ginfo = cl.getGroup(msg.to)
                                         msgs = "⌬Protect kick dinonaktifkan\nDi Group : " +str(ginfo.name)
                                    else:
                                         msgs = "⌬Protect kick sudah tidak aktif"
                                    cl.sendMessage(msg.to, "「Dinonaktifkan」\n" + msgs)

                        elif 'Protectjoin ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Protectjoin ','')
                              if spl == 'on':
                                  if msg.to in protectjoin:
                                       msgs = "⌬ Protect join sudah aktif"
                                  else:
                                       protectjoin.append(msg.to)
                                       ginfo = cl.getGroup(msg.to)
                                       msgs = "⌬ Protect join diaktifkan\nDi Group : " +str(ginfo.name)
                                  cl.sendMessage(msg.to, "「Diaktifkan」\n" + msgs)
                              elif spl == 'off':
                                    if msg.to in protectjoin:
                                         protectjoin.remove(msg.to)
                                         ginfo = cl.getGroup(msg.to)
                                         msgs = "⌬ Protect join dinonaktifkan\nDi Group : " +str(ginfo.name)
                                    else:
                                         msgs = "⌬ Protect join sudah tidak aktif"
                                    cl.sendMessage(msg.to, "「Dinonaktifkan」\n" + msgs)

                        elif 'Protectcancel ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Protectcancel ','')
                              if spl == 'on':
                                  if msg.to in protectcancel:
                                       msgs = "⌬ Protect cancel sudah aktif"
                                  else:
                                       protectcancel.append(msg.to)
                                       ginfo = cl.getGroup(msg.to)
                                       msgs = "⌬ Protect cancel diaktifkan\nDi Group : " +str(ginfo.name)
                                  cl.sendMessage(msg.to, "「Diaktifkan」\n" + msgs)
                              elif spl == 'off':
                                    if msg.to in protectcancel:
                                         protectcancel.remove(msg.to)
                                         ginfo = cl.getGroup(msg.to)
                                         msgs = "⌬Protect cancel dinonaktifkan\nDi Group : " +str(ginfo.name)
                                    else:
                                         msgs = "⌬Protect cancel sudah tidak aktif"
                                    cl.sendMessage(msg.to, "「Dinonaktifkan」\n" + msgs)
                                    
                        elif 'Protectinvite ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Protectinvite ','')
                              if spl == 'on':
                                  if msg.to in protectinvite:
                                       msgs = "⌬ Protect invite sudah aktif"
                                  else:
                                       protectinvite.append(msg.to)
                                       ginfo = cl.getGroup(msg.to)
                                       msgs = "⌬ Protect invite diaktifkan\nDi Group : " +str(ginfo.name)
                                  cl.sendMessage(msg.to, "「Diaktifkan」\n" + msgs)
                              elif spl == 'off':
                                    if msg.to in protectinvite:
                                         protectinvite.remove(msg.to)
                                         ginfo = cl.getGroup(msg.to)
                                         msgs = "⌬Protect invite dinonaktifkan\nDi Group : " +str(ginfo.name)
                                    else:
                                         msgs = "⌬Protect invite sudah tidak aktif"
                                    cl.sendMessage(msg.to, "「Dinonaktifkan」\n" + msgs)                                                       
                                         
                        elif ("Unban " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           del wait["blacklist"][target]
                                           sendFooter(msg.to,"❒   Berhasil menghapus blacklist")
                                       except:
                                           pass
                        elif cmd == "ban:on" or text.lower() == 'ban:on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["wblacklist"] = True
                                sendTextTemplate1(msg.to,"Kirim kontaknya...")
                        elif cmd == "unban:on" or text.lower() == 'unban:on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["dblacklist"] = True
                                sendTextTemplate1(msg.to,"Kirim kontaknya...")
                        elif cmd == "wanted" or text.lower() == 'banlist':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                              if wait["blacklist"] == {}:
                                sendFooter1(msg.to,"Tak ada daftar buronan")
                              else:
                                ma = ""
                                a = 0
                                for m_id in wait["blacklist"]:
                                    a = a + 1
                                    end = '\n'
                                    ma += str(a) + ". " +cl.getContact(m_id).displayName + "\n"
                                sendFooter1(msg.to,"Blacklist User\n\n"+ma+"\nTotal「%s」Blacklist User" %(str(len(wait["blacklist"]))))

                        elif cmd == "blc" or text.lower() == 'bl':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                              if wait["blacklist"] == {}:
                                   cl.sendMessage(msg.to,"ᴛɪᴅᴀᴋ ᴀᴅᴀ ʙᴀᴄᴋʟɪꜱᴛ")
                              else:
                                    ma = ""
                                    for i in wait["blacklist"]:
                                        ma = cl.getContact(i)
                                        cl.sendMessage(msg.to, None, contentMetadata={'mid': i}, contentType=13)
                        elif cmd == "cban" or text.lower() == 'clearban':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                              wait["blacklist"] = {}
                              ragets = cl.getContacts(wait["blacklist"])
                              mc = "「%i」" % len(ragets)
                              sendTextTemplate1(msg.to,"ᴅᴏɴᴇ ᴄʟᴇᴀʀ ʙᴀᴄᴋʟɪꜱᴛ" +mc)
                                                   
#===============================
                        elif 'Set pesan: ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Set pesan: ','')
                              if spl in [""," ","\n",None]:
                                  sendFooter1(msg.to, "Gagal mengganti Pesan Msg")
                              else:
                                  wait["message"] = spl
                                  sendFooter1(msg.to, "「Pesan Msg」\nPesan Msg diganti jadi :\n\n「{}」".format(str(spl)))
                        elif 'Set welcome: ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Set welcome: ','')
                              if spl in [""," ","\n",None]:
                                  sendFooter1(msg.to, "Gagal mengganti Welcome Msg")
                              else:
                                  wait["welcome"] = spl
                                  sendFooter1(msg.to, "「Welcome Msg」\nWelcome Msg diganti jadi :\n\n「{}」".format(str(spl)))
                                  
                        elif 'Set mention: ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Set mention: ','')
                              if spl in [""," ","\n",None]:
                                  sendFooter1(msg.to, "Gagal mengganti Key mention all member")
                              else:
                                  wait["tagall"] = spl
                                  sendFooter1(msg.to, "❒  ᴋᴇʏ ᴍᴇɴᴛɪᴏɴ ᴍᴇᴍʙᴇʀ :\n\n{}".format(str(spl)))
                                                
                        elif 'Set autoleave: ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Set autoleave: ','')
                              if spl in [""," ","\n",None]:
                                  sendFooter1(msg.to, "Gagal mengganti Autoleave Msg")
                              else:
                                  wait["autoLave"] = spl
                                  sendFooter1(msg.to, "「Autoleave Msg」\nAutoleave Msg diganti jadi :\n\n「{}」".format(str(spl)))
                                  
                        elif 'Set respon: ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Set respon: ','')
                              if spl in [""," ","\n",None]:
                                  sendFooter1(msg.to, "Gagal mengganti Respon Msg")
                              else:
                                  wait["Respontag"] = spl
                                  sendFooter1(msg.to, "「Respon Msg」\nRespon Msg diganti jadi :\n\n「{}」".format(str(spl)))
                                  
                        elif 'Set respon3: ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Set respon3: ','')
                              if spl in [""," ","\n",None]:
                                  sendFooter1(msg.to, "Gagal mengganti Respon Msg")
                              else:
                                  wait["Respontag3"] = spl
                                  sendFooter1(msg.to, "「Respon Msg」\nRespon Msg diganti jadi :\n\n「{}」".format(str(spl)))
                        elif 'Set respon4: ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Set respon3: ','')
                              if spl in [""," ","\n",None]:
                                  sendFooter1(msg.to, "Gagal mengganti Respon Msg")
                              else:
                                  wait["Respontag4"] = spl
                                  sendFooter1(msg.to, "「Respon Msg」\nRespon Msg diganti jadi :\n\n「{}」".format(str(spl)))
                        elif 'Set respon2: ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Set respon2: ','')
                              if spl in [""," ","\n",None]:
                                  sendFooter1(msg.to, "Gagal mengganti Respon Msg")
                              else:
                                  wait["Respontag2"] = spl
                                  sendFooter1(msg.to, "「Respon Msg」\nRespon Msg diganti jadi :\n\n「{}」".format(str(spl)))
                        elif 'Set sider: ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Set sider: ','')
                              if spl in [""," ","\n",None]:
                                  sendFooter1(msg.to, "Gagal mengganti Sider Msg")
                              else:
                                  wait["mention"] = spl
                                  sendFooter1(msg.to, "「Sider Msg」\nSider Msg diganti jadi :\n\n「{}」".format(str(spl)))
                        
                        elif text.lower() == "cek welcome":
                            if msg._from in admin:
                               sendFooter1(msg.to, "「Welcome Msg」\nWelcome Msg mu :\n\n「 " + str(wait["welcome"]) + " 」")
                        elif text.lower() == "cek leave":
                            if msg._from in admin:
                               sendFooter1(msg.to, "「Autoleave Msg」\nAutoleave Msg mu :\n\n「 " + str(wait["autoleave"]) + " 」")
                        elif text.lower() == "cek respon":
                            if msg._from in admin:
                               sendFooter1(msg.to, "「Respon Msg」\nRespon Msg mu :\n\n「 " + str(wait["Respontag"]) + " 」")
                        elif text.lower() == "cek respon2":
                            if msg._from in admin:
                               sendFooter1(msg.to, "「Respon Msg」\nRespon Msg mu :\n\n「 " + str(wait["Respontag2"]) + " 」")
                        elif text.lower() == "cek respon3":
                            if msg._from in admin:
                               sendFooter1(msg.to, "「Respon Msg」\nRespon Msg mu :\n\n「 " + str(wait["Respontag3"]) + " 」")
                        elif text.lower() == "cek respon4":
                            if msg._from in admin:
                               sendFooter1(msg.to, "「Respon Msg」\nRespon Msg mu :\n\n「 " + str(wait["Respontag4"]) + " 」")
                        elif text.lower() == "cek mention":
                            if msg._from in admin:
                               sendFooter(msg.to, "ꜱᴇᴛ ᴍᴇɴᴛɪᴏɴ ᴋᴇʏ:\n\n" + str(wait["tagall"])) 
#===============================❒  ❒  ❒  ❒  ❒  ❒  ❒  ❒  ❒  ❒  ❒  ❒  ❒  ❒  
                        elif "youtube" in msg.text.lower():
                          if msg._from in admin:
                            try:
                                sep = msg.text.split(" ")
                                textToSearch = msg.text.replace(sep[0] + " ","")
                                query = urllib.parse.quote(textToSearch)
                                tz = pytz.timezone("Asia/Jakarta")
                                timeNow = datetime.now(tz=tz)
                                cover = cl.getProfileCoverURL(mid)
                                search_url="https://www.youtube.com/results?search_query="
                                mozhdr = {'User-Agent': 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'}
                                sb_url = search_url + query
                                sb_get = requests.get(sb_url, headers = mozhdr)
                                soupeddata = BeautifulSoup(sb_get.content, "html.parser")
                                yt_links = soupeddata.find_all("a", class_ = "yt-uix-tile-link")
                                x = (yt_links[1])
                                yt_href =  x.get("href")
                                yt_href = yt_href.replace("watch?v=", "")
                                qx = "https://youtu.be" + str(yt_href)
                                vid = pafy.new(qx)
                                stream = vid.streams
                                best = vid.getbest()
                                best.resolution, best.extension
                                for s in stream:
                                    me = best.url
                                    data = {
                                "type": "flex",
                                "altText": "TEAM TERMUX",
                                "contents": {
"type": "carousel",
"contents": [
{
"type": "bubble",
"size": "nano",
"body": {
"backgroundColor": "#00ff00",
"type": "box",
"layout": "vertical",
"contents": [
{
"type": "image", #Wall 1
"url": "https://content.skyscnr.com/m/7d3992c451e6cf6c/original/color.gif?imbypass=true",
"size": "full",
"aspectMode": "cover",
"aspectRatio": "4:5",
"gravity": "bottom",
"action": {
"uri": "line://nv/profilePopup/mid=u1aaf34421b7a8a94e0a977095e4ff605",
"type": "uri",
}
},
{
"type": "box",
"layout": "vertical",
"contents": [
{
"type": "image", #Wall 2
"url": "https://content.skyscnr.com/m/7d3992c451e6cf6c/original/color.gif?imbypass=true",
"gravity": "bottom",
"size": "xxl",
"aspectMode": "cover",
"aspectRatio": "2:3",
"offsetTop": "0px",
"action": {
"uri": "line://nv/profilePopup/mid=u1aaf34421b7a8a94e0a977095e4ff605",
"type": "uri",
}
}
],
"position": "absolute",
"cornerRadius": "5px",
"offsetTop": "5px",
"offsetStart": "5px",
"height": "140px",
"width": "110px"
},
{
"type": "box",
"layout": "vertical",
"contents": [
{
"type": "image", #Wall 2
"url": cover, #"https://obs.line-scdn.net/{}".format(cl.getContact(sender).pictureStatus),
"gravity": "bottom",
"size": "xxl",
"aspectMode": "cover",
"aspectRatio": "2:3",
"offsetTop": "0px",
"action": {
"uri": "line://nv/profilePopup/mid=u1aaf34421b7a8a94e0a977095e4ff605",
"type": "uri",
}
}
],
"position": "absolute",
"cornerRadius": "5px",
"offsetTop": "5px",
"offsetStart": "5px",
"height": "140px",
"width": "110px"
},
{
"type": "box",
"layout": "vertical",
"contents": [
{
"type": "image", #Wall 2
"url": "https://obs.line-scdn.net/{}".format(cl.getContact(sender).pictureStatus),
"gravity": "bottom",
"size": "xxl",
"aspectMode": "cover",
"aspectRatio": "2:3",
"offsetTop": "0px",
"action": {
"uri": "line://nv/profilePopup/mid=u1aaf34421b7a8a94e0a977095e4ff605",
"type": "uri",
}
}
],
"position": "absolute",
"cornerRadius": "5px",
"offsetTop": "5px",
"offsetStart": "5px",
"height": "140px",
"width": "110px"
},
{
"type": "box",
"layout": "vertical",
"contents": [
{
"type": "text",
"text": "ʏᴏuᴛᴜʙᴇ",
"align": "center",
"color": "#000000",
"weight": "bold",
"size": "xxs",
"weight": "bold",
"offsetTop": "1px"
}
],
"position": "absolute",
"cornerRadius": "5px",
"offsetTop": "7px",
"backgroundColor": "#ffd700",
"offsetStart": "7px",
"height": "15px",
"width": "45px"
},
{
"type": "box",
"layout": "vertical",
"contents": [ #====================================================== 
{
"type": "image",
"url": "https://thumbs.gfycat.com/DependentSleepyHusky-size_restricted.gif",
#======================================================  
"size": "xxl",
"action": {
"type": "uri",
"uri": "https://wa.me/085757076639",
},         
"flex": 0
}
],
"position": "absolute",
"offsetTop": "5px",
"offsetStart": "92px",
"height": "43px",
"width": "22px"
},
{
"type": "box",
"layout": "vertical",
"contents": [ #dsini
{
"type": "image",
"url": "https://thumbs.gfycat.com/DependentSleepyHusky-size_restricted.gif",
#====================================================== 
"size": "xxl",
"action": {
"type": "uri",
"uri": "https://youtube.com",
},         
"flex": 0
}
],
"position": "absolute",
"offsetTop": "5px",
"offsetStart": "67px",
"height": "43px",
"width": "22px"
},
{
"type": "box",
"layout": "vertical",
"contents": [ #======================================================  
{
"type": "image",
"url": "https://i.ibb.co.com/CntKh4x/20190525-152240.png", #smule
"size": "xl",
"action": {
"type": "uri",
"uri": "Https://smule.com/Zul_moko",
},
"flex": 0
},{
"type": "image",
"url": "https://i.ibb.co.com/ZHtFDts/20190427-185307.png",
"size": "xl",
"action": {
"type": "uri",
"uri": "line://nv/chat",
},
"flex": 0
},{
"type": "image",
"url": "https://i.ibb.co.com/b53ztTR/20190427-191019.png", #linehttps://icon-icons.com/icons2/70/PNG/512/line_14096.png", #line
"size": "full",
"action": {
"type": "uri",
"uri": "http://line.me/ti/p/~Zul.1.02",
},
"flex": 0
},{
"type": "image",
"url": "https://i.ibb.co.com/1sGhJdC/20190428-232658.png",
"size": "xl",
"action": {
"type": "uri",
"uri": "http://line.me/ti/p/~Zul.1.02"
},
"flex": 0
}
],
"position": "absolute",
"offsetTop": "25px",
"offsetStart": "5px",
"height": "180px",
"width": "25px"
},
{
"type": "box",
"layout": "vertical",
"contents": [
{
"type": "text",
"text": "❒   "+ datetime.strftime(timeNow,'%H:%M:%S'),
"weight": "bold",
"color": "#ffffff",
#"align": "center",
"size": "xxs",
"offsetTop": "0px"
}
],
"position": "absolute",
"cornerRadius": "5px",
"offsetTop": "98px",
"backgroundColor": "#ff0000",
"offsetStart": "50px",
"height": "16px",
"width": "63px"
},
{
"type": "box",
"layout": "vertical",
"contents": [
{
"type": "text",
"text": "🎙️" + str(vid.author),
"weight": "bold",
"color": "#ffffff",
"size": "xxs",
"offsetTop": "0px"
}
],
"position": "absolute",
"cornerRadius": "5px",
"offsetTop": "115px",
"backgroundColor": "#0000ff",
"offsetStart": "33px",
"height": "16px",
"width": "80px"
},
{
"type": "box",
"layout": "vertical",
"contents": [
{
"type": "text",
"text": "TEAM TERMUX",
"weight": "bold",
"color": "#00ff00",
"size": "xxs",
"offsetTop": "0px"
}
],
"position": "absolute",
"cornerRadius": "5px",
"offsetTop": "130px",
#===================================================== 
"offsetStart": "8px",
"height": "50px",
"width": "110px"
}
],
#======================================================
"paddingAll": "0px"
}
},
]
}
}
                                cl.postTemplate(to, data)
                                cl.sendVideoWithURL(msg.to, me)
                            except Exception as e:
                                cl.sendMessage(msg.to,str(e))

                        elif "yutube" in msg.text.lower():
                          if msg._from in admin:
                            try:
                                sep = msg.text.split(" ")
                                textToSearch = msg.text.replace(sep[0] + " ","")
                                query = urllib.parse.quote(textToSearch)
                                search_url="https://www.youtube.com/results?search_query="
                                mozhdr = {'User-Agent': 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'}
                                sb_url = search_url + query
                                sb_get = requests.get(sb_url, headers = mozhdr)
                                soupeddata = BeautifulSoup(sb_get.content, "html.parser")
                                yt_links = soupeddata.find_all("a", class_ = "yt-uix-tile-link")
                                x = (yt_links[1])
                                yt_href =  x.get("href")
                                yt_href = yt_href.replace("watch?v=", "")
                                qx = "https://youtu.be" + str(yt_href)
                                vid = pafy.new(qx)
                                stream = vid.streams
                                best = vid.getbest()
                                best.resolution, best.extension
                                for s in stream:
                                    me = best.url
                                    data = {
                                        "type": "flex",
                                        "altText": "TEAM TERMUX",
                                        "contents": {
  "styles": {
    "body": {
      "backgroundColor": "#800000"
    },
    "footer": {
      "backgroundColor": "#800000"
    }
  },
  "type": "bubble",
 "size": "micro",
      "body": {
  "contents": [
      {
        "contents": [                   
            {            
            "type": "separator",
            "color": "#FFFFFF"            
      },
      {
        "type": "separator",
        "color": "#FFFFFF"  
      },
      {         
         "contents": [
          {
          "type": "separator",
          "color": "#FFFFFF"   
      },
      {
            "contents": [
              {
              "type": "image",
     "url": "https://media.tenor.com/images/3cfcb167ed18a35f3a52f70e44fdf6c0/tenor.gif",
    "size": "xxs"
          },{
 "type": "text",
"text": "™Bₒₜₛ",
"weight": "bold",
"color": "#FFFFFF",
"size": "xxs",
"flex": 0
},{
"type": "text",
"text": "speed",
"weight": "bold",
"color": "#FFFFFF",
"size": "xxs",
"flex": 0
},{
"type": "text",
"text": "ʙᴏᴛꜱ",
"weight": "bold",
"color": "#FFFFFF",
"size": "xxs",
"flex": 0
      },
      {
    "type": "image",
     "url": "https://media.tenor.com/images/3cfcb167ed18a35f3a52f70e44fdf6c0/tenor.gif",
    "size": "xxs"
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "horizontal"    
      },
      {
        "type": "separator",
         "color": "#33ffff"
         }
            ],
            "type": "box",
            "layout": "horizontal"   
            },
         {
        "type": "separator",
        "color": "#33ffff"
         },
         {
       "contents": [
         {
        "type": "separator",
        "color": "#FFFFFF"
         },
         {
            "text": "🎙🎙🎙",
            "size": "xxs",
            "color": "#FF9900",
            "align": "center",
            "wrap": True,
            "weight": "bold",
            "type": "text"
            },{
            "type": "separator",
            "color": "#33ffff"
           },
             {
            "text": "🎙🎙🎙",
            "size": "xxs",
            "color": "#FF9900",
            "align": "center",
            "wrap": True,
            "weight": "bold",
            "type": "text"
            },{
            "type": "separator",
            "color": "#33ffff"
           },
             {
            "text": "🎙🎙🎙",
            "size": "xxs",
            "color": "#FFFFFF",
            "align": "center",
            "wrap": True,
            "weight": "bold",
            "type": "text"   
            },
         {
        "type": "separator",
        "color": "#33ffff"
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "horizontal"    
      },
      {
        "type": "separator",
         "color": "#33ffff"
         },
         {
       "contents": [
          {
           "type": "separator",
           "color": "#33ffff"
          },
          {
          "type": "image",
            "url": "https://thumbs.gfycat.com/DependentSleepyHusky-max-1mb.gif", 
            "size": "xxs",
            "action": {
            "type": "uri",
            "uri": "https://youtube.com",
          },
            "flex": 0
          },
          {
        "type": "separator",
        "color": "#FFFFFF"
      },
      {      
       "contents": [              
          {
"type": "text",
"text": "TEAM TERMUX",
"weight": "bold",
"color": "#FFFFFF",
"align": "center",
"size": "xxs",
"flex": 0
},{
"type": "separator",
"color": "#FFFFFF"
},{
"type": "text",
"text": "❒   "+ str(vid.duration),
"weight": "bold",
"color": "#FFFFFF",
#"align": "center",
"size": "xxs",
"flex": 0
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "vertical"
      },
      {
        "type": "separator",
        "color": "#FFFFFF"
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "horizontal"
      },
      {
        "type": "separator",
         "color": "#FFFFFF"
       },
       {     
       "contents": [           
         { 
           "type": "separator",
           "color": "#FFFFFF"
            },
           {
            "contents": [
              {
              "type": "separator",
           "color": "#FFFFFF"
            },
           {
          "type": "text",
"text": "voc:" + str(vid.author),
"weight": "bold",
"color": "#FFFFFF",
"align": "center",
"size": "xxs",
"flex": 0
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "vertical"    
      },
      {
        "type": "separator",
         "color": "#FFFFFF"
         }
            ],
            "type": "box",
            "layout": "horizontal"   
            },
         {
        "type": "separator",
        "color": "#FFFFFF"
         },
         {          
         "contents": [
         { 
           "type": "separator",
           "color": "#FFFFFF"
            },
           {
            "contents": [
              {
              "type": "separator",
           "color": "#FFFFFF"
            },
           {
          "text": "🎙ᴊᴜᴅᴜʟ🎙\n " + vid.title + " ",
           "size": "xxs",
          "align": "center",
           "color": "#FFFFFF",
           "wrap": True,
           "weight": "bold",
           "type": "text"
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "vertical"    
      },
      {
        "type": "separator",
         "color": "#FFFFFF"
         }
            ],
            "type": "box",
            "layout": "horizontal"   
            },
         {
        "type": "separator",
        "color": "#FFFFFF"
         },
         {
       "contents": [
         {
        "type": "separator",
        "color": "#FFFFFF"
         },
         {
            "text": "👨‍💻👨‍💻👨‍💻",
            "size": "xxs",
            "color": "#FF9900",
            "align": "center",
            "wrap": True,
            "weight": "bold",
            "type": "text"
            },{
            "type": "separator",
            "color": "#33ffff"
           },
             {
            "text": "👨‍💻👨‍💻👨‍💻",
            "size": "xxs",
            "color": "#FF9900",
            "align": "center",
            "wrap": True,
            "weight": "bold",
            "type": "text"
            },{
            "type": "separator",
            "color": "#33ffff"
           },
             {
            "text": "👨‍💻👨‍💻👨‍💻",
            "size": "xxs",
            "color": "#FF9900",
            "align": "center",
            "wrap": True,
            "weight": "bold",
            "type": "text"   
          },
         {
        "type": "separator",
        "color": "#FFFFFF"
         }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "horizontal"    
      },
      {
        "type": "separator",
         "color": "#FFFFFF"
         },
         {
      "contents": [
          {
            "type": "separator",
            "color": "#33ffff"
            },
             {
            "type": "image",
            "url": "https://i.ibb.co.com/XWQd8rj/20190625-201419.png",
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "https://youtube.com",
           }, 
            "flex": 1
          },
          {
          "type": "image",
            "url": "https://i.ibb.co.com/b53ztTR/20190427-191019.png", #linehttps://icon-icons.com/icons2/70/PNG/512/line_14096.png", #line
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "http://line.me/ti/p/~Zul.1.02",             
           }, 
            "flex": 1            
          },
          {
          "type": "image",
            "url": "https://i.ibb.co.com/ZHtFDts/20190427-185307.png", #chathttps://i.ibb.co.com/b53ztTR/20190427-191019.png", #linehttps://icon-icons.com/icons2/70/PNG/512/line_14096.png", #line
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "line://nv/chat" #"http://line.me/ti/p/~Zul.1.02",
            },         
            "flex": 1          
            },
          {
          "type": "image",
            "url": "https://i.ibb.co.com/CntKh4x/20190525-152240.png", #smule
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "Https://smule.com/Zul_moko",
            },         
            "flex": 1          
          },
          {
          "type": "image",
            "url": "https://i.ibb.co.com/Wf8bQ2Z/20190625-105354.png",
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "line://nv/cameraRoll/multi"
            },
            "flex": 1
            },
            {
            "contents": [
            {
            "type": "image",
            "url": "https://i.ibb.co.com/1sGhJdC/20190428-232658.png",
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "http://line.me/ti/p/~Zul.1.02"
          },
            "flex": 1           
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "vertical"    
      },
      {
        "type": "separator",
         "color": "#FFFFFF"
         }
            ],
            "type": "box",
            "layout": "horizontal"   
            },
         {
        "type": "separator",
        "color": "#FFFFFF"
        },{
        "contents": [         
              {
            "type": "separator",
            "color": "#FFFFFF"
            },
             {          
            "contents": [
               {
    "type": "image",
    "url": "https://media.tenor.com/images/3cfcb167ed18a35f3a52f70e44fdf6c0/tenor.gif",
    "size": "xxs"
    },{
 "type": "text",
"text": "SB TEAM TERMUX",
"weight": "bold",
"color": "#FFFFFF",
"size": "xxs",
"flex": 0
},{
"type": "text",
"text": "™Bₒₜₛ",
"weight": "bold",
"color": "#FFFFFF",
"size": "xxs",
"flex": 0
},{
"type": "text",
"text": "ʙᴏᴛꜱ",
"weight": "bold",
"color": "#FFFFFF",
"size": "xxs",
"flex": 0
      },
      {
    "type": "image",
    "url": "https://media.tenor.com/images/3cfcb167ed18a35f3a52f70e44fdf6c0/tenor.gif",
    "size": "xxs"
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "horizontal"    
      },
      {
        "type": "separator",
         "color": "#FFFFFF"
         }
            ],
            "type": "box",
            "layout": "horizontal"   
            },
         {
        "type": "separator",
        "color": "#FFFFFF"     
          }
        ],
        "type": "box",
        "layout": "vertical"
      }
    ],
    "type": "box",
    "spacing": "xs",
    "layout": "vertical"
  }
}
}
                                cl.postTemplate(to, data)
                                cl.sendVideoWithURL(msg.to, me)
                            except Exception as e:
                                cl.sendMessage(msg.to,str(e))


#==============================================================
                        
                        elif cmd == "mempict":
                              if msg._from in admin:
                                  kontak = cl.getGroup(to)
                                  group = kontak.members
                                  picall = []
                                  for ids in group:
                                    if len(picall) >= 400:
                                      pass
                                    else:
                                      picall.append({
                                        "imageUrl": "https://os.line.naver.jp/os/p/{}".format(ids.mid),
                                        "action": {
                                          "type": "uri",
                                          "uri": "http://line.me/ti/p/~Zul.1.02"
                                          }
                                        }
                                      )
                                  k = len(picall)//10
                                  for aa in range(k+1):
                                    data = {
                                      "type": "template",
                                      "altText": "{} membagikan janda".format(cl.getProfile().displayName),
                                      "template": {
                                        "type": "image_carousel",
                                        "columns": picall[aa*10 : (aa+1)*10]
                                      }
                                    }
                                    cl.postTemplate(to, data)

#======================================================================
                        elif "/ti/g/" in msg.text.lower():
                          #if wait["selfbot"] == True:
                            #if msg._from in admin or msg._from in owner:
                              if settings["autoJoinTicket"] == True:
                                 link_re = re.compile('(?:line\:\/|line\.me\/R)\/ti\/g\/([a-zA-Z0-9_-]+)?')
                                 links = link_re.findall(text)
                                 n_links = []
                                 for l in links:
                                     if l not in n_links:
                                        n_links.append(l)
                                 for ticket_id in n_links:
                                     group = cl.findGroupByTicket(ticket_id)
                                     cl.acceptGroupInvitationByTicket(group.id,ticket_id)
                                     sendFooter2(msg.to, "❒  ᴛᴇʟᴀʜ ʙᴇʀʜᴀꜱɪʟ ᴍᴀꜱᴜᴋ ᴋᴇ ɢʀᴜᴘ : %s" % str(group.name))
#======================================================================
                        elif text.lower() == "cek":
                	          if msg._from in admin:
                	              try:
                	                  sendFooter(msg.to, ["u1aaf34421b7a8a94e0a977095e4ff605"]);bot1 = True
                	              except:bot1 = False
                	              md = "╭━━━━━━━━╮\n"
                	              md += "┃ᴄᴇᴋ ᴋᴇꜱᴇʜᴀᴛᴀɴ       ┃\n"
                	              md += "╰━━━━━━━━╯\n"
                	              if bot1 == True: md+="┃🌺 DUDAH ™ ɴᴏʀᴍᴀʟ\n╰━━━━━━━━╯"
                	              else: md+="┃🌺 ᴊᴀɴᴅᴀ ™ ʟɪᴍɪᴛ\n╰━━━━━━━━╯"
                	              sendFooter(msg.to,md)   
#=====================================================================
                        elif cmd.startswith("addmp3 "):
                            if msg._from in admin:
                                sep = text.split(" ")
                                name = text.replace(sep[0] + " ","")
                                name = name.lower()
                                if name not in audios:
                                    settings["Addaudio"]["status"] = True
                                    settings["Addaudio"]["name"] = str(name.lower())
                                    audios[str(name.lower())] = ""
                                    f = codecs.open("audio.json","w","utf-8")
                                    json.dump(audios, f, sort_keys=True, indent=4, ensure_ascii=False)
                                    sendFooter(msg.to,"Silahkan kirim mp3 nya...") 
                                else:
                                    sendFooter(msg.to, "Mp3 itu sudah dalam list") 
                                
                        elif cmd.startswith("dellmp3 "):
                            if msg._from in admin:
                                sep = text.split(" ")
                                name = text.replace(sep[0] + " ","")
                                name = name.lower()
                                if name in audios:
                                    cl.deleteFile(audios[str(name.lower())])
                                    del audios[str(name.lower())]
                                    f = codecs.open("audio.json","w","utf-8")
                                    json.dump(audios, f, sort_keys=True, indent=4, ensure_ascii=False)
                                    sendFooter(msg.to, "Done hapus mp3 {}".format( str(name.lower())))
                                else:
                                    sendFooter(msg.to, "Mp3 itu tidak ada dalam list") 
                                 
                        elif cmd == "listmp3":
                            if msg._from in admin:
                                no = 0
                                ret_ = "╔═══❲ My Music ❳════\n"
                                for audio in audios:
                                    ret_ += "┣❒   " + audio.title() + "\n"
                                ret_ += "╚═══❲ {} Record  ❳════".format(str(len(audios)))
                                sendFooter(to, ret_)

                        elif cmd.startswith("addsticker "):
                            if msg._from in admin:
                                sep = text.split(" ")
                                name = text.replace(sep[0] + " ","")
                                name = name.lower()
                                if name not in stickers:
                                    settings["Addsticker"]["status"] = True
                                    settings["Addsticker"]["name"] = str(name.lower())
                                    stickers[str(name.lower())] = ""
                                    f = codecs.open("Sticker.json","w","utf-8")
                                    json.dump(stickers, f, sort_keys=True, indent=4, ensure_ascii=False)
                                    sendFooter(to, "❒   Silahkan Kirim Sricker Nyah Yah") 
                                else:
                                    sendFooter(to, "❒   Sticker itu sudah dalam List") 
                                
                        elif cmd.startswith("dellsticker "):
                            if msg._from in admin:
                                sep = text.split(" ")
                                name = text.replace(sep[0] + " ","")
                                name = name.lower()
                                if name in stickers:
                                    del stickers[str(name.lower())]
                                    f = codecs.open("sticker.json","w","utf-8")
                                    json.dump(stickers, f, sort_keys=True, indent=4, ensure_ascii=False)
                                    sendFooter(to, "❒   Berhasil menghapus sticker {}".format( str(name.lower())))
                                else:
                                    sendFooter(to, "❒   Sticker ada di list") 
                                                   
                        elif cmd == "liststicker":
                            if msg._from in admin:
                                no = 0
                                ret_ = "╔═══❲ My Sticker ❳════\n"
                                for sticker in stickers:
                                    ret_ += "┣❒    " + sticker.title() + "\n"
                                ret_ += "╚═══❲  {} Stickers  ❳════".format(str(len(stickers)))
                                sendFooter(to, ret_)

                        elif cmd.startswith("addimg "):
                            if msg._from in admin:
                                sep = text.split(" ")
                                name = text.replace(sep[0] + " ","")
                                name = name.lower()
                                if name not in images:
                                    settings["Addimage"]["status"] = True
                                    settings["Addimage"]["name"] = str(name.lower())
                                    images[str(name.lower())] = ""
                                    f = codecs.open("image.json","w","utf-8")
                                    json.dump(images, f, sort_keys=True, indent=4, ensure_ascii=False)
                                    sendFooter(to, "Silahkan kirim fotonya")
                                else:
                                    sendFooter(to, "Foto Udah dalam list")

                        elif cmd.startswith("dellimg "):
                            if msg._from in admin:
                               sep = text.split(" ")
                               name = text.replace(sep[0] + " ","")
                               name = name.lower()
                               if name in images:
                                   cl.deleteFile(images[str(name.lower())])
                                   del images[str(name.lower())]
                                   f = codecs.open("image.json","w","utf-8")
                                   json.dump(images, f, sort_keys=True, indent=4, ensure_ascii=False)
                                   sendFooter(to, "Berhasil menghapus {}".format( str(name.lower())))
                               else:
                                   sendFooter(to, "Foto ada dalam list")

                        elif cmd == "listimage":
                            if msg._from in admin:
                                no = 0
                                ret_ = "╭───「 Daftar Image 」\n"
                                for audio in audios:
                                    no += 1
                                    ret_ += str("├≽") + " " + audio.title() + "\n"
                                ret_ += "╰───「 Total {} Image 」".format(str(len(audios)))
                                sendFooter(to, ret_)
#===== [ ꜱᴜᴘᴘᴏʀᴛ ʙʏᴇ ᴛᴇᴀᴍ TEAM TERMUX
                        elif cmd.startswith("addvideo"):
                            if msg._from in admin:
                                sep = text.split(" ")
                                name = text.replace(sep[0] + " ","")
                                name = name.lower()
                                if name not in images:
                                    settings["Addvideo"]["status"] = True
                                    settings["Addvideo"]["name"] = str(name.lower())
                                    images[str(name.lower())] = ""
                                    f = codecs.open("video.json","w","utf-8")
                                    json.dump(images, f, sort_keys=True, indent=4, ensure_ascii=False)
                                    sendFooter(to, "Silahkan kirim video nya...")
                                else:
                                    sendFooter(to, "video sudah ada")
                        elif cmd.startswith("dellvideo "):
                            if msg._from in admin:
                               sep = text.split(" ")
                               name = text.replace(sep[0] + " ","")
                               name = name.lower()
                               if name in images:
                                   cl.deleteFile(images[str(name.lower())])
                                   del images[str(name.lower())]
                                   f = codecs.open("video.json","w","utf-8")
                                   json.dump(images, f, sort_keys=True, indent=4, ensure_ascii=False)
                                   sendFooter(to, "Berhasil menghapus {}".format( str(name.lower())))
                               else:
                                   sendFooter(to, "video tidak ada")

                        elif cmd == "listvideo":
                            if msg._from in admin:
                                no = 0
                                ret_ = "╭───「 Daftar Video 」\n"
                                for audio in audios:
                                    no += 1
                                    ret_ += str("├≽") + " " + audio.title() + "\n"
                                ret_ += "╰───「 Total {} Video 」".format(str(len(audios)))
                                sendFooter(to, ret_)
    except Exception as error:
        print (error)


while True:
    try:
        ops = oepoll.singleTrace(count=50)
        if ops is not None:
            for op in ops:
                bot(op)
                # Don't remove this line, if you wan't get error soon!
                oepoll.setRevision(op.revision)
    except Exception as e:
    	logError(e)                      
